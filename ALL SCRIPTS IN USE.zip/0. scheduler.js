﻿// >>>>>>>>> STEEMIT UI this code relies on: https://github.com/steemit/condenser

﻿/*
    INDEX:
    -
    -
    -
*/
/*
    BOTS SUMMARY:
    - gaottantacinque: personal blog
    - gasaeightyfive: (usual free resteems comments)
        * crappy upvote if: first 10 or resteemed
        * subscription + cheap resteem
    - marcocasario: (usual free resteems comments)
        * $0.03 upvote if: resteem
    - cribbio: (usual free resteems comments)
        * MAX 3 LINKS // PS: nah, NY..
        ( * crappy upvote if first 10 or resteemed )
*/

let logsOn = false;
let casarioPostEveryOtherDay = true;
let RESET_ERRORS_AT_MIDNIGHT = true;


// reset only at midnight
let countResteemedTask = 0;
let countResteemedTask_prev = 0;
let resteemedLinksToday = []; // [ 'https://steemit.com/myname/blah' ]
let countPostsCreatedToday = 0;
let countSpammedResteemers = 0;
let countSpammedResteemers_prev = 0;
let usedResteemersDb = [];

// reset every time to get updated balances
let postStatsDb = [];  // [ 'https://steemit.com/myname/blah' ]
let countUpvotes = 0;
let countPayouts = 0;
// reset every time
let countPostsWeek = 0;

const titlesShort = {
  1: 'Resteem users',
  2: 'Post Creation',
  3: 'Spam Resteemers',
  4: 'Self Promotion',
};

const extractUA = () => {
  const ua = navigator.userAgent.split(' ').pop().split('/')[0].toLowerCase();
  return ua === 'safari' ? 'edge' : ua; // changed for Brave Browser - was: 'chrome' : ua;
}
const usag = extractUA();
const notChrome = usag !== 'chrome';

let tasks = {
  // hours, id, name, calledInSameHour
  '2': { id: 1, name: 'Resteem users_h2', calledToday: false }, // + delays
  '4': { id: 1, name: 'Resteem users_h4', calledToday: false }, // + delays
  '9': { id: 1, name: 'Resteem users_h9', calledToday: false }, // + delays
  '10': { id: 1, name: 'Resteem users_h10', calledToday: false }, // + delays
  '13': { id: 1, name: 'Resteem users_h13', calledToday: false }, // + delays
  '19': { id: 1, name: 'Resteem users_h19', calledToday: false }, // + delays
  '21': { id: 1, name: 'Resteem users_h21', calledToday: false }, // + delays
  '23': { id: 1, name: 'Resteem users_h23', calledToday: false }, // + delays
  '100': { id: 3, name: 'Spam Resteemers', calledToday: false }, // + delays
  '101': { id: 4, name: 'Self Promotion' }, // + delays
};
tasks[`${usag === 'edge' ? '9':'12'}`] = { id: 2, name: 'Post Creation', calledToday: false }; // + delays

// ========================================= UTILITIES
const now = () => new Date().toString().split(' ').slice(1,5).join(' ');

function nap(durationMs) {
  const start = new Date().getTime();
  return new Promise(resolve => setTimeout(() => {
    logsOn && console.debug(`${now()} -- Waking up after ${(new Date().getTime() - start) / 1000} seconds`, new Date());
    resolve();
  }, durationMs));
}

const setNativeValue = (element, value, w) => {
  const valueSetter = Object.getOwnPropertyDescriptor(element, 'value').set;
  const prototype = !w ?
    Object.getPrototypeOf(element) : w.window.Object.getPrototypeOf(element);
  const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
  if (valueSetter && valueSetter !== prototypeValueSetter) {
    prototypeValueSetter.call(element, value);
  } else {
    valueSetter.call(element, value);
  }
}
 // >>> TypeError: Unable to get property 'call' of undefined or null reference
 // Launching all resteems..!


const isMySeparator = (anchor) =>
  ( anchor && anchor.offsetParent && anchor.offsetParent.id.indexOf('@gasaeightyfive') !== -1
    || anchor.offsetParent && anchor.offsetParent.id.indexOf('@marcocasario') !== -1
    || anchor.offsetParent && anchor.offsetParent.id.indexOf('@cribbio') !== -1
  ) && ( anchor.href.indexOf('@gasaeightyfive') !== -1
        || anchor.href.indexOf('@marcocasario') !== -1
        || anchor.href.indexOf('@cribbio') !== -1
  ) && ( anchor.offsetParent.innerHTML.indexOf('done guys') !== -1
        || anchor.offsetParent.innerHTML.toLowerCase().indexOf('Thanks guys') !== -1 // for single user resteemed
        || anchor.offsetParent.innerHTML.indexOf('already until this comment') !== -1 );
        // || anchor.offsetParent.innerHTML.toLowerCase().indexOf('done') !== -1 // generic (x IE manual comments & single resteem on FF)
        // || anchor.offsetParent.innerHTML.indexOf('all done so far') !== -1

const notMine = (anchor) =>
  anchor.href.indexOf('@gasaeightyfive') == -1
  && anchor.href.indexOf('@marcocasario') == -1
  && anchor.href.indexOf('@cribbio') == -1;

const getTodaysDOW = (arg) => { // -1 or +n
  let dayIdx = new Date().getDay();
  if (arg < 0) dayIdx = (dayIdx + 7 + arg) % 7;
  else if (+arg) dayIdx = (dayIdx + arg) % 7;
  return 'sunday,monday,tuesday,wednesday,thursday,friday,saturday'.split(',')[dayIdx];
};

const getAllLinksString = () => {
  let result = '';
  [0,1,2,3,4,5,6].forEach(id => {
    const links = getTodaysLinkCodeOnly(id);
    if (links.indexOf('NOT FOUND') === -1) result += `${links},`;
  });
  return result.slice(0, -1);
}

// getTodaysLinkCodeOnly(); // -1, +1,+3,..
// ->  '.. NOT FOUND', 'https://link.com', 'https://l1.it,https://l2.it'
const getTodaysLinkCodeOnly = (arg) => { // -1 or +n
  const dow = getTodaysDOW(arg);
  const todaysPost1 = localStorage.getItem(`${dow}1`);
  const todaysPost2 = localStorage.getItem(`${dow}2`);
  const todaysPost3 = localStorage.getItem(`${dow}3`);
  if (!todaysPost1 && !todaysPost2 && !todaysPost3) {
    logsOn && console.debug(`${now()} -- NO posts found for ${dow}. None of these found in ls: ${dow}1 ${dow}2 ${dow}3!`);
    return 'TODAYS POST(S) NOT FOUND !!';
  } else {
    let result = '';
    if (todaysPost1) result = todaysPost1;
    if (todaysPost2) result += `,${todaysPost2}`;
    if (todaysPost3) result += `,${todaysPost3}`;
    result = result.replace(/^,/, ''); // remove first comma if found
    return result;
  }
}

const checkAbsenceOfErrorPanel = (wind) => {
  const target = wind ? wind.document : document;
  const errorPanel = target.querySelectorAll('span[class=notification-bar-message]')[0];
  if (errorPanel) throw new Error(`Error panel appeared with message: ${errorPanel.textContent}`);
}

const expired = (postAge) => {
  const arrAge = postAge.split(' ');
  return +arrAge[0] >= 5 && `${arrAge[1]} ${arrAge[2]}` === 'days ago';
}

const formatDate = (input) => {
  if (!input) return `invalid date.`;
  return new Date(+(input)).toString().split(' ').slice(0,5).join(' ');
}
const version = formatDate(new Date().getTime());
const getVersion = () => `Scheduler last loaded on ${version}`;

const showErrorsAndMaybeRemove = (fromCode = false, deleteToo = true) => {
  let remove = false;
  if (!fromCode && confirm('Wanna remove errors too ??')) remove = true;
  const errKeys = [];
  Object.keys(localStorage).forEach((key) => { if (key.indexOf('errors') !== -1) errKeys.push(key) });
  let allErrors = '';
  errKeys.forEach((errKey) => {
    allErrors += `
  - ${errKey} --> ${localStorage.getItem(errKey)}
  `;
    (remove || (fromCode && deleteToo)) && localStorage.removeItem(errKey);
  });
  if (fromCode) {
    return allErrors;
  } else {
    alert(`Found${remove?' and removed':' and NOT removed'}:\n${
      errKeys.length?allErrors:'\nnone'
    }`);
  }
}

const removeTasksFromLocalStorage = (fromCode = false) => {
  if (fromCode || confirm('Wanna remove tasks logs from localStorage ??')) {
    const found = [];
    Object.keys(localStorage).forEach((key) => {
      if (key.indexOf('-task-') !== -1) found.push(key);
    });
    let allFound = '';
    found.forEach((key) => {
      allFound += `\n${key} --> ${localStorage.getItem(key)}`;
      localStorage.removeItem(key);
    });
    const msg = `Tasks found and removed:\n${allFound}`;
    if (fromCode) {
      logsOn && console.debug(msg);
    } else {
      alert(msg);
    }
  }
}

const openGithubAndLastPost = (force = false) => {
  if (force || usag !== 'chrome') {
    setTimeout(() => {
      if (usag !== 'edge') {
        open('https://github.com/mycatnamedweb/Steemit-Resteem-script/edit/master/resteem-script.js')
        const w = openLastPost();
        w.window.alert(
          '<< Paste and execute "resteemer.txt" here so that it leaves comments too.. >>'
        );
      } 
    }, 100);
  }
}
openGithubAndLastPost();


// ============================================================
// [[[[[[ ENTRY POINT ]]]]]] -- From: selfPromotion.js
const commentsWithMyLink = () => ({
  chrome: [`(link)`, `(link)<br><br>Thanks :)`],
  firefox: [
    `Thanks for the Free Resteem. Done all the steps. Here is my link to resteem (link)<br><br>Thanks`,
    `Thankful for the Free Service. Here is my entry: (link)`,
    `Bless ya for the Free Resteem! Here it is:<br><br>(link)`,
    `(link) here is mine. Thanks for your free ${Math.random()>=0.5?'resteem':''} service. Good way to help minnows!`,
  ],
  opr: [
    `(link) ${Math.random()>=0.5?'Thanks!':'Thanks'}`,
    `(link)<br><br>${Math.random()>=0.5?'Thanks!':'Thanks'} :D`,
    `(link)  :D`,
    `${Math.random()>=0.5?'Please resteem this':'My link:'} (link)`,
  ],
  edge: [
    `Thanks for your Free Resteem Service. ${Math.random()>=0.5?'Here is my entry. ':''} I also resteemd you. Thanks!<br><br>(link)`,
    `Thanks for the Free Resteem. Here is my link to resteem:<br>(link)<br>I also resteemed your post.`,
    `Thanks for your Service. This is my entry: (link)`,
  ],
});

async function expandIfMyPostAndHidden(w, user) {
  var showButton = w.document.querySelectorAll('button[class="button hollow tiny float-right"]')[0];
  if (showButton && showButton.textContent.toLowerCase() === 'show') {
    logsOn && console.error(`My post was hidden. Expanding it..`);
    const currLocation = w.window.location.href;
    // if (currLocation.indexOf(ACCOUNT_NAME) === -1) {
    //   throw new Error(`Hidden post for user ${user} - and it's not me`);
    // }
    logsOn && console.debug(`${now()} -- Clicking..`);
    showButton.click();
    await nap(1000);
  } else {
    logsOn && console.debug(`${now()} -- No need to expand the post.`);
  }
}

async function spamResteemersWithMyLinks (arrayBotsLinks, takeNap = true) {
  if (typeof arrayBotsLinks === 'string'
      && arrayBotsLinks.split('https://').length === 2) {
    arrayBotsLinks = [arrayBotsLinks];
  }
  if (!Array.isArray(arrayBotsLinks)) {
    const msg = 'The data you provided as argument is not an array or string!';
    alert(msg);
    throw new Error(msg);
  }
  const howManyLinks = arrayBotsLinks.length;
  if (takeNap) {
    // [-- DELAYS (to avoid resources congestion) --]
    if (usag === 'opr') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for ${30000*howManyLinks} secs = ${30000*howManyLinks/60} mins ======= ]]=`);
      await nap(30000 * howManyLinks);
    } else if (usag === 'edge') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for ${30000*howManyLinks*2} secs = ${30000*howManyLinks*2/60} mins ======= ]]=`);
      await nap(30000 * howManyLinks * 2);
    }
  }
  logsOn && console.debug(`${now()} -- =======>> Starting Spamming Other Resteemers process for ${howManyLinks} Resteemers..`);
  countSpammedResteemers_prev = countSpammedResteemers;

  const linkToMyLatestPost = getLastPost(1);
  const linkToMy2ndLatestPost = getLastPost(2); // last 2 if tot > 6 or nada
  if (!linkToMyLatestPost && !linkToMy2ndLatestPost) {
    const msg = 'No posts found in LocalStorage!!!';
    alert(msg);
    throw new Error(msg);
  }

  const openTabs = {};
  for(let id = 0; id < arrayBotsLinks.length; id ++) {
    const resteemerLink = arrayBotsLinks[id];
    logsOn && console.debug(`${now()} -- Opening Resteemer post ${resteemerLink}..`);
    if ( resteemerLink.indexOf('https://steemit.com') === -1
        // || resteemerLink.indexOf('@gasaeightyfive') !== -1 || // PS. ok with my links too
      ) {
      throw new Error(`Found invalid link >> ${resteemerLink}`)
    }

    let currentCommLink = linkToMy2ndLatestPost && howManyLinks > 10 && id > howManyLinks - 2 ?
      linkToMy2ndLatestPost : linkToMyLatestPost;

    try {
      openTabs[`tab${id}`] = open(resteemerLink,'_blank');//,'toolbar=no,status=no,menubar=no,left=1000000,top=10000000','');
      await nap(6000);
      await expandIfMyPostAndHidden(openTabs[`tab${id}`], 'some-user-blah');

      logsOn && console.debug('Checking if post is already upvoted.. (except when its mine)')
      logsOn && console.debug('Nah, can be already upvoted because they used my free resteems. Going on.')
      // if (alreadyVoted(openTabs[`tab${id}`]) && linkHasNoneOfMyAccountNames(resteemerLink)) {
      //     await nap(2000); // double checking..
      //     if (alreadyVoted(openTabs[`tab${id}`])) {
      //       logsOn && console.debug('Already voted, skipping..');
      //       continue;
      //     }
      // }

      logsOn && console.debug('Upvoting post..');
      await upvote(openTabs[`tab${id}`]);
      await nap(6000);

      if (resteemerLink.indexOf(accounts[usag]) === -1) {
        logsOn && console.debug('Following Resteemers if not already following..');
        await follow(openTabs[`tab${id}`]); // waits 5000 too to check btn status
        await nap(5000); // MIN 20 secs ..
      }

      let target = openTabs[`tab${id}`].document;
      if (usag === 'edge') {
        await hackToOpenSteemerPostInSameSpa(resteemerLink, openTabs[`tab${id}`]); // navigate to post to like and comment with my link
        target = document;
      }

      const commentArr = commentsWithMyLink()[usag];
      const commRandId = Math.floor(Math.random() * commentArr.length - 1) + 1;
      // if (usag === 'firefox') currentCommLink = `Thanks ${currentCommLink}`;
      // if (usag === 'opr') currentCommLink = `Thanks for you free service! Here is my entry: ${currentCommLink}`;
      const comment = `${commentArr[commRandId].replace('(link)', currentCommLink)}`;
	// `${(resteemerLink.indexOf('gasaeightyfive') !== -1 || resteemerLink.indexOf('cribbio') !== -1 || resteemerLink.indexOf('marcocasario') !== -1 || Math.random()>0.9) ?

      logsOn && console.debug(`${now()} -- Adding comment ""${comment}"" .. [EVERY >= 20 SECS @]`);
      if (resteemerLink.indexOf(accounts[usag]) !== -1) {
        logsOn && console.debug('Not leaving comments on my own Resteemer post..');
      } else {
        await addComment(comment, target);
        await nap(5000);
      }
      if (usedResteemersDb.indexOf(openTabs[`tab${id}`].window.location.href) === -1) {
        usedResteemersDb.push(openTabs[`tab${id}`].window.location.href);
        countSpammedResteemers++;
      }
      logsOn && console.debug(`${now()} -- This post DONE. Commented ${currentCommLink} on ${resteemerLink}`);
    } catch (err) {
      logsOn && console.error(`>>> ${err}`);
      localStorage.setItem(`errors-spamResteemersWithMyLinks-${formatDate(new Date().getTime())}`, err);
    } finally {
      if (openTabs[`tab${id}`].close) openTabs[`tab${id}`].close();
    }
  }
  if (usag === 'edge') {
    await hackToOpenSteemerPostInSameSpa(null); // navigate back to wallet
  }
  logsOn && console.debug('>>>>> spamResteemersWithMyLinks END <<<<<<');
}

const getLastPost = (arg) => {
  let result;
  try {
    if (!arg) throw new Error('Specify if you want the 1st or 2nd latest');
    const backwardsOrderArr = [0,6,5,4,3,2,1];
    for (let i = 0; i < backwardsOrderArr.length; i++) {
      const idx = backwardsOrderArr[i];
      const linksForDay = getTodaysLinkCodeOnly(idx);
      if (linksForDay.indexOf('NOT FOUND') === -1) {
        const linkArr = linksForDay.split(',');
        if (arg === 1) {
          result = linkArr[0];
          return;
        }
        if (arg === 2 && linkArr[1]) {
          result = linkArr[1];
          return;
        }
        arg = 1;
      }
    }
  } finally {
    logsOn && console.debug(`${now()} -- Post extracted is ${result}`);
    return result;
  }
}

const alreadyVoted = (w) => {
  let x = w.document.getElementsByClassName('PostFull__footer row')[0];
  if (!x) return true; // it will try again in a sec..
  const hasUpvote = x.getElementsByClassName('Voting__button Voting__button-up Voting__button--upvoted')[0];
  return hasUpvote;
}

async function addComment (comment, target) {
  let replyBtn = target.getElementsByClassName('PostFull__reply')[0]
    .getElementsByTagName('a')[0];
  replyBtn.click();
  await nap(1000);
  let textarea = target.getElementsByTagName('textarea')[0];
  setNativeValue(textarea, comment);
  textarea.dispatchEvent(new Event('input', { bubbles: true }));
  await nap(500);
  const postReplyBtn = target.getElementsByClassName('ReplyEditor row')[0].getElementsByTagName('button')[0];
  postReplyBtn.click();
}

const isPostUpvoteBtn = (upvoteBtn, w) => {
  let resteemerName;
  const block = upvoteBtn.parentElement.parentElement.parentElement.parentElement.parentElement;
  if (block.children[0].textContent.split('by ').length === 1) {
    resteemerName = block.parentElement.children[0].textContent.split('by ')[1].split(' (')[0];
  } else {
    resteemerName = block.children[0].textContent.split('by ')[1].split(' (')[0];
  }
  return w.window.location.href.indexOf(resteemerName) !== -1;
}

// Not in use:
// const isRighCommenttWeightBtn = (weightBtn, win) => {
//   const name = weightBtn.parentElement.parentElement.parentElement
//     .parentElement.parentElement.parentElement.parentElement
//     .parentElement.parentElement
//     .textContent.split('[-]')[1].split(' (')[0];
//   logsOn && console.debug(`${now()} -- Weight btn is for name: ${name}`);
//   return win.window.location.href.indexOf(name) !== -1;
// }

const isPostWeightBtn = (weightBtn, win) => {
  logsOn && console.debug(`${now()} --  -- checking if it's weight btn of the post..`);
  let name = '@@@';
  let parentBlock;
  try {
    parentBlock = weightBtn.parentElement.parentElement.parentElement.parentElement
      .parentElement.parentElement.parentElement.parentElement.parentElement;
    name = parentBlock.textContent.split('by ')[1].split(' (')[0];
    logsOn && console.debug(`${now()} -- Name found for post owner: ${name}`);
  } catch (err) {
    logsOn && console.error(`Error. Not post upvote btn. Debug :: innerText was:\n${parentBlock.textContent}`);
  }
  return win.window.location.href.indexOf(name) !== -1;
}

async function upvote (w) {
  const upvBtnType1 = w.document.getElementById('upvote_button');
  const upvBtnBlock = w.document.querySelectorAll('span[class="Voting__button Voting__button-up"]')[0];
  const upvBtnType2 = upvBtnBlock && upvBtnBlock.firstChild.firstChild;
  const upvoteBtn = upvBtnType1 || upvBtnType2;
  if (!isPostUpvoteBtn(upvoteBtn, w)) throw new Error(`Was going to upvote first commenter instead of post - likely already upvoted then. Out.`);
  if (!upvoteBtn) {
    logsOn && console.debug('No upvote button found. Skipping.');
    throw new Error('No upvote button found. Not commenting link to avoid doubles..');
  }
  upvoteBtn.click();
  await nap(1000);
  const weightBtn = w.document.querySelectorAll('a[class="confirm_weight"]')[0];
  if (weightBtn) {
    if (!isPostWeightBtn(weightBtn, w)) return logsOn && console.error(`Weight button was not the post one! Out.`);
    weightBtn.click();
    await nap(3000);
  }
}

async function follow (w) {
  logsOn && console.debug('Opening author dropdown to follow..');
  w.document.getElementsByClassName('Author')[0].getElementsByTagName('a')[0].click()

  const followBtn = w.document.getElementsByClassName('button slim hollow secondary ')[0];
  if (followBtn.textContent.toUpperCase() === 'FOLLOW') {
    logsOn && console.debug(`${now()} -- Not following yet. Clicking on FOLLOW..`);
    followBtn.click();
    await nap(5000);
    if (followBtn.textContent.toUpperCase() !== 'UNFOLLOW') {
      logsOn && console.debug('Button did not change, (maybe) was not able to follow..');
    }
  }
}


async function hackToOpenSteemerPostInSameSpa (link, wAlreadyOpen) {
  if (link) {
    try {
      logsOn && console.debug(`${now()} -- RESTEEMing POST SO THAT IT WILL APPEAR ON MY BLOG AND CAN OPEN IT IN SPA`)
      const resteemBtn = wAlreadyOpen.document.querySelectorAll('[title=Resteem]')[0]
      if (!resteemBtn && link.indexOf(accounts[usag]) === -1) {
        throw new Error('Resteem button not found..');
      }
      resteemBtn && resteemBtn.click();
      await nap(1000);
      logsOn && console.debug('Confirming Resteem..');
      const confirmForm = wAlreadyOpen.document.getElementsByClassName('ConfirmTransactionForm')[0];
      if (!confirmForm && link.indexOf(accounts[usag]) === -1) {
        throw new Error('Resteem confirmation popup did not appear!');
      }
      confirmForm && confirmForm.getElementsByTagName('button')[0].click();
      await nap(5000);
      const resteemOk = wAlreadyOpen.document.getElementsByClassName('Reblog__button Reblog__button-active')[0];
      if (resteemOk && confirmForm) {
        logsOn && console.debug('SUCCESS! Resteemed.');
      } else if (resteemOk && !confirmForm) {
        logsOn && console.debug('Post was already resteemed');
        if (link.indexOf(accounts[usag]) === -1)
          throw new Error('Post was already resteemed, it would not appear on my blog to comment my link..');
      } else {
        const msg = `FAILED? Grey Resteem...`;
        logsOn && console.debug(msg);
      }
    } catch (err) {
      logsOn && console.error(`>>> ${err}`);
      localStorage.setItem(`errors-hackToOpenSteemerPostInSameSpa-${formatDate(new Date().getTime())}`, err);
    }
  }

  logsOn && console.debug('Opening the dropdown menu.. (2)');
  var drop = document.getElementsByClassName('DropdownMenu Header__usermenu left')[0]
  drop.firstChild.click();
  await nap(1000);

  let linkOfPostToOpen;
  if (!link) {
    return 'PS. NOT OPENING WALLET ANYMORE BECAUSE NOW ITS ON NEW SITE';
    logsOn && console.debug('Navigating back to the wallet page clicking on wallet button.. (2)');
    var blogBtn = document.getElementsByClassName('VerticalMenu menu vertical VerticalMenu')[0]
      .getElementsByTagName('li')[5].firstChild
    blogBtn.click();
    await nap(5000);
    return;
  }

  logsOn && console.debug('Clicking on the Blog button..');
  var blogBtn = document.getElementsByClassName('VerticalMenu menu vertical VerticalMenu')[0]
    .getElementsByTagName('li')[2].firstChild
  blogBtn.click();
  await nap(5000);

  logsOn && console.debug(`${now()} -- Finding the post of the Resteemer that I just resteemed..`);
  const linkToSearch = link.replace('https://steemit.com','');
  const resteemedPostTitle = document.querySelectorAll(`a[href="${linkToSearch}"]`)[2];
  if (!resteemedPostTitle) {
    throw new Error('Resteemed post not found on my Blog wall..! ADVICE: on IE resteem resteemers posts when copy links..');
  }
  resteemedPostTitle.click()
  await(7000);
}


// ============================================================
// [[[[[[ ENTRY POINT ]]]]]] -- From: selfPromotion.js

const todaysLinkLs = (id) => {
  const dow = getTodaysDOW();
  return localStorage.getItem(`${dow}${id}`);
}

const getTodaysLink = () => {
  if (window.location.href.indexOf('https://steemit.com') == -1) {
    const msg = 'You gotta execute this command on steemit!';
    alert(msg);
    throw msg;
  }
  const todaysLinks = [todaysLinkLs(1), todaysLinkLs(2), todaysLinkLs(3)];
  let allLinks = '';
  todaysLinks.forEach((link) => {
    if (link) {
      if (link.indexOf('https://steemit.com') == -1) {
        const msg = `WTF!! Extracted link that is not for steemit!!!

        ${link}`;
        alert(msg);
        throw msg;
      }
      allLinks += `${link},`;
    }
  });
  if (!allLinks.length) {
    logsOn && console.debug(`${now()} -- No steemit links found in localStorage.`);
    return '';
  }
  return allLinks.slice(0,-1);
}

const linkHasNoneOfMyAccountNames = (link) => {
  let notFound = true;
  Object.keys(accounts).forEach(brs => {
    if (notFound) {
      notFound = link.indexOf(accounts[brs]) === -1;
    }
  });
  return notFound;
}

const hasExternalLink = (dataArr) => {
  let hasExternal = false;
  dataArr.forEach(link => {
    if (!hasExternal) {
      hasExternal = linkHasNoneOfMyAccountNames(link);
    }
  })
  return hasExternal;
}

// ===========================================
// execTodaysSelfSupport({
//  "firefox":"https://steemit.com/resteem/@gasaeightyfive/free-resteem-service-follow-and-upvote-this-post-open,https://steemit.com/resteem/@gasaeightyfive/free-resteem-service-follow-and-upvote-this-post-open",
//  "opr":"https://steemit.com/minnowsupport/@marcocasario/onscc-free-resteem-to-everyone-just-follow-and-upvote-on",
//  "edge":"https://steemit.com/resteem/@cribbio/daily-free-resteem-follow-upvote-leave-link-in-comments-active__BROKEN",
// }, true/*->default value for takeNap*/);
async function execTodaysSelfSupport (linksObj, takeNap = true) {
  if (!linksObj) {
    const msg = 'You gave me no links to my bots posts. Use the UI first. --> http://my-steemit-bots.bitballoon.com/';
    alert(msg);
    throw msg;
  }
  if (takeNap) {
    // [-- DELAYS (to avoid resources congestion) --]
    if (usag === 'opr') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 90 secs = 1.5 mins ======= ]]=`);
      await nap(60000);
    } else if (usag === 'edge') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 180 secs = 3 mins ======= ]]=`);
      await nap(120000);
    }
  }
  let windows = {};
  try {
    delete linksObj[usag];
    const arrBrws = Object.keys(linksObj);
    for (let id = 0; id < arrBrws.length; id++) {
      const botBrowser = arrBrws[id];
      const botLinks = linksObj[botBrowser];
      const links = botLinks.split(',');
      for (let idx = 0; idx < links.length; idx++) {
        const link = links[idx];
        if (linkHasNoneOfMyAccountNames(link)) {
          throw new Error(`Link ${link} does not contain my account name!`);
        }
        windows[`w${id}{idx}`] = open(link,'_blank');//,'toolbar=no,status=no,menubar=no,left=1000000,top=10000000','');
        await nap(5000);

        logsOn && console.debug(`${now()} -- Processing my link ${link}..`);
        const upvBtn = windows[`w${id}{idx}`].document.getElementById('upvote_button');
        if (!upvBtn) {
          const msg = `Upvote button not found for link ${link} !`;
          logsOn && console.debug(msg);
          throw msg;
        }
        if (upvBtn.title === 'Remove Vote') {
          logsOn && console.debug(`${now()} -- Was already upvoted: ${link}`);
        } else {
          windows[`w${id}{idx}`].document.getElementById('upvote_button').click();
          await nap(1000);
          const weightBtn = windows[`w${id}{idx}`].document.querySelectorAll('a[class="confirm_weight"]')[0];
          if (weightBtn && isPostWeightBtn(weightBtn, windows[`w${id}{idx}`])) {
            weightBtn.click();
            await nap(3000);
          } else {
            logsOn && console.error(`Was going to upvote wrong btn. Likely already upvoted. Going on.`);
          }
        }

        if (usag !== 'chrome') { // main user does not resteem bots stuff
          const resteemBtn = windows[`w${id}{idx}`].document.querySelectorAll('[title=Resteem]')[0];
          if (!resteemBtn) {
            logsOn && console.debug(`${now()} -- Resteem button not found for link ${link}. Skipping..`);
            continue;
          }
          resteemBtn.click();
          await nap(1000);
          logsOn && console.debug('Confirming Resteem..');
          const confirmForm = windows[`w${id}{idx}`].document.getElementsByClassName("ConfirmTransactionForm")[0]
          if (confirmForm) {
            confirmForm.getElementsByTagName('button')[0].click();
            await nap(3000);
          }
          const resteemOk = windows[`w${id}{idx}`].document.getElementsByClassName("Reblog__button Reblog__button-active")[0];
          if (resteemOk && confirmForm) {
            logsOn && console.debug('Done.');
          } else if (resteemOk && !confirmForm) {
            logsOn && console.debug(`${now()} -- Already resteemed: ${link}`);
          } else {
            logsOn && console.debug(`${now()} -- FAILED? Grey Resteem for ${link}`);
          }
        }
        windows[`w${id}{idx}`].close();
        delete windows[`w${id}{idx}`];
      }
      logsOn && console.debug(`${now()} -- All ${links.length} link(s) for ${getAccountName(botBrowser)} have been processed`);
    }
    logsOn && console.debug(`${now()} -- >>>> All links for ${arrBrws} have been processed`);
  } catch (err) {
    localStorage.setItem(`errors-execTodaysSelfSupport-${formatDate(new Date().getTime())}`, err);
    // throw new Error(`execTodaysSelfSupport -> ${err}`);
  } finally {
    Object.keys(windows).forEach((ref) => { windows[ref].close(); delete windows[ref]; });
  }
}

// ============================================================
// [[[[[[ ENTRY POINT ]]]]]] -- From: post-creator.js
async function processPostCreation(takeNap, w, errK) {
  try {
    await editExpiredPostsToClosed(takeNap);
    const created = await createMyPost(w);
    if (created) openGithubAndLastPost();
    cancelTaskAtTime(usag === 'edge' ? 8 : 1, 'from-code');
  } catch (err) {
    errK(err);
  }
}

const getDowAndIdGivenLink = (link) => {
  const daysArr = 'sunday,monday,tuesday,wednesday,thursday,friday,saturday'.split(',');
  for (let id = 0; id < daysArr.length; id++) {
    const dow = daysArr[id];
    for (let idx = 1; idx < 4; idx++) {
      const value = localStorage.getItem(`${dow}${idx}`);
      if (value === link) {
        logsOn && console.debug(`${now()} -- The given link ${link} has been found in localStorage as ${dow}${idx}`);
        return `${dow}${idx}`;
      }
    }
  }
}

async function editExpiredPostsToClosed(takeNap = false) {
  if (takeNap) {
    // [-- DELAYS (to avoid resources congestion) --]
    if (usag === 'opr') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 60 secs = 1 mins ======= ]]=`);
      await nap(60000);
    } else if (usag === 'edge') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 120 secs = 2 mins ======= ]]=`);
      await nap(120000);
    }
  }
  logsOn && console.debug('Checking if old posts have to be edited to CLOSED..');
  const links = getAllLinksString();
  if (!links) {
    logsOn && console.debug(`${now()} -- No links found in localStorage! Won't edit expired posts.`);
  } else {
    const posts = links.split(',');
    for (let id = 0; id < posts.length; id++) { // gotta use for or interpreter complains for await nap ... (?)
      const link = posts[id];
      logsOn && console.debug(`${now()} -- Checking expiration of post ${link}..`);
      if (!link) continue;
      let w = { close: () => {} };
      try {
        w = open(link,'_blank');//,'toolbar=no,status=no,menubar=no,left=1000000,top=10000000','');
        await nap(5000);
        // await expandIfMyPostAndHidden(w, 'me-my-posts');
        const postAge = w.document.querySelectorAll('div[class=right-side]')[0]
          .querySelectorAll('span[class=updated]')[0].textContent;
        console.log(`Current link "${link}" has age: ${postAge}`);
        if (expired(postAge)) {
          console.log(`${now()} -- Setting old post ${link} to CLOSED and removing it from LS..`);
          const dowAndId = getDowAndIdGivenLink(link);
          localStorage.removeItem(`${dowAndId}`);

          if (usag !== 'edge') { // bc of IE issues..
            const editBtn = w.document.querySelectorAll('span[class=PostFull__reply]')[0].children[1];
            editBtn.click();
            await nap(200);

            const titleEl = w.document.querySelectorAll('input[class=ReplyEditor__title]')[0];
            const oldTitle = titleEl.value;
            const newTitle = getNewTitle(oldTitle);
            setNativeValue(titleEl, newTitle);
            titleEl.dispatchEvent(new Event('input', { bubbles: true }));

            const updatePostBtn = w.document.querySelectorAll('button[type=submit]')[1];
            updatePostBtn.click();
            await nap(2500); // wait until page updated
            checkAbsenceOfErrorPanel(w);
            await nap(2500); // wait until page updated
            checkAbsenceOfErrorPanel(w);
            if (titleEl.value !== newTitle) throw new Error(`Title is not updated after 5 seconds for post ${link}`);
          }
        }
      } catch (err) {
        localStorage.setItem(`errors-editExpiredPostsToClosed-${formatDate(new Date().getTime())}`, err);
        logsOn && console.error(`editExpiredPostsToClosed -> ${err}`);
        // throw new Error(msg); // nah, just go on..
      } finally {
        w.close();
      }
    }
  }
}

async function addWinnerComment (blog, name, link, isHisBlog, myNewPostLink) {
  logsOn && console.debug(`Navigating to newly created post..`);
  if (myNewPostLink) {
    blog.location.href = myNewPostLink;
    await nap(10000);
  }
  logsOn && console.debug(`${now()} -- Leaving winner comment on ${isHisBlog ? 'his' : 'my'} today's blog. Winner: ${name}.`);
  try {
    await nap(5000); // NEW @@
    if (!blog.document) throw new Error(`Document of my blog not found..!`);
    console.debug(`### debug: here1`);
    let replyBtn = blog.document.getElementsByClassName('PostFull__reply')[0];
    let anchor;
    if (!replyBtn) {
      console.error(`Reply btn not found for ${name} and link ${link}! My blog? ${!isHisBlog}. Looping over anchors to find right one..`);
      const allAnchors = document.getElementsByTagName('a');
      for (i = 40; i < 120; i++) if (allAnchors[i] && allAnchors[i].textContent === 'Reply') { anchor = allAnchors[i]; break; }
    } else {
      console.debug(`### debug: here2 -- replybtn was ok`);
      anchor = replyBtn.getElementsByTagName('a')[0];
    }
    anchor.click();
    await nap(1000);
    console.debug(`### debug: here3`);
    let textarea = blog.document.getElementsByTagName('textarea')[0];
    const todaysLink = getTodaysLinkCodeOnly();
    const yesterdaysLink = getTodaysLinkCodeOnly(casarioPostEveryOtherDay ? -2 : -1);
    let comment = isHisBlog ? `Congratulations @${name}! You got drawn in my [last Free Resteem & Giveway Post](${todaysLink.indexOf('NOT FOUND')!=-1?'https://steemit.com/@marcocasario':todaysLink}) and will receive a FREE 5 Resteems Subscription (includes 5x $~0.02 upvotes)! Enjoy! &nbsp; =)<br><div class="pull-right"><sub>If this comment bothers you reply OFF</sub></div>` :
    `<div class="pull-right"><sub>( automatic winner drawing )</sub></div>

<sub><sub><sub><a href="https://giphy.com/gifs/swag-money-make-it-rain-VTxmwaCEwSlZm">source</a></sub></sub></sub>

<sub>https://78.media.tumblr.com/tumblr_mak6ktGGkA1ru90dzo1_250.gif</sub> &nbsp; @${name} <b>YOU WON a 5 Resteems Subscription! =] <div class="pull-left">(includes 5x $~0.02 upvotes)! =]</div> </b>

<div class="pull-right"><a href="${yesterdaysLink}">the last giveaway</a> -- <a href="${link ? link : `https://(last_post_not_found)`}">your last post</a></div>`;
    setNativeValue(textarea, comment, blog);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    await nap(500);
    console.debug(`${now()} -- DEBUG: addWinnerComment BEFORE clicking submit of reply. HisBlog: ${isHisBlog}`);
    let postReplyBtn = blog.document.querySelectorAll('[type=submit]')[1];
    logsOn && console.debug(`${now()} -- -- Sumbitting reply..`);
    postReplyBtn.click();
    console.debug(`${now()} -- DEBUG: addWinnerComment AFTER clicking submit of reply.`);
    await nap(7000);
  } catch (err) {
    const msg = `-- Error in addWinnerComment: hisblog: ${isHisBlog}. Error: ${err}`;
    logsOn && console.error(msg);
    localStorage.setItem(`errors-addWinnerComment-${formatDate(new Date().getTime())}`, msg);
    throw new Error('stopped in addWinnerComment. Why: ' + msg);
  }
}



async function createMyPost(w0) {
  if (casarioPostEveryOtherDay && usag === 'opr' && new Date().getDate() % 2 === 0) {
    logsOn && console.debug('-------- TASK SKIPPED. New post only every other day for CASARIO. -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Post~Creation`);
    localStorage.setItem(`${getTodaysDOW()}-task-Post~Creation`,`${startTime}->${new Date().getTime()}`);
    document.getElementById(`exec2`).style['color'] = '#0d284d';
    document.getElementById(`exec2`).style['background-color'] = 'transparent';
    return false;
    // YESTERDAY'S LINK CHANGED TO getTodaysLinkCodeOnly(-2) and getTodaysDOW(-2)
  }

  let target = w0 ? w0.document : document;

  if (usag === 'edge') {
    logsOn && console.debug('Special behavior for retarded browser.. (Edge..)');
    target = document;
    target.querySelectorAll("a[href='/submit.html']")[0].click();
    nap(1000);
  }

  logsOn && console.debug('Preparing new post to publish..');
  const accountName = getAccountName();
  if (accountName === 'gaottantacinque') {
    const msg = `You are using the wrong account!!
Trying to create a resteemer bot post on partial-bot @${accountName}.`;
    alert(msg);
    throw msg;
  }
  let myBlog = { close: () => {} };
  try {
    const optionalLink = localStorage.getItem('postToPromote');
    const postToCreate = await getPostObject(optionalLink, getTodaysDOW(casarioPostEveryOtherDay ? -2 : -1)); // -2 --> NEW POST EVERY OTHER DAY
    await nap(3000);
    const title = target.querySelectorAll('input[name=title]')[0];
    if (!title) {
      throw new Error('Something is wrong. Title not found..');
    }

    setNativeValue(title, postToCreate.title);
    title.dispatchEvent(new Event('input', { bubbles: true }));

    const textarea = target.querySelectorAll('textarea[name=body]')[0];
    setNativeValue(textarea, postToCreate.body);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));

    const tags = target.querySelectorAll('input[name=category]')[0];
    setNativeValue(tags, postToCreate.tags);
    tags.dispatchEvent(new Event('input', { bubbles: true }));

    const submitNewPostBtn = target.querySelectorAll('button[type=submit]')[1];
    submitNewPostBtn.click();
    await nap(2500);
    checkAbsenceOfErrorPanel();

    logsOn && console.debug('Checking if it`s annoyingly asking me to login..');
    await nap(2500);
    const loginModalButtons = target.getElementsByClassName('login-modal-buttons')[0];
    if (loginModalButtons) {
      logsOn && console.debug('Found login modal, trying to submit login..');
      await nap(2500);
      loginModalButtons.disabled = false;
      loginModalButtons.querySelectorAll('button[type=submit]')[0].click();
    }
    await nap(2000);
    checkAbsenceOfErrorPanel();

    await nap(20 * 1000); // wait for slow post creation
    const linkToMyBlog = `https://steemit.com/@${accountName}`;
    myBlog = open(linkToMyBlog,'_blank');
    logsOn && console.debug(`${now()} -- Waiting for my blog ${linkToMyBlog} to load in order to extract link of just created post.. ================================= @@`);
    await nap(10 * 1000); // wait until my blog is loaded and get first article link
    const postBlockTitle = myBlog.document.querySelectorAll(`h2[class='articles__h2 entry-title']`)[0];
    const generatedURL = postBlockTitle.children[0].href;
    const titleNewPost = postBlockTitle.children[0].textContent;
    if (titleNewPost.substr(0,20) !== postToCreate.title.substr(0,20))
      throw new Error(`Title of newly created post not found or does not match expectation. Found: ${titleNewPost}`);

    logsOn && console.debug(`${now()} -- Self upvoting newly created post..`);
    const upvBtn = postBlockTitle.parentElement.getElementsByTagName('a')[2]
    upvBtn.click();
    await nap(2000);
    const weightBtn = myBlog.document.querySelectorAll('a[class="confirm_weight"]')[0];
    if (weightBtn && isPostWeightBtn(weightBtn, myBlog)) {
      weightBtn.click();
      await nap(3000);
    } else {
      localStorage.setItem(`errors-createMyPost-${formatDate(new Date().getTime())}`, `Did not upvote new post..`);
    }

    if (usag === 'opr') {
      const winnerName = (postToCreate.yesterdaysWinner || { name: 'in--progress' }).name;
      const winnerLink = (postToCreate.yesterdaysWinner || { link: 'in--progress' }).link;
      if (!winnerName) {
        console.debug(`Something went wrong before this. Winner not found. Not adding winner comment.`);
      } else {
        logsOn && console.debug(`${now()} -- Adding winner comment. Name: ${name}, Link to upvote: ${winnerLink}..`);
        localStorage.setItem('contestWinner', winnerName);
        await addWinnerComment (myBlog, winnerName, winnerLink, false, generatedURL);
      }
    }

    const dow = getTodaysDOW();
    let saved = false;
    [1,2,3].forEach((id) => {
      if (!saved && localStorage.getItem(`${dow}${id}`) === null) {
        localStorage.setItem(`${dow}${id}`, generatedURL);
        logsOn && console.debug(`${now()} -- New post ${generatedURL} SUCCESSFULLY created and saved in LS under entry ${dow}${id}.`);
        saved = true;
        logsOn && console.debug('-------- TASK COMPLETED -------');
        const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Post~Creation`);
        localStorage.setItem(`${getTodaysDOW()}-task-Post~Creation`,`${startTime}->${new Date().getTime()}`);
        countPostsCreatedToday++;
        updateUIAndChangeBtnColorTo(1, 2);
        updateCount(2);
      }
    });
    if (!saved) {
      localStorage.setItem(`${dow}1`, generatedURL);
      throw `Had to overwrite ${dow}1 because localStorage was full for today!!`;
    }

    if (usag === 'edge') {
      logsOn && console.debug('Navigating back to wallet.. (Edge sucks!)');
      await hackToCreatePostInIE(null);
    }
    return true;
  } catch (err) {
    logsOn && console.error(`>>> ${err}`);
    localStorage.setItem(`errors-createMyPost-${formatDate(new Date().getTime())}`, err);
    throw new Error(`createMyPost -> ${err}`);
  } finally {
    if (myBlog.close) myBlog.close();
    if (w0.close) setTimeout(() => w0.close(), 30000);
  }
}

const accounts = {
  chrome: 'gaottantacinque',
  firefox: 'gasaeightyfive',
  opr: 'marcocasario',
  edge: 'cribbio',
};

const getAccountName = (brsName) => {
  const ua = brsName || extractUA();
  return accounts[ua];
};

const postStatus = {
  open: {
    firefox: '[OPEN]',
    opr: '{~3K SP BOT: ACTIVE}',
    edge: '(OPEN for 3d)', // (ACTIVE)
  },
  closed: {
    firefox: '[CLOSED]',
    opr: '{BOT: OFF}',
    edge: '', // (INACTIVE) // cant change because of crappy IE issues..
  }
}

const enemyTag = () => 'resteembot';// bestofresteembot winwithresteembot resteembotvip'.split(' ')[Math.floor(Math.random()*4-1)+1];
var nowInTitle = (mode) => {
  switch (mode) {
  case 1:
    return new Date().toString().split(' ').slice(1,3).join(' ');
  case 2:
    return `${new Date().toString().split(' ')[2]}-${new Date().toString().split(' ')[1]}`;
  case 3:
    return `#${new Date().getMonth()+1}-${new Date().toString().split(' ')[2]}`;
  default:
    return '';
  }
}

// Reason for low rep [here](https://steemit.com/steemit/@marcocasario/resteem-bot-as-he-did-with-others-managed-to-send-our-repo-to-3-cribbio-marcocasario-gasaeightyfive).

const postsDb = () => ({
  opr: {
    title: `FREE RESTEEM for everyone!! ${Math.random()>=0.5?'Fastеst':'First'} 3 gеt a $0.02 upvotе on their last post. Extra prize: 1x Subscription. ~status~ ++ Quotе of thе day`,
    body: `
<h2>STEPS:</h2>

<h2>Upvote, follow, lеavе ${Math.random()>=0.5?'1':'onе'} Steemit link in the comments.</h2>

<sub>If you leave a Partiko link the correspondent Steemit post will be resteemed if the URL matches.</sub>

-----

<div class="pull-right"><img src="https://cdn.steemitimages.com/DQmcWDczPA35ERG1d4NXcg9JkZTnKwkb91fs7JVV76sxHjU/ezgif.com-gif-maker.gif"></div>
&nbsp;&nbsp;&nbsp;&nbsp;<div class="phishy"><b>${Math.random()>=0.5?'QUOTE OF THE DAY':'TODAY\'S QUOTE'}:</b></div>

{X1}

<div class="pull-right"><sub><sub><sub><a href="https://www.warriorgoddesskettlebelltraining.com/events/magickal-meditation-summer-solstice/">img source</a></sub></sub></sub></div>

-----

<sub>Please no ${Math.random()>=0.5?'nsfw':'#nsfw'} and no users on the [global blacklist](http://blacklist.usesteem.com/user/USERNAME)

Nеw post еvеry ${casarioPostEveryOtherDay?'other':''} day ${Math.random()>=0.5?'in the ["New" section](https://steemit.com/created/resteem) of the resteem channel':'on the #resteem channel'}. <br>${!casarioPostEveryOtherDay?'':'<sub>![](https://cdn.steemitimages.com/DQmNqQBfUnuTuip47TwbZyswoK6eX3ouiX4q7Usscs5yZMf/image.png)</sub>&nbsp;&nbsp;'} <sub>![](https://cdn.steemitimages.com/DQmVNfRYqbSKFxzpQBTtXANMPXziRWoF9WJ8Hz9AfYc9T3F/image.png)</sub>

-----

<h4>NO-SPAM POLICY:</h4>

<div class="pull-right"><img src="https://cdn.steemitimages.com/DQmVuxP1qt8RWwnMJtgZiB4KDEWzwKSQ5RxNjwSjXMR2cgj/image.png"></div>
<b>I DO NOT COMMENT ON YOUR ${Math.random()>=0.5?'POSTS':'ARTICLES'}</b> to promote my service${Math.random()>=0.5?' to your rеaders':''} unless you OPT-IN.

NOTE: My own ${Math.random()>=0.5?'automatic':''} commеnts on this post arе ${Math.random()>=0.5?'disablеd':'mutеd'} aftеr 2 days but thе bot kееps procеssing ${Math.random()>=0.5?'your':''} nеw commеnts for ${Math.random()>=0.5?'about':''} 5 days.</sub></h5>

-----

<sub>Spending too much time on Steemit? If you or someone you know has a gambling problem and wants help, call [1-800-GAMBLER](https://www.youtube.com/watch?v=URhjjcV67d0).</sub>

-----

<h2>${Math.random()>=0.8?'REWARDS': `${Math.random()>=0.5?'AWARDS':'PRIZES'}`}:</h2>

.1. If you also rеstееm this post ${Math.random()>0.5?`I will thank you`:'my bot will thank u'} with a [~$0.02](https://steemworld.org/@marcocasario) upvotе! (& follow) &nbsp; &nbsp; <sub>[ Upvoting active for 48hs, thеn usе thе nеw post ]</sub>

  &nbsp; &nbsp;  &nbsp;  &nbsp;  Plеasе, if you ${Math.random()>=0.5?'rеstееmеd':'rе-stееmеd'} mе, writе it in thе ${Math.random()>=0.9?'samе':''} commеnt<br>  &nbsp; &nbsp;  &nbsp;  &nbsp;  ${Math.random()>=0.5?'togеthеr':''} with your link (eg. "I also resteemed you").

.2. Give a try to JSEcoin minining in your browser and use [my referral](href="https://platform.jsecoin.com/?lander=3&utm_source=referral&utm_campaign=aff113192), I will reward you with at 15 resteems + upvotes subscription.

.3. After ~${casarioPostEveryOtherDay?'48':'24'}hs <b>onе lucky commеntеr</b> will bе automatically ${Math.random()>=0.5?'drawn':'randomically picked'} and ${Math.random()>0.5?'WIN':'GET'} a 5x Resteems Subscription (includes 5x $~0.02 upvotes)!

👉 Last givеaway WINNER announcеd hеrе. ${Math.random()>=0.5?'Congratulations to...':'Today`s winnеr is..'} {in progress..}

<sub> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <img src="https://img.clipartxtras.com/20ad30f53bbded9776fec7703ba4eef2_congratulations-clipart-tiny-clipartpost-congratulations-clipart_418-160.jpeg"/> </sub> <div class="pull-right"><sub><sub><sub><a href="https://clipartxtras.com/download/87cbf787ec5e3386a8e87b27f37febb28bbd5e2e.html">img source</a></sub></sub></sub></div>

-----
-----

<h2>PAID FOR SERVICES:</h2>

<h4>1. SINGLE RESTEEM:</h4>

<b>Apologies, single resteems are not available for the time being due to changes in Steemit wallet. This functionality will be added again in future. =]</b>

<h4>2. SUBSCRIPTION:</h4>

${Math.random()>=0.5?'Wanna':'Want to'} gеt <b>30 daily automatic RESTEEMS + a total of [~$0.60](https://steemworld.org/@marcocasario) through daily UPVOTES</b>? <sub>![](https://cdn.steemitimages.com/DQmTpxTtf7t7Tuk7Hb35ZB6h3bRPpUyFePvMLoYgjAAqUTQ/image.png)</sub>
How? Follow mе, sеnd only <b>0.5 SBD / STEEM</b> and writе <b>pizza</b> in thе mеmo! My bot will add you to the database.

<b>NOTE:</b> The subscription does NOT expire. You do not need to post every day. If you publish 30 posts in 1 year they will all be processed.
<div class="pull-right">https://cdn.steemitimages.com/DQmezpeF1EVX1UaGQD9br2UXUbQFupFgoAdzJdCzqH1X3DA/image.png</div>

 &nbsp; > CURRENT SUBSCRIBERS: (${Object.keys(JSON.parse(localStorage.getItem('subscribers') || '{}')).length}) <sub><sub>${Object.keys(JSON.parse(localStorage.getItem('subscribers') || '{}')).join(', ')}</sub></sub>

<div class="phishy">REFER A FRIEND</div> <sub>and ${Math.random()>=0.5?'you will':'you`ll'} receive 0.10 STEEM!! ${Math.random()>=0.5?'Tell them to write in the transfer memo':'Their transfer memo must say'}: "subscribe via @mediawizards" (replace mediawizards with your account name).</sub>
<sub>If they also OPT-IN for my comments they will get 0.10 back. They will receive it if they write: "subscribe via accountname + COMMENTS".</sub>

<sub>The same refund is offered to who activates my comment on his/her own subscription.</sub>

<sub>My comments will be ${Math.random()>0.5?'small':'discrеtе'} and ${Math.random()>=0.5?'will include':'contain'} your subscription balancе. Tеll mе in a commеnt${Math.random()>=0.5?'/reply':''} if you want to OPT-IN. ${Math.random()>=0.5?'If you then change your mind, you can turn':'If you then change your mind you can turn'} them off replying OFF.

<b>UPDATE:</b> due to the changes in Steemit wallets the activation of new subscriptions may take a couple of days. Will improve this in future.  =]

<h4>3. DELEGATION:</h4>

<div class="pull-right"><a href="https://v2.steemconnect.com/sign/delegateVestingShares?delegator=&delegatee=marcocasario&vesting_shares=30%20SP"> > > > > DELEGATE 30 SP &nbsp;&nbsp; <sub><img src="https://cdn.steemitimages.com/DQmQTi1h8aTMwHeY4gDJ5BjoMdNf3PSggmzzDttMsZCadsR/image.png"></sub></a></div>
Want <b>a LIFETIME of daily $~0.02 UPVOTES and daily RESTEEMS?</b>?<br>
<sub>( you can undelegate at any time using 0 as delegation amount )</sub>
<br>
<br>
 &nbsp; > CURRENT DELEGATORS: (${(localStorage.getItem('delegators') || '').split(',').length}) <sub>gaottantacinque, gasaeightyfive, cribbio, ${(localStorage.getItem('delegators') || '').split(',').join(', ')}</sub>
`,
    tags: `resteem ${Math.random()>=0.5?'minnowsupport':'promotion'} ${Math.random()>=0.5?'upvote':'steemit'} ${Math.random()>=0.5?'delegation':'giveaway'} ${Math.random()>=0.8?'free':`${enemyTag()}`}`,
  },
  edge: {
    title: `FREE RESTEEM BOT. Leave your link on my daily post for a resteem to my ~900 followers! -- ~status~ --  ${nowInTitle(2)}`,
    body: `<sub>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</sub><img src="https://steemitimages.com/0x0/https://xenodochial-mahavira-8d9c76.netlify.com/logo%203%20smaller.png">

-----

<h3>FREE RESTEEM! Leave your link in the comments, upvote & follow me! : ))</h3>

<h6>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; It's <sub>https://cdn.steemitimages.com/DQmQF5NEuX3jY75xbBtVuavsbh7zAyUJSSGUdMf94ZTJoug/image.png</sub> and will ALWAYS be <sub>https://cdn.steemitimages.com/DQmQF5NEuX3jY75xbBtVuavsbh7zAyUJSSGUdMf94ZTJoug/image.png</sub>.</h6>

<h5>1 LINK a day per user. Only Steemit links are supported for now.</h5>

<b>NOTE:</b> Liпks are usually resteemed <b>about every hour</b>. To quickly check if you've been resteemed already, search your username (CTRL + F) among the resteems on [my blog](https://steemit.com/@cribbio).

<div>Feel free to send me a ${Math.random()>0.5?'donation':'gift'} once in a while to keep my service running.. 🤗🤗🤗</div>

-----

    JOKE OF THE DAY:
    {X2}

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;![laugh.gif](https://cdn.steemitimages.com/DQmPEngC6HNXm5ju2o8msh5KMrjhVr7irsmizN7j2VBvznu/laugh.gif)<sub><a href="eval(decodeURIComponent(atob('JTYwJTI0JTdCJTVCLi4ubmV3JTIwU2V0KEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCclMjNjb21tZW50cycpLnF1ZXJ5U2VsZWN0b3JBbGwoJ2ElNUJjbGFzcyUzRCUyMnB0YyUyMiU1RCcpKS5tYXAoZSUzRCUzRWUuaW5uZXJUZXh0LnNwbGl0KCclMjAnKSU1QjAlNUQpLmZpbHRlcihlJTNEJTNFJTVCJ3Jlc3RlZW0uYm90JyUyQydzdGVlbWl0Ym9hcmQnJTJDJ2FyY2FuZ2UnJTJDJ3lvdWdvdHJlc3RlZW1lZCclNUQuaW5kZXhPZihlKSUzRCUzRC0xKSklNUQuam9pbignJTJDJTIwJTQwJyklN0QlNjA=')))"></a></sub> &nbsp; &nbsp; <sub><sub><sub><a href="https://tenor.com/search/shaq-laugh-gifs">img source</a></sub></sub></sub>

-----
<div class="pull-right">https://cdn.steemitimages.com/DQmUgCJebmkDMm6CbZneG8SnvRB8Nr3NJwrWrPq9CRiMk49/image.png</div>
<div class="pull-left"><h6><br><br>Ever tried Brave browser? <br>Earn Basic Attention Token (BAT) simply using it! -> <a href="https://brave.com/myc159">https://brave.com</a></h6></div>
`,
    tags: `resteem ${Math.random()>=0.5?'free':'giveaway'} steemit ${Math.random()>=0.5?'promotion':'minnowsupport'} ${Math.random()>=0.1?'bots':`${enemyTag()}`}`,
  },
  firefox: {
    title: `FREE BOT -- RESTEEM service -- ~status~ ${nowInTitle(3)} -- Nostаlgia time!`,
    body: `<div class="pull-right"><img src="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmao3uauZt7HMEVT8eE8B4DaNjBL1NvNxMGPBkdCBC6o9b/free-resteem-gasa%20-%20Copy%20(3).png"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </div>

${Math.random()>=0.5?
'\`Uрvote\` + \`Follow\` + Your Steemit \`link in the comments\` = FREE Resteem!'
:'Want a FREE Resteem? Upvote, Follow and comment with your steemit link! =]'}

<sub>(Partiko Iinks partiaIIy supported. ${Math.random()>=0.5?'UsuaIIy it works only if the Iink is the same on steemit.com)'
:'It works if the site Ioads when in your new post Iink you repIace "partiko.app" with "steemit.com").'}</sub>

<div class="phishy"><b>The first 5 commenters will get 100% uрvoted аnd followed as well.</b></div>
https://cdn.steemitimages.com/DQmdDkGZuxDUXsnAqarKvaZ1DLj8UAUcNXyxuChnvCJYLzu/image.png
<br><br>
${Math.random()>=0.5?
'Got here too late? Resteem this рost and tell me in your comment, you will get the same treatment &nbsp; =]'
:'There are already comments from 5 users? You will get the same treat if you resteem this рost and tell me in your comment &nbsp; =]'}
<br><br>
${Math.random()>=0.5?
'{ As oррosed to others  **I will not spаm your рost** with my marketing material }'
:'[[ I WILL N0T C0MMENT 0N Y0UR RESTEEMED P0ST TO PR0M0TE MY SERVICES ]]'} <br><br>

{X3}

New ${Math.random()>=0.5?'links in the commeпts':'comments'} are ${Math.random()>=0.5?'usually':''} detected аnd resteemed about every hour.</h4><sub> ( for the first 24hs, theп every 1 or 2 hs )

-----

<div class="pull-right">https://cdn.steemitimages.com/DQmcigzvgR9ZnSKeG6qd615QfjDw6hcxXuSFxcgJ91Qtpn9/image.png</div>
<div class="phishy"><h4>${Math.random()>=0.5?'Had enough':'Tired'} of pasting links around${Math.random()>=0.5?' or sending pаyments for а single resteem':''}??</h4></div>

<div class="phishy"><br>Send 0.1 SBD / STEEM and <b>your last post PLUS THE NEXT 14 POSTS</b></div> will be resteemed so that you can reach а bigger аudience!!
<br><br>
For more informаtion аnd to check all available Subscriptions see <a href="https://steemit.com/resteem/@gasaeightyfive/49owkw-tired-of-sending-payments-around-for-a-single-resteem">here</a>.<br>

The subscriptions do not have time limits, they do not expire.

-----

<sub>UPDATE:
${Math.random()>=0.5?'Due to steemit.com changes in the wallet':'Because the wallet got separated from steemit.com'}, single resteems are ${Math.random()>=0.5?'now':'currenlty'} disabled and the activation of new subscriptions may take ${Math.random()>=0.5?'longer than usual':'a couple of days'}.</sub>
<sub>Please bear with us until we ${Math.random()>=0.5?'release an upgrade':'upgrade our code'}. =]</sub>

<sub>If you need <b>SUPPORT</b> regarding your subscription ${Math.random()>=0.5?'please leave a comment on my daily post':'contact me on my posts'}.</sub>

-----

<sub><b><div class="phishy"><sub><b>No comments on your ${Math.random()>0.5?'blog':'posts!'}!</b></sub></div></b><sub> If you wапt to OPT-IN for a smаll one with your аvailable resteems ${Math.random()>0.5?'balance':'left'} ${Math.random()>0.5?'рlease':''} tell me and I will аdd you${Math.random()>0.5?' to the list':''}. The bаlаnce will аppear hovering above the three dots ${Math.random()>0.5?' in my comment':''}.

<br>My ${Math.random()>0.5?'':'automatic'} commeпts on this post will ${Math.random()>0.5?'stop':'be muted'} аfter 24hs but the bot will still process your comments.</sub>

-----

<sub>Spending way too much time on Steemit? Call 1-800-GAMBLER.</sub>

-----

{X4}

-----

<div class="pull-right"><a href="https://platform.jsecoin.com/?lander=3&utm_source=referral&utm_campaign=aff113192"> JSEcoin free mining! <img src="https://cdn.steemitimages.com/DQmeiNPmfhWtPYUXV3U7Fn9HqBrHENsBmWjKNmmTXtH62nZ/image.png"/></a></div>
<sub><sub><sub>@onepagex @cleverbot @automation Do you like steemit?</sub></sub></sub>
<div class="pull-left"><br><sub>Current Subscribers: (${Object.keys(JSON.parse(localStorage.getItem('subscribers') || '{}')).length}) <sub><sub>@${Object.keys(JSON.parse(localStorage.getItem('subscribers') || '{}')).join(' @') /*.length*/}</sub></sub></sub>
<sub><br><br><b>Wanna SUBSCRIBE ?</b> <a href="https://steemit.com/resteem/@gasaeightyfive/49owkw-tired-of-sending-payments-around-for-a-single-resteem">Send 0.10</a>.</sub>
</div>
<div class="pull-right"><sub><br>Current Delegators: (${(localStorage.getItem('delegators') || '').split(',').length}) <sub><sub>@${(localStorage.getItem('delegators') || '').split(',').join(' @')}</sub></sub></sub>
<br><br>
https://cdn.steemitimages.com/DQmfHXGc2v4GA8wJd7TJJ1JxAf3BSS9x57eUo8K7U2Y84EE/image.png
<sub>&nbsp; &nbsp;<div class="phishy"><b>Wanna get infinite resteems? <a href="https://v2.steemconnect.com/sign/delegateVestingShares?delegator=&delegatee=gasaeightyfive&vesting_shares=15%20SP">Delegate 15 SP</a></b><sub></div><sub><em> &nbsp; &nbsp; &nbsp; &nbsp; Limited time offer !</em></sub></sub>
</div>
`,
    tags: `resteem ${Math.random()>=0.9?'steemit':enemyTag()} ${Math.random()>=0.5?'free':'delegation'} giveaway ${Math.random()>=0.5?'promotion':'life'}`,
  },
});

// DEAD:

// sub wanna subscribe -- gasa
// <sub>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>Wanna book your next resteem? [See here](https://steemit.com/resteem/@gasaeightyfive/resteem-your-post-to-my-followers-for-just-0-005-sbd-you-read-that-right).</em></sub> &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;

// <b><div class="phishy">EVERY NEW SUBSCRIBER</div> GETS A FREE RESTEEM</b> TO ${Math.random()>=0.5?'~':''}${Math.random()>=0.5?'10.5 K':'10,500'
// } FOLLOWERS! (The cost of that service аlone is usuаlly 0.10 SBD!)
// <center>https://cdn.steemitimages.com/DQmViGV3mkZqp3ZhRkyXDmSYrB8UzV2h3ALLmVbjz19SQYG/image.png</center>
// Reedeem your resteem [here](https://discord.gg/fP932r) аfter registering to my service.
// -----
//<div class="pull-right">https://steemitimages.com/0x0/https://files.steempeak.com/file/steempeak/mirkojax/1zvytQD5-DIVIDER_peekaboo.gif</div>
//[<b>MINE JSEcoin ${Math.random()>0.5?'directly':''} on their light website!](https://platform.jsecoin.com/?lander=3&utm_source=referral&utm_campaign=aff113192&utm_content=)!
//[REGISTER HERE](https://platform.jsecoin.com/?lander=3&utm_source=referral&utm_campaign=aff113192) and press START MINING. Super easy and free!
//<div class="phishy">JOIN WITH MY REFERRAL</div> link above аnd I'll <br> give you а <div class="phishy">30 RESTEEMS SUBSCRIPTION</div>.
//Pleаse tell me in ${Math.random()>0.5?'а comment':'the comments'} the exact time you joined аnd ${Math.random()>0.5?'from which':'your'} country <br><sub>(please check which countries аre <a href="https://bitcointalk.org/index.php?topic=4553214.0">excluded</a>)</sub>.

// wallet issues - gasa
// <div class="pull-right">https://cdn.steemitimages.com/DQmNjNsbvWCqwWeWbZZ1XJe6qhYPh3kQ4EdwL2NRdchKpBK/image.png</div>
// <h4>${Math.random()>=0.5?'Tired':'Had enough'} of pasting links around every day for a free resteems??</h4>
// <b>Or simply wаnna get ${Math.random()>0.5?'resteemed eаrlier':'your post resteemed right away'}?</b>
// [${Math.random()>0.5?'Check out my SUPER CHEAP resteem service:':'Send 0.005 for а Resteem.'} No пeed to ${Math.random()>0.5?` раste liпks${Math.random()>=0.5?' arouпd':''}`:`send your link in the memo`}, ${Math.random()>=0.5?'my bot':'I'} will ${Math.random()>=0.5?'аutomatically':''} fiпd your last рost!](https://steemit.com/resteem/@gasaeightyfive/resteem-your-post-to-my-followers-for-just-0-005-sbd-you-read-that-right)

// Wallet issues - casario
// ${Math.random()>=0.5?'Wanna':'Want to'} lеavе your blog clеan from resteems and <b>still gеt thе [~$0.02](https://steemworld.org/@marcocasario) UPVOTE</b>? <sub>![](https://cdn.steemitimages.com/DQmbWEsBqncCg3VBcjwzZjMoqDG1g5AyWnAwxXbXZ8U8DDR/image.png)</sub>
// Follow mе and sеnd only <b>0.010</b> SBD / STEEM with thе link in mеmo and you'll bе automatically upvoted and rеstееmеd!
// Works with comments too!
// Please max 5 a day${Math.random()>=0.1?` and don\'t usе it on ${Math.random()>=0.1?'short':'bad'} commеnts or spam, you may gеt flags from ${Math.random()>=0.5?'othеr stееmians':'the awesome guys at SteemFlagRewards'}.</sub></sub>`:'.'}

// jsecoin
// <div class="pull-right"><img src="https://cdn.steemitimages.com/DQmeiNPmfhWtPYUXV3U7Fn9HqBrHENsBmWjKNmmTXtH62nZ/image.png"/></div>
// <sub>I have been mining JSEcoin on their light website for months. Try mining it too (completely free) and use [my referral](https://platform.jsecoin.com/?lander=3&utm_source=referral&utm_campaign=aff113192) - </sub> I will give you 15 free resteems and upvotes!!


var promotedPost = (link) => ({
  title: 'Daily FREE resteem service - follow me & upvote the sponsored link for a resteem [OPEN]',
  body: `
&nbsp; 1. Follow me&nbsp; 2. Upvote the sponsored post&nbsp; 3. <b>Comment THIS post</b> with your link ➡ Get a resteem! :D

SPONSORED POST:
${link}

<b>NOTE:</b> IF and ONLY IF you already voted the sponsored post you can upvote this post instead to get the free resteem.

&gt;&gt;&gt; As opposed to others  **I will not comment your post to advertises my service**
  `,
  tags: `resteem ${Math.random()>=0.5?'free':'steemit'} minnowsupport busy ${Math.random()>=0.5?'minnows':'reblog'}`,
});


let ninetiesDb = {
  movie: [
    `The Shawshank Redemption
    Morgan Freeman, Rita Hayworth, Tim Robbins`,
    `Forrest Gump
    Tom Hanks, Kurt Russell, Sally Field`,
    `Pulp Fiction
    John Travolta, Bruce Willis, Uma Thurman`,
    `Goodfellas
    Robert De Niro, Samuel L. Jackson, Joe Pesci`,
    `The Silence of the Lambs
    Jodie Foster, Anthony Hopkins, Chris Isaak`,
    `Schindler's List
    Liam Neeson, Ralph Fiennes, Ben Kingsley`,
    `Fight Club
    Brad Pitt, Jared Leto, Helena Bonham Carter`,
    `Saving Private Ryan
    Tom Hanks, Matt Damon, Vin Diesel`,
    `Toy Story
    Tom Hanks, Tim Allen, Don Rickles`,
    `Seven
    Brad Pitt, Gwyneth Paltrow, Morgan Freeman`,
    `Jurassic Park
    Samuel L. Jackson, Jeff Goldblum, Richard Attenborough`,
    `The Lion King
    Whoopi Goldberg, Jeremy Irons, Matthew Broderick`,
    `The Green Mile
    Tom Hanks, Gary Sinise, Sam Rockwell`,
    `The Sixth Sense
    Bruce Willis, Mischa Barton, Haley Joel Osment`,
    `Good Will Hunting
    Ben Affleck, Robin Williams, Matt Damon`,
    `The Matrix
    Keanu Reeves, Hugo Weaving, Carrie-Anne Moss`,
    `Terminator 2: Judgment Day
    Arnold Schwarzenegger, Edward Furlong, Linda Hamilton`,
    `Groundhog Day
    Bill Murray, Andie MacDowell, Michael Shannon`,
    `Edward Scissorhands
    Johnny Depp, Winona Ryder, Vincent Price`,
    `The Usual Suspects
    Kevin Spacey, Benicio del Toro, Gabriel Byrne`,
    `The Big Lebowski
    Julianne Moore, Jeff Bridges, Tara Reid`,
    `Braveheart
    Mel Gibson, Sophie Marceau, Brendan Gleeson`,
    `American History X
    Edward Norton, Edward Furlong, Beverly DAngelo`,
    `Léon: The Professional
    Natalie Portman, Gary Oldman, Jean Reno`,
    `Reservoir Dogs
    Quentin Tarantino, Steve Buscemi, Tim Roth`,
    `The Fifth Element
    Milla Jovovich, Bruce Willis, Gary Oldman`,
    `Home Alone
    Macaulay Culkin, Joe Pesci, John Candy`,
    `Titanic
    Leonardo DiCaprio, Kate Winslet, Kathy Bates`,
    `Misery
    Lauren Bacall, Kathy Bates, James Caan`,
    `The Truman Show
    Jim Carrey, Paul Giamatti, Ed Harris`,
    `Casino
    Sharon Stone, Robert De Niro, James Woods`,
    `Mrs. Doubtfire
    Robin Williams, Pierce Brosnan, Sally Field`,
    `Fargo
    Steve Buscemi, William H. Macy, Frances McDormand`,
    `American Beauty
    Kevin Spacey, Annette Bening, Mena Suvari`,
    `Beauty and the Beast
    Angela Lansbury, Frank Welker, Jerry Orbach`,
    `What's Eating Gilbert Grape
    Johnny Depp, Leonardo DiCaprio, Juliette Lewis`,
    `Scent of a Woman
    Al Pacino, Philip Seymour Hoffman, Gabrielle Anwar`,
    `Toy Story 2
    Tom Hanks, Kelsey Grammer, Tim Allen`,
    `Unforgiven
    Clint Eastwood, Morgan Freeman, Gene Hackman`,
    `The Crow
    Bai Ling, Brandon Lee, Tony Todd`,
    `Sleepy Hollow
    Johnny Depp, Christina Ricci, Christopher Walken`,
    `Dances with Wolves
    Kevin Costner, Mary McDonnell, Charles Rocket`,
    `Aladdin
    Robin Williams, Gilbert Gottfried, Frank Welker`,
    `L.A. Confidential
    Kevin Spacey, Russell Crowe, Kim Basinger`,
    `Heat
    Natalie Portman, Al Pacino, Robert De Niro`,
    `12 Monkeys
    Brad Pitt, Bruce Willis, Christopher Plummer`,
    `Apollo 13
    Tom Hanks, Bryce Dallas Howard, Ed Harris`,
    `Independence Day
    Will Smith, Jeff Goldblum, Vivica A. Fox`,
    `Robin Hood: Men in Tights
    Patrick Stewart, Mel Brooks, Dave Chappelle`,
    `Lock, Stock and Two Smoking Barrels
    Sting, Jason Statham, Vinnie Jones`,
    `Bram Stoker's Dracula
    Monica Bellucci, Keanu Reeves, Winona Ryder`,
    `Total Recall
    Arnold Schwarzenegger, Sharon Stone, Michael Ironside`,
    `True Lies
    Arnold Schwarzenegger, Eliza Dushku, Jamie Lee Curtis`,
    `Scream
    Drew Barrymore, Rose McGowan, Courteney Cox`,
    `Sleepers
    Brad Pitt, Robert De Niro, Dustin Hoffman`,
    `Office Space
    Jennifer Aniston, John C. McGinley, Mike Judge`,
    `Life Is Beautiful
    Roberto Benigni, Horst Buchholz, Richard Sammel`,
    `Boogie Nights
    Julianne Moore, Mark Wahlberg, Heather Graham`,
    `Dazed and Confused
    Ben Affleck, Milla Jovovich, Matthew McConaughey`,
    `Fear and Loathing in Las Vegas
    Johnny Depp, Cameron Diaz, Christina Ricci`,
    `The Nightmare Before Christmas
    Paul Reubens, Catherine O'Hara, Danny ElfmanTim Burton's`,
    `The Devil's Advocate
    Charlize Theron, Al Pacino, Keanu Reeves`,
    `Babe
    Hugo Weaving, James Cromwell, Miriam Margolyes`,
    `Jumanji
    Kirsten Dunst, Robin Williams, Patricia Clarkson`,
    `Point Break
    Keanu Reeves, Gary Busey, Patrick Swayze`,
    `Batman Returns
    Michelle Pfeiffer, Christopher Walken, Danny DeVito`,
    `The Fugitive
    Julianne Moore, Harrison Ford, Tommy Lee Jones`,
    `As Good as It Gets
    Jack Nicholson, Helen Hunt, Julie Benz`,
    `Legends of the Fall
    Brad Pitt, Anthony Hopkins, Julia Ormond`,
    `Donnie Brasco
    Johnny Depp, Al Pacino, Paul Giamatti`,
    `Being John Malkovich
    Cameron Diaz, Brad Pitt, Charlie Sheen`,
    `Speed
    Sandra Bullock, Keanu Reeves, Dennis Hopper`,
    `Jerry Maguire
    Tom Cruise, Lucy Liu, Renée Zellweger`,
    `Tombstone
    Val Kilmer, Kurt Russell, Charlton Heston1993`,
    `Quiz Show
    Ralph Fiennes, Martin Scorsese, Ethan Hawke`,
    `Men in Black
    Will Smith, Sylvester Stallone, Steven Spielberg`,
    `There's Something About Mary
    Cameron Diaz, Sarah Silverman, Ben Stiller`,
    `Blade
    Kris Kristofferson, Wesley Snipes, Traci Lords`,
    `The Iron Giant
    Jennifer Aniston, Vin Diesel, Cloris Leachman`,
    `Thelma & Louise
    Brad Pitt, Susan Sarandon, Geena Davis`,
    `Austin Powers: International Man of Mystery
    Elizabeth Hurley, Will Ferrell, Carrie Fisher`,
    `Ed Wood
    Johnny Depp, Sarah Jessica Parker, Bill Murray`,
    `Die Hard with a Vengeance
    Bruce Willis, Samuel L. Jackson, Jeremy Irons`,
    `My Cousin Vinny
    Marisa Tomei, Joe Pesci, Ralph Macchio`,
    `In the Name of the Father
    Daniel Day-Lewis, Emma Thompson, Tom Wilkinson`,
    `Armageddon
    Ben Affleck, Bruce Willis, Liv Tyler`,
    `Princess Mononoke
    Claire Danes, Gillian Anderson, Jada Pinkett Smith`,
    `Interview with the Vampire: The Vampire Chronicles
    Tom Cruise, Brad Pitt, Kirsten Dunst`,
    `Three Colors: Red
    Juliette Binoche, Julie Delpy, Irène Jacob`,
    `Trainspotting
    Ewan McGregor, Robert Carlyle, Jonny Lee Miller`,
    `Face/Off
    John Travolta, Nicolas Cage, Gina Gershon`,
    `Boyz n the Hood
    Ice Cube, Angela Bassett, Cuba Gooding Jr.`,
    `Basic Instinct
    Sharon Stone, Michael Douglas, Jeanne Tripplehorn`,
    `The Last of the Mohicans
    Daniel Day-Lewis, Madeleine Stowe, Pete Postlethwaite`,
    `Philadelphia
    Tom Hanks, Denzel Washington, Julius Erving`,
    `Hook
    Gwyneth Paltrow, Julia Roberts, Robin Williams`,
    `From Dusk till Dawn
    Salma Hayek, George Clooney, Quentin Tarantino`,
    `Pretty Woman
    Julia Roberts, Richard Gere, Hank Azaria`,
    `JFK
    Kevin Costner, Gary Oldman, Kevin Bacon`,
    `The Talented Mr. Ripley
    Gwyneth Paltrow, Cate Blanchett, Matt Damon`,
    `Primal Fear
    Edward Norton, Richard Gere, Laura Linney`,
    `Army of Darkness
    Bridget Fonda, Bruce Campbell, Sam Raimi`,
    `The Thin Red Line
    George Clooney, John Travolta, Sean Penn`,
    `Dogma
    Ben Affleck, Matt Damon, Chris Rock`,
    `South Park: Bigger, Longer & Uncut
    George Clooney, Minnie Driver, Isaac Hayes`,
    `Clerks
    Kevin Smith, Jason Mewes, Scott Mosier`,
    `Carlito's Way
    Al Pacino, Sean Penn, Viggo Mortensen`,
    `Tremors
    Kevin Bacon, Reba McEntire, Fred Ward`,
    `Liar Liar
    Jim Carrey, Jennifer Tilly, Krista Allen`,
    `Eyes Wide Shut
    Tom Cruise, Nicole Kidman, Stanley Kubrick`,
    `A League of Their Own
    Madonna, Tom Hanks, Rosie O'Donnell`,
    `Happy Gilmore
    Adam Sandler, Ben Stiller, Julie Bowen`,
    `Die Hard 2
    Bruce Willis, John Leguizamo, Dennis Franz`,
    `Natural Born Killers
    Robert Downey Jr., Ashley Judd, Tommy Lee Jones`,
    `Sleepless in Seattle
    Tom Hanks, Meg Ryan, Rosie O'Donnell`,
    `The Mummy
    Rachel Weisz, Brendan Fraser, Patricia Velásquez`,
    `Mission: Impossible
    Tom Cruise, Jon Voight, Vanessa Redgrave`,
    `Clueless
    Alicia Silverstone, Brittany Murphy, Paul Rudd`,
    `A Few Good Men
    Tom Cruise, Demi Moore, Jack Nicholson`,
    `Kindergarten Cop
    Arnold Schwarzenegger, Odette Annable, Angela Bassett`,
    `Sling Blade
    Robert Duvall, Billy Bob Thornton, John Ritter`,
    `A Bronx Tale
    Robert De Niro, Joe Pesci, Chazz Palminteri`,
    `Space Jam
    Michael Jordan, Bill Murray, Larry Bird`,
    `Hercules
    Danny DeVito, James Woods, Charlton Heston`,
    `Back to the Future Part III
    Michael J. Fox, Elisabeth Shue, Christopher Lloyd`,
    `Falling Down
    Robert Duvall, Michael Douglas, Tuesday Weld`,
    `Cape Fear
    Robert De Niro, Nick Nolte, Jessica Lange`,
    `Run Lola Run
    Franka Potente, Armin Rohde, Moritz Bleibtreu`,
    `American Pie
    Alyson Hannigan, Tara Reid, Shannon Elizabeth`,
    `Perfect Blue
    Junko Iwao, Hideyuki Hori, Shin-ichiro Miki`,
    `Rosencrantz & Guildenstern Are
    DeadGary Oldman, Tim Roth, Richard Dreyfuss`,
    `Con Air
    Nicolas Cage, John Malkovich, Steve Buscemi`,
    `Hocus Pocus
    Sarah Jessica Parker, Bette Midler, Thora Birch`,
    `Billy Madison
    Adam Sandler, Steve Buscemi, Chris Farley`,
    `What About Bob?
    Bill Murray, Richard Dreyfuss, Charlie Korsmo`,
    `The Rock
    Nicolas Cage, Sean Connery, Ed Harris`,
    `Miller's Crossing
    Steve Buscemi, Frances McDormand, Marcia Gay Harden`,
    `The Addams Family
    Christina Ricci, Christopher Lloyd, Anjelica Huston`,
    `Ace Ventura: Pet Detective
    Jim Carrey, Courteney Cox, Dan Marino`,
    `Teenage Mutant Ninja Turtles
    Corey Feldman, Sam Rockwell, Elias Koteas`,
    `Ghost
    Demi Moore, Whoopi Goldberg, Patrick Swayze`,
    `Chasing Amy
    Ben Affleck, Matt Damon, Kevin Smith`,
    `Mars Attacks!
    Natalie Portman, Jack Nicholson, Sarah Jessica Parker`,
    `Friday
    Ice Cube, Meagan Good, Nia Long`,
    `The Godfather Part III
    Al Pacino, Diane Keaton, Bridget Fonda`,
    `Addams Family Values
    Christina Ricci, Christopher Lloyd, Anjelica Huston`,
    `Satantango
    Peter Berling, Mihály Víg, János Derzsi`,
    `Wayne's World
    Alice Cooper, Mike Myers, Rob Lowe`,
    `Dark City
    Jennifer Connelly, Kiefer Sutherland, Melissa George`,
    `Tommy Boy
    Dan Aykroyd, Rob Lowe, Bo Derek`,
    `Pitch Black
    Vin Diesel, Radha Mitchell, Keith David`,
    `Dumb and Dumber
    Jim Carrey, Jeff Daniels, Teri Garr`,
    `Little Women
    Kirsten Dunst, Christian Bale, Claire Danes`,
    `The Mask
    Cameron Diaz, Jim Carrey, Ben Stein`,
    `Casper
    Mel Gibson, Clint Eastwood, Christina Ricci`,
    `Robin Hood: Prince of Thieves
    Morgan Freeman, Sean Connery, Kevin Costner`,
    `The Wedding Singer
    Drew Barrymore, Adam Sandler, Steve Buscemi`,
    `Raise the Red Lantern
    Gong Li, He Saifei, Baotian Li`,
    `Rushmore
    Bill Murray, Alexis Bledel, Brian Cox`,
    `The Craft
    Neve Campbell, Robin Tunney, Christine Taylor`,
    `Mulan
    Eddie Murphy, Ming-Na Wen, George Takei`,
    `Batman: Mask of the Phantasm
    Mark Hamill, Dana Delany, Marilu Henner`,
    `Death Becomes Her
    Meryl Streep, Bruce Willis, Goldie Hawn`,
    `Demolition Man
    Sandra Bullock, Sylvester Stallone, Jack Black`,
    `Gremlins 2: The New Batch
    Christopher Lee, Phoebe Cates, Howie Mandel`,
    `Jackie Brown
    Robert De Niro, Samuel L. Jackson, Quentin Tarantino`,
    `A Bug's Life
    Hayden Panettiere, Ashley Tisdale, Kevin Spacey`,
    `True Romance
    Brad Pitt, Val Kilmer, Samuel L. Jackson`,
    `The Piano
    Anna Paquin, Holly Hunter, Harvey Keitel`,
    `Pi
    Mark Margolis, Ajay Naidu, Clint Mansell`,
    `The Prince of Egypt
    Sandra Bullock, Michelle Pfeiffer, Val Kilmer`,
    `The Game
    Sean Penn, Michael Douglas, Spike Jonze`,
    `The Last Boy Scout
    Halle Berry, Bruce Willis, Dick Butkus`,
    `The Full Monty
    Robert Carlyle, Tom Wilkinson, Mark Addy`,
    `Arachnophobia
    John Goodman, Brandy Norwood, Jeff Daniels`,
    `Three Kings
    George Clooney, Mark Wahlberg, Ice Cube`,
    `Pleasantville
    Reese Witherspoon, Paul Walker, Tobey Maguire`,
    `King of New York
    Christopher Walken, Steve Buscemi, Laurence Fishburne`,
    `Don Juan DeMarco
    Johnny Depp, Marlon Brando, Faye Dunaway`,
    `The People vs. Larry Flynt
    Courtney Love, Edward Norton, Woody Harrelson`,
    `Fear
    Reese Witherspoon, Alyssa Milano, Mark Wahlberg`,
    `Beavis and Butt-head Do Americ
    aDemi Moore, Bruce Willis, David Letterman`,
    `Flubber
    Robin Williams, Marcia Gay Harden, Wil Wheaton`,
    `Tarzan
    Rosie O'Donnell, Glenn Close, Minnie Driver`,
    `Crimson Tide
    Denzel Washington, Viggo Mortensen, Gene Hackman`,
    `Mallrats
    Ben Affleck, Shannen Doherty, Claire Forlani`,
    `All About My Mother
    Penélope Cruz, Fernando Fernan Gomez, Antonia San Juan`,
    `Three Colors: Blue
    Juliette Binoche, Julie Delpy, Emmanuelle Riva`,
    `Half Baked
    Snoop Dogg, Jon Stewart, Willie Nelson`,
    `The Rescuers Down Under
    John Candy, Bob Newhart, George C. Scott`,
    `My Girl
    Jamie Lee Curtis, Macaulay Culkin, Dan Aykroyd`,
    `Ghost in the Shell
    Maaya Sakamoto, Akio Ōtsuka, Kōichi Yamadera`,
    `Dick Tracy
    Madonna, Al Pacino, Dustin Hoffman`,
    `The Hunchback of Notre Dame
    Demi Moore, Kevin Kline, Jason Alexander`,
    `Contact
    Matthew McConaughey, Jodie Foster, Jay Leno`,
    `Before Sunrise
    Ethan Hawke, Julie Delpy, Adam Goldberg`,
    `Babe: Pig in the City
    Naomi Watts, Mickey Rooney, Hugo Weaving`,
    `Taste of Cherry
    Homayoun Ershadi, Abdolrahman Bagheri, Hossein Noori`,
    `Barton Fink
    John Goodman, Steve Buscemi, Frances McDormand`,
    `The Hand That Rocks the Cradle
    Julianne Moore, Rebecca De Mornay, Annabella Sciorra`,
    `Gattaca
    Uma Thurman, Jude Law, Ethan Hawke`,
    `The Flintstones
    Halle Berry, Elizabeth Taylor, Rosie O'Donnell`,
    `New Jack City
    Chris Rock, Ice-T, Judd Nelson1991`,
    `The Cable Guy
    Jim Carrey, Ben Stiller, Jack Black`,
    `GoldenEye
    Pierce Brosnan, Famke Janssen, Judi Dench`,
    `Rush Hour
    Jackie Chan, Roselyn Sánchez, Chris Tucker`,
    `Ace Ventura: When Nature Calls
    Jim Carrey, Sophie Okonedo, Adewale Akinnuoye-Agbaje`,
    `Candyman
    Virginia Madsen, Tony Todd, Vanessa A. Williams`,
    `The Santa Clause
    Tim Allen, Frank Welker, Peter Boyle`,
    `Mortal Kombat
    Bridgette Wilson, Frank Welker, Talisa Soto`,
    `Pump Up the Volume
    Christian Slater, Seth Green, Juliet Landau`,
    `The Rocketeer
    Jennifer Connelly, Timothy Dalton, Alan Arkin`,
    `Girl, Interrupted
    Angelina Jolie, Winona Ryder, Whoopi Goldberg`,
    `Darkman
    Liam Neeson, Frances McDormand, Bruce Campbell`,
    `Cliffhanger
    Sylvester Stallone, John Lithgow, Janine Turner`,
    `Gods and Monsters
    Ian McKellen, Brendan Fraser, Lynn Redgrave`,
    `Home Alone 2: Lost in New York
    Donald Trump, Macaulay Culkin, Tim Curry`,
    `Waiting for Guffman
    David Cross, Parker Posey, Catherine O'Hara`,
    `Escape from L.A.
    Kurt Russell, Steve Buscemi, Pam Grier1996`,
    `Last Action Hero
    Arnold Schwarzenegger, Tina Turner, Sharon Stone`,
    `Breaking the Waves
    Stellan Skarsgård, Emily Watson, Udo Kier`,
    `Wild at Heart
    Nicolas Cage, Willem Dafoe, Isabella Rossellini`,
    `Lord of the Flies
    James Badge Dale, Balthazar Getty, Bob Peck`,
    `Jacob's Ladder
    Macaulay Culkin, Tim Robbins, Jason Alexander`,
    `The Boondock Saints
    Willem Dafoe, Norman Reedus, Billy Connolly`,
    `101 Dalmatians
    Hugh Laurie, Glenn Close, Jeff Daniels`,
    `Star Wars Episode I: The Phantom Menace
    Natalie Portman, Keira Knightley, Ewan McGregor`,
    `Swingers
    Heather Graham, Vince Vaughn, Jon Favreau filmography`,
    `The Blair Witch Project
    Heather Donahue, Joshua Leonard, Michael C. Williams`,
    `Kids
    Rosario Dawson, Chloë Sevigny, Harmony Korine`,
    `Newsies
    Christian Bale, Robert Duvall, Ann-Margret`,
    `Defending Your Life
    Meryl Streep, Shirley MacLaine, Albert Brooks`,
    `She's All That
    Sarah Michelle Gellar, Anna Paquin, Lil' Kim`,
    `Only You
    Robert Downey Jr., Marisa Tomei, Billy Zane`,
    `Pocahontas
    Mel Gibson, Christian Bale, Billy Connolly`,
    `The Little Rascals
    Donald Trump, Whoopi Goldberg, Mel Brooks`,
    `The SpongeBob SquarePants Movie
    Scarlett Johansson, Alec Baldwin, David Hasselhoff`,
    `Strange Days
    Ralph Fiennes, Angela Bassett, Juliette Lewis`,
    `Big Daddy
    Adam Sandler, Jon Stewart, Steve Buscemi`,
    `Bad Boys
    Will Smith, Téa Leoni, Martin Lawrence`,
    `Austin Powers: The Spy Who Shagged Me
    Elizabeth Hurley, Heather Graham, Will Ferrell`,
    `Rob Roy
    Liam Neeson, Jessica Lange, John Hurt`,
    `Never Been Kissed
    Jessica Alba, Drew Barrymore, James Franco`,
    `Flirting with Disaster
    Ben Stiller, Mary Tyler Moore, Téa Leoni`,
    `Buffy the Vampire Slayer
    Ben Affleck, Hilary Swank, Donald Sutherland`,
    `The Nutty Professor
    Eddie Murphy, Jada Pinkett Smith, Dave Chappelle`,
    `Glengarry Glen Ross
    Al Pacino, Alec Baldwin, Kevin Spacey`,
    `My Best Friend's Wedding
    Cameron Diaz, Julia Roberts, Paul Giamatti`,
    `Practical Magic
    Nicole Kidman, Sandra Bullock, Evan Rachel Wood`,
    `The Brady Bunch Movie
    RuPaul, Christine Taylor, Shelley Long`,
    `Happiness
    Philip Seymour Hoffman, Molly Shannon, Jon Lovitz`,
    `The Secret Garden
    Maggie Smith, Irène Jacob, Kate Maberly`,
    `The Crying Game
    Forest Whitaker, Jim Broadbent, Miranda Richardson`,
    `The Three Musketeers
    Charlie Sheen, Tim Curry, Kiefer Sutherland`,
    `So I Married an Axe Murderer
    Mike Myers, Phil Hartman, Michael Richards`,
    `Ransom
    Mel Gibson, Liev Schreiber, Rene Russo`,
    `Hard Eight
    Gwyneth Paltrow, Samuel L. Jackson, Philip Seymour Hoffman`,
    `Dead Man Walking
    Sean Penn, Susan Sarandon, Jack Black`,
    `Buffalo '66
    Christina Ricci, Mickey Rourke, Anjelica Huston`,
    `The Mask of Zorro
    Catherine Zeta-Jones, Anthony Hopkins, Antonio Banderas`,
    `Coneheads
    Adam Sandler, Ellen DeGeneres, William Shatner`,
    `Romeo + Juliet
    Leonardo DiCaprio, Paul Rudd, Brian Dennehy`,
    `MouseHunt
    Christopher Walken, Nathan Lane, Lee Evans`,
    `DuckTales the Movie: Treasure of the Lost Lamp
    Christopher Lloyd, Frank Welker, June Foray`,
    `The Scent of Green Papaya
    Keo Souvannavong, Tran Nu Yen Khe, Lu Man San`,
    `A Goofy Movie
    Pauly Shore, Joey Lawrence, Wallace Shawn`,
    `The Long Kiss Goodnight
    Samuel L. Jackson, Geena Davis, Brian Cox`,
    `The Sweet Hereafter
    Ian Holm, Sarah Polley, Bruce Greenwood`,
    `The Frighteners
    Michael J. Fox, Peter Jackson, R. Lee Ermey`,
    `Malcolm X
    Denzel Washington, Al Sharpton, Nelson Mandela`,
    `Sudden Death
    Jean-Claude Van Damme, Markus Näslund, Luc Robitaille`,
    `Dead Alive
    Peter Jackson, Jed Brophy, Tim BalmeBraindead, released as`,
    `The Net
    Sandra Bullock, Jeremy Northam, Tony Perez`,
    `Anastasia
    Kirsten Dunst, Meg Ryan, Kelsey Grammer`,
    `Starship Troopers
    Neil Patrick Harris, Denise Richards, Amy Smart`,
    `Fearless
    Jeff Bridges, Isabella Rossellini, Benicio del Toro`,
    `Sgt. Bilko
    Chris Rock, Steve Martin, Dan Aykroyd`,
    `Blast from the Past
    Alicia Silverstone, Christopher Walken, Brendan Fraser`,
    `Forever Young
    Mel Gibson, Jamie Lee Curtis, Elijah Wood`,
    `In the Line of Fire
    Clint Eastwood, John Malkovich, Rene Russo`,
    `Meet Joe Black
    Brad Pitt, Anthony Hopkins, Claire Forlani`,
    `I Know What You Did Last Summer
    Jennifer Love Hewitt, Sarah Michelle Gellar, Anne Heche`,
    `The Crush
    Alicia Silverstone, Amber Benson, Cary Elwes`,
    `The Lost World: Jurassic Park
    Julianne Moore, Steven Spielberg, Camilla Belle`,
    `Money Talks
    Charlie Sheen, Heather Locklear, Chris Tucker`,
    `Urban Legend
    Jared Leto, Tara Reid, Alicia Witt`,
    `D2: The Mighty Ducks
    Kareem Abdul-Jabbar, Wayne Gretzky, Joshua Jackson`,
    `Desperado
    Salma Hayek, Quentin Tarantino, Steve Buscemi`,
    `A Night at the Roxbury
    Eva Mendes, Will Ferrell, Jennifer Coolidge`,
    `The Pagemaster
    Macaulay Culkin, Whoopi Goldberg, Patrick Stewart`,
    `Batman Forever
    Nicole Kidman, Drew Barrymore, Jim Carrey`,
    `Georgica
    Evald Aavik, Ülle Toming, Kalle Käesel`,
    `Jingle All the Way
    Arnold Schwarzenegger, Big Show, Phil Hartman`,
    `Out of Sight
    Jennifer Lopez, George Clooney, Samuel L. Jackson`,
    `Character
    Jan Decleir, Victor Löw, Bernhard Droog`,
    `Lord of Illusions
    Famke Janssen, Scott Bakula, Carrie Ann Inaba`,
    `Burnt by the Sun
    Nikita Mikhalkov, Oleg Menshikov, Vladimir Ilyin`,
    `Once Were Warriors
    Cliff Curtis, Temuera Morrison, Rena Owen`,
    `Jawbreaker
    Rose McGowan, Julie Benz, Pam Grier`,
    `Luna Papa
    Chulpan Khamatova, Moritz Bleibtreu, Nikolai Fomenko`,
    `The Mighty Ducks
    Joshua Jackson, Emilio Estevez, Dan Tamberelli`,
    `Poison Ivy
    Leonardo DiCaprio, Drew Barrymore, Cheryl Ladd`,
    `Dead Man
    Johnny Depp, Steve Buscemi, John Hurt`,
    `Election
    Reese Witherspoon, Matthew Broderick, Chris Klein`,
    `Mystery Men
    Ben Stiller, Tom Waits, Hank Azaria`,
    `Daun di Atas Bantal
    Sarah Azhari, Christine Hakim, Heru`,
    `Naked
    David Thewlis, Ewen Bremner, Lesley Sharp`,
    `Magnolia
    Tom Cruise, Julianne Moore, Philip Seymour Hoffman`,
    `Instinct
    Anthony Hopkins, Kim Cattrall, Cuba Gooding Jr.`,
    `Rosetta
    Olivier Gourmet, Fabrizio Rongione, Émilie Dequenne`,
    `White Palace
    Susan Sarandon, Kathy Bates, James Spader`,
    `Miracle on 34th Street
    Richard Attenborough, Mara Wilson, Dylan McDermott`,
    `The Negotiator
    Kevin Spacey, Samuel L. Jackson, Paul Giamatti`,
    `Three Colors: White
    Juliette Binoche, Julie Delpy, Jerzy Stuhr`,
    `Dick
    Kirsten Dunst, Will Ferrell, Ryan Reynolds`,
    `Safe
    Julianne Moore, Dean Norris, Xander Berkeley`,
    `Fresh
    Samuel L. Jackson, Giancarlo Esposito, N'Bushe Wright`,
    `Black Sheep
    Julie Benz, Gary Busey, David Spade`,
    `Michael
    John Travolta, Carla Gugino, Andie MacDowell`,
    `The River Wild
    Meryl Streep, Kevin Bacon, John C. Reilly`,
    `The Swan Princess
    John Cleese, Jack Palance, Frank Welker`,
    `Boys on the Side
    Drew Barrymore, Matthew McConaughey, Whoopi Goldberg`,
    `Balto
    Kevin Bacon, Phil Collins, Bridget Fonda`,
    `Heart and Souls
    Robert Downey Jr., Elisabeth Shue, Kyra Sedgwick`,
    `Shallow Grave
    Ewan McGregor, Christopher Eccleston, 피터 뮬란`,
    `Mom and Dad Save the World
    Kathy Ireland, Jeffrey Jones, Teri Garr`,
    `Paradise Lost: The Child Murde
    rs at Robin Hood Hills`,
    `Vampire in Brooklyn
    Eddie Murphy, Angela Bassett, Joanna Cassidy`,
    `The Adventures of Priscilla, Queen of the Desert
    Hugo Weaving, Guy Pearce, Terence Stamp`,
    `Little Boy Blue
    Ryan Phillippe, Nastassja Kinski, Jenny Lewis`,
    `The Butcher's Wife
    Demi Moore, Jeff Daniels, Frances McDormand`,
    `Party Girl
    Liev Schreiber, Christine Taylor, Parker Posey`,
    `An All Dogs Christmas Carol
    Ashley Tisdale, Ernest Borgnine, Sheena Easton`,
    `Going All the Way
    Ben Affleck, Rose McGowan, Rachel Weisz`,
    `Existenz
    Jude Law, Willem Dafoe, Jennifer Jason Leigh`,
    `Deep Cover
    Jeff Goldblum, Laurence Fishburne, Clarence Williams III1992`,
    `Timecop
    Jean-Claude Van Damme, Mia Sara, Ron Silver`,
    `Short Cuts
    Robert Downey Jr., Julianne Moore, Tim Robbins`,
    `City of Industry
    Lucy Liu, Famke Janssen, Harvey Keitel`,
    `Henry Fool
    Parker Posey, Rachel Miner, Liam Aiken`,
    `Deuce Bigalow: Male Gigolo
    Adam Sandler, Amy Poehler, Rob Schneider`,
    `The Thomas Crown Affair
    Pierce Brosnan, Faye Dunaway, Rene Russo`,
    `The Fisher King
    Robin Williams, Jeff Bridges, Tom Waits`,
    `Crash
    Holly Hunter, James Spader, Rosanna Arquette`,
    `Menace II Society
    Samuel L. Jackson, Jada Pinkett Smith, Charles S. Dutton`,
    `Funny Games
    Susanne Lothar, Ulrich Mühe, Wolfgang GlückWritten `,
    `Disclosure
    Demi Moore, Michael Douglas, Donald Sutherland`,
    `Pecker
    Christina Ricci, Stacy Keibler, Edward Furlong`,
    `Ghost Dog: The Way of the Samu
    raiForest Whitaker, Henry Silva, Victor Argo`,
    `Tall Tale
    Patrick Swayze, William H. Macy, Burgess Meredith`,
    `The Jungle Book
    Lena Headey, John Cleese, Sam NeillRudyard Kipling's`,
    `Jack Frost
    Michael Keaton, Stevie Ray Vaughan, Kelly Preston`,
    `Air Bud
    Mark Jackson, Kevin Zegers, Michael Jeter1997`,
    `Idle Hands
    Jessica Alba, Ricky Martin, Vivica A. Fox`,
    `Nixon
    Anthony Hopkins, James Woods, Ed Harris`,
    `RoboCop 2
    Peter Weller, Leeza Gibbons, Nancy Allen`,
    `Life Stinks
    Mel Brooks, Lesley Ann Warren, Jeffrey Tambor`,
    `Money Train
    Jennifer Lopez, Woody Harrelson, Wesley Snipes`,
    `Cadillac Man
    Robin Williams, Tim Robbins, Fran Drescher`,
    `Man Bites Dog
    Bernard Frédéric, Edith Lemerdy, Jacqueline Poelvoorde-Pappaert`,
    `Mimic
    Josh Brolin, Mira Sorvino, Norman Reedus`,
    `The Ref
    Kevin Spacey, J.K. Simmons, Denis Leary`,
    `The Age of Innocence
    Michelle Pfeiffer, Winona Ryder, Daniel Day-Lewis`,
    `Undercover Blues
    Kathleen Turner, Dennis Quaid, Dave Chappelle`,
    `Trick
    Miss Coco Peru, Tori Spelling, Missi Pyle`,
    `Nothing but Trouble
    Demi Moore, Tupac Shakur, Chevy ChaseNothing But Trouble`,
    `Beverly Hills Ninja
    Chris Rock, Chris Farley, Nicollette Sheridan`,
    `L.A. Story
    Sarah Jessica Parker, Steve Martin, Patrick Stewart`,
    `The Doom Generation
    Rose McGowan, Margaret Cho, Parker Posey`,
    `Nurse Betty
    Morgan Freeman, Chris Rock, Renée Zellweger`,
    `Mixed Nuts
    Adam Sandler, Steve Martin, Jon Stewart`,
    `Small Soldiers
    Sarah Michelle Gellar, Kirsten Dunst, Christina Ricci`,
    `The Langoliers
    Stephen King`,
    `Sure Fire
    Dennis Brown, Richard L. Blackwell, Kristi Hager`,
    `Spanking the Monkey
    Carla Gallo, Jeremy Davies, Alberta Watson`,
    `The Miracle of P. Tinto
    Javier Fesser, Luis Ciges, Eduardo Gómez`,
    `Passenger 57
    Elizabeth Hurley, Wesley Snipes, Tom Sizemore`,
    `Grand Canyon
    Steve Martin, Kevin Kline, Mary-Louise Parker`,
    `Priest
    Robert Carlyle, Tom Wilkinson, Marsha Thomason`,
    `The Faculty
    Salma Hayek, Usher, Famke Janssen`,
    `The Arrival
    Charlie Sheen, Teri Polo, Ron Silver`,
    `Everyone Says I Love You
    Natalie Portman, Julia Roberts, Drew Barrymore`,
    `The Insider
    Al Pacino, Russell Crowe, Christopher Plummer`,
    `Mo' Money
    Stacey Dash, Bernie Mac, Damon Wayans`,
    `The Piano Teacher
    Isabelle Huppert, Annie Girardot, Benoît Magimel`,
    `Riff-Raff
    Robert Carlyle, Ricky Tomlinson, Jim Coleman`,
    `Bad Lieutenant
    Harvey Keitel, Victor Argo, Paul Calderón`,
    `The Last Seduction
    Linda Fiorentino, Bill Pullman, Peter Berg`,
    `A Simple Plan
    Billy Bob Thornton, Bill Paxton, Bridget Fonda`,
    `Serial Mom
    Joan Rivers, Kathleen Turner, Suzanne Somers`,
    `Fall
    Scarlett Johansson, Lisa Vidal, Scott Cohen`,
    `The Double Life of Véronique
    Irène Jacob, Philippe Volter, Sandrine Dumas`,
    `Always Outnumbered
    Laurence Fishburne, Natalie Cole, Laurie Metcalf`,
    `Bullet
    Mickey Rourke, Tupac Shakur, Peter Dinklage`,
    `The Idiots
    Lars von Trier, Nikolaj Lie Kaas, Paprika Steen`,
    `The Locusts
    Ashley Judd, Vince Vaughn, Paul Rudd`,
    `Kiss the Sky
    Terence Stamp, Gary Cole, Ivana Miličević`,
    `Clay Pigeons
    Joaquin Phoenix, Vince Vaughn, Janeane Garofalo`,
    `Thursday
    Mickey Rourke, Paulina Porizkova, Thomas Jane`,
    `Festen
    Ulrich Thomsen, Klaus Bondam, Thomas Vinterberg`,
    `Relax...It's Just Sex
    Jennifer Tilly, Paul Winfield, Lori Petty`,
    `Six Ways to Sunday
    Debbie Harry, Norman Reedus, Adrien Brody`,
    `A Brother's Kiss
    Marisa Tomei, Jennifer Esposito, Rosie Perez`,
    `Denial
    Patrick Dempsey, Angie Everhart, Christine Taylor`
  ],
  song: [
    `Nirvana - "Smells Like Teen Spirit" (1991, #6 US)`,
    `U2 - "One" (1991, #10 US)`,
    `Backstreet Boys - "I Want It That Way" (1999, #6 US)`,
    `Whitney Houston - "I Will Always Love You" (1992, #1 US)`,
    `Madonna - "Vogue" (1990, #1 US)`,
    `Sir Mix-A-Lot - "Baby Got Back" (1992, #1 US)`,
    `Britney Spears - "Baby One More Time" (1999, #1 US)`,
    `TLC - "Waterfalls" (1994, #1 US)`,
    `R.E.M. - "Losing My Religion" (1991, #4 US)`,
    `Sinéad O'Connor - "Nothing Compares 2 U" (1990, #1 US)`,
    `Pearl Jam - "Jeremy" (1991, #79 US)`,
    `Alanis Morissette - "You Oughta Know" (1995)`,
    `Dr. Dre (featuring Snoop Doggy Dogg) - "Nuthin' but a "G" Thang" (1992, #2 US)`,
    `Mariah Carey - "Vision of Love" (1990, #1 US)`,
    `Red Hot Chili Peppers - "Under the Bridge" (1991, #2 US)`,
    `MC Hammer - "U Can't Touch This" (1990, #8 US)`,
    `Destiny's Child - "Say My Name" (1999, #1 US)`,
    `Metallica - "Enter Sandman" (1991, #16 US)`,
    `Beastie Boys - "Sabotage" (1994)`,
    `Hanson - "MMMBop" (1997, #1 US)`,
    `Celine Dion - "My Heart Will Go On" (1997, #1 US)`,
    `Beck - "Loser" (1994, #10 US)`,
    `Salt-N-Pepa with En Vogue - "Whatta Man" (1993, #3 US)`,
    `House of Pain - "Jump Around" (1992, #3 US)`,
    `Soundgarden - "Black Hole Sun" (1994)`,
    `Eminem - "My Name Is" (1999, #26 US)`,
    `Counting Crows - "Mr Jones" (1993)`,
    `Ricky Martin - "Livin' la Vida Loca" (1999, #1 US)`,
    `Vanilla Ice - "Ice Ice Baby" (1990, #1 US)`,
    `*NSYNC - "Tearin' Up My Heart" (1998)`,
    `Radiohead - "Creep" (1993)`,
    `BLACKstreet - "No Diggity" (1996, #1 US)`,
    `Spice Girls - "Wannabe" (1997, #1 US)`,
    `Third Eye Blind - "Semi-Charmed Life" (1997, #4 US)`,
    `Oasis - "Wonderwall" (1995, #8 US)`,
    `C+C Music Factory - "Gonna Make You Sweat (Everybody Dance Now)" (1991, #1 US)`,
    `Green Day - "Good Riddance (Time of Your Life)" (1998)`,
    `Christina Aguilera - "Genie In A Bottle" (1999, #1 US)`,
    `Goo Goo Dolls - "Iris" (1998)`,
    `Color Me Badd - "I Wanna Sex You Up" (1991, #2 US)`,
    `Spin Doctors - "Two Princes" (1993, #7 US)`,
    `Collective Soul - "Shine" (1994, #11 US)`,
    `En Vogue - "My Lovin' (You're Never Gonna Get It)" (1992, #2 US)`,
    `The Fugees - "Killing Me Softly With His Song" (1996)`,
    `Hootie & the Blowfish - "Only Wanna Be With You" (1995, #6 US)`,
    `Shania Twain - "You're Still the One" (1998, #2 US)`,
    `Marky Mark and the Funky Bunch - "Good Vibrations" (1991, #1 US)`,
    `Matchbox Twenty - "3 A.M." (1997)`,
    `Jewel - "Who Will Save Your Soul" (1996, #11 US)`,
    `Alice in Chains – “Man in the Box” (1990)`,
    `2Pac (featuring Dr Dre and Roger Troutman) - "California Love" (1996, #6 US)`,
    `Sugar Ray - "Fly" (1997)`,
    `Naughty by Nature - "O.P.P." (1991, #6 US)`,
    `Joan Osborne - "One of Us" (1995, #4 US)`,
    `Fiona Apple - "Criminal" (1996, #21 US)`,
    `L.L.Cool J - "Mama Said Knock You Out" (1990, #17 US)`,
    `Jay-Z featuring Amil and Ja Rule - "Can I Get A..." (1998)`,
    `Sophie B Hawkins - "Damn, I Wish I Was Your Lover" (1992, #5 US)`,
    `Weezer - "Buddy Holly" (1994)`,
    `Bell Biv DeVoe - "Poison" (1990, #2 US)`,
    `Sheryl Crow - "All I Wanna Do" (1993, #2 US)`,
    `Live - "I Alone" (1994)`,
    `The Notorious B.I.G featuring Mase & Puff Daddy - "Mo Money Mo Problems" (1997, #1 US)`,
    `The Presidents of the United States of America - "Peaches" (1995)`,
    `Digital Underground - "The Humpty Dance" (1990, #11 US)`,
    `Edwin McCain - "I'll Be" (1998, #5 US)`,
    `Deee-Lite - "Groove Is In The Heart" (1990, #4 US)`,
    `Will Smith - "Gettin' Jiggy Wit It" (1998, #1 US)`,
    `Korn - "Freak on a Leash" (1998)`,
    `Jamiroquai - "Virtual Insanity" (1997)`,
    `Arrested Development - "Tennessee" (1992, #6 US)`,
    `Barenaked Ladies - "One Week" (1998, #1 US)`,
    `Marcy Playground - "Sex and Candy" (1998, #5 US)`,
    `Cher - "Believe" (1999, #1 US)`,
    `Kris Kross - "Jump" (1992, #1 US)`,
    `Blues Traveler - "Run-around" (1995, #8 US)`,
    `Ice Cube - "It Was a Good Day" (1992, #15 US)`,
    `Lenny Kravitz - "Are You Gonna Go My Way" (1993)`,
    `Meredith Brooks - "Bitch" (1997, #2 US)`,
    `Right Said Fred - "I'm Too Sexy" (1992, #1 US)`,
    `Paula Cole - "I Don't Want to Wait" (1997, #11 US)`,
    `Geto Boys - "Mind Playing Tricks on Me" (1991, #23 US)`,
    `The Breeders - "Cannonball" (1993)`,
    `Snow - "Informer" (1993, #1 US)`,
    `Cypress Hill - "Insane In The Brain" (1993, #19 US)`,
    `The Cranberries - "Linger" (1993, #8 US)`,
    `Billy Ray Cyrus - "Achy Breaky Heart" (1992, #4 US)`,
    `Duncan Sheik - "Barely Breathing" (1997, #16 US)`,
    `Liz Phair - "Never Said" (1993)`,
    `New Radicals - "You Get What You Give" (1998, #37 US)`,
    `Sarah McLachlan - "Building a Mystery" (1997, #13 US)`,
    `Public Enemy - "911 Is a Joke" (1990)`,
    `Lisa Loeb - "Stay (I Missed You)" (1994, #1 US)`,
    `Fastball - "The Way" (1998)`,
    `Montell Jordan - "This Is How We Do It" (1995, #1 US)`,
    `Nelson - "(Can't Live Without Your) Love and Affection" (1990, #1 US)`,
    `Prince & The New Power Generation - "Gett Off" (1991, #27 US)`,
    `EMF - "Unbelievable" (1991, #1 US)`,
    `Missy Elliott - "The Rain (Supa Dupa Fly)" (1997)`,
    `Gerardo - "Rico Suave" (1991, #7 US)`,
  ],
}

if (usag !== 'firefox') ninetiesDb = {movie:[],song:[]};

const findPostInFirstScroll = (userWin, user) => {
  console.debug(`${now()} -- DEBUG: findPostInFirstScroll BEFORE looking for blog items.`);
  const blogItemsBlock = userWin.document.querySelectorAll('ul[class="PostsList__summaries hfeed"]')[0]
  console.debug(`${now()} -- DEBUG: findPostInFirstScroll AFTER looking for blog items.`);
  if (!blogItemsBlock) throw new Error(`Something went wrong reading ${user}'s list of blogs. Items not found.`);
  var allBlogItems = blogItemsBlock.children;
  var allBlogItemsArr = Array.prototype.slice.call(allBlogItems);
  for (let id = 0; id < allBlogItemsArr.length; id++) {
    const htmlElement = allBlogItems[id];
    if (htmlElement.textContent.substr(0,9) !== 'resteemed') {
      logsOn && console.debug(`${now()} -- -- Found ${user}'s last post. #${id+1} from top.`);
      const postLink = htmlElement.getElementsByTagName('a')[3].href;
      if (postLink.indexOf(`/@${user}/`) !== -1) return postLink;
    }
  }
}

async function extractLastPost (userWin, user) {
  try {
    let postAfterScrolling = findPostInFirstScroll(userWin, user);
    if (!postAfterScrolling) {
      logsOn && console.debug(`${now()} -- Not found without scrolling. Scrolling and searching more..`);
      userWin.window.scrollBy(0,5000);
      await nap(5000);
      postAfterScrolling = findPostInFirstScroll(userWin, user);
      if (!postAfterScrolling) {
        logsOn && console.debug(`${now()} -- Not found in first scroll. Scrolling and searching more..`);
        userWin.window.scrollBy(0,5000);
        await nap(5000);
        postAfterScrolling = findPostInFirstScroll(userWin, user);
      }
    }
    if (!postAfterScrolling) logsOn && console.error(`Post not found.`);
    logsOn && console.debug(`${now()} -- Found: ${postAfterScrolling}`);
    return postAfterScrolling;
  } catch (err) {
    const msg = `Error in extractLastPost. Error: ${err}`;
    logsOn && console.error(msg);
    localStorage.setItem(`errors-extractLastPost-${formatDate(new Date().getTime())}`, msg);
    throw new Error('stopped in extractLastPost');
  }
}

async function extractCommenter (wWinner) {
  try {
    logsOn && console.debug(`${now()} -- Reading commenters..`);
    var comments = wWinner.document.getElementById('#comments');
    var commentsEntities = comments.querySelectorAll('a[class="ptc"]');
    var allComments = Array.prototype.slice.call(commentsEntities);
    logsOn && console.debug(` -- commentsEntities: ${commentsEntities.length}, allComments: ${allComments.length}`);
    await nap(500); // ?
    var allCommenters = [...new Set(allComments.map(e => e.textContent.split(' ')[0] || e.href.split('/@')[1]))];
    var randomId = Math.floor(Math.random()*allCommenters.length-1)+1;
    logsOn && console.debug(`${now()} -- Commenters: ${JSON.stringify(allCommenters)}. Picked commenter #${randomId}: ${allCommenters[randomId]}`);
    return allCommenters[randomId];
  } catch (err) {
    const msg = `Error in extractCommenter. Error: ${err}`;
    logsOn && console.error(msg);
    localStorage.setItem(`errors-extractCommenter-${formatDate(new Date().getTime())}`, msg);
    throw new Error('stopped in extractCommenter');
  }
}

const cantWin = ['resteem.bot','gasaeightyfive','cribbio','gaottantacinque','abasinkanga','yougotresteemed','upvotewhale','tipu','cheetah']; // nazi, miei, resteemers e bid-bots

async function getWinner(link) {
  if (link.indexOf('https://') == -1) throw new Error('yesterday link not found');
  let wWinner;
  try {
    logsOn && console.debug(`${now()} -- Opening yesterday's post ${link}`);
    wWinner = open(link);
    await nap(10000);
    logsOn && console.debug(`${now()} -- Extracting lucky commenter..`);
    let wiener = await extractCommenter(wWinner);
    let count = 0;
    while (cantWin.indexOf(wiener) !== -1) {
      logsOn && console.debug(`${now()} -- was in cantWin, trying again..`);
      wiener = await extractCommenter(wWinner);
      if (++count === 20) throw new Error('winners were all excluded..');
    }
    if (!wiener) throw new Error(`No wiener found on yesterday's post!`);
    wWinner.window.location.href = `https://steemit.com/@${wiener}`;
    await nap(7000);
    logsOn && console.debug(`${now()} -- Winner is ${wiener}. Extracting winner's last post..`);
    const lastLink = await extractLastPost(wWinner, wiener);

    if (lastLink) {
      wWinner.window.location.href = lastLink;
      await nap(7000);
      logsOn && console.debug(`${now()} -- Adding comment on winner's post..`);
      await addWinnerComment (wWinner, wiener, lastLink, 'itshisblog');
    } else {
      logsOn && console.error(`No last link found for user ${wiener}!`);
    }
    logsOn && console.debug(`${now()} -- All done.`);
    return { wiener, lastLink };
  } finally {
    wWinner && !wWinner.closed && wWinner.close();
  }
}

/* navigator.userAgent
   "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0" Firefox
   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36 OPR/53.0.2907.99" OPR
   "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134" Edge
   ( "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36" Chrome )
*/
async function getPostObject (link, yesterday) {
  if (link) return promotedPost(link);
  const template = postsDb()[usag];
  template.title = template.title.replace('~status~', postStatus.open[usag]);
  if (usag === 'opr') { // QUOTE of the day
    const randomId = Math.floor(Math.random() * allQuotes.length - 1) + 1;
    template.body = template.body.replace('{X1}', `> ${allQuotes[randomId]}`);
    try {
      logsOn && console.debug(`${now()} -- Extracting yesterday's winner to insert in post..`);
      const yesterdaysLink = getTodaysLinkCodeOnly(casarioPostEveryOtherDay ? -2 : -1);
      const winnerObj = await getWinner(yesterdaysLink);
      template.body = template.body.replace('{in progress..}', `@${winnerObj.wiener}! <sub>upvote on his [last post](${winnerObj.lastLink || 'https://steemit.com/_NOT_FOUND_--_WILL_DO_MANUALLY'}) for winning [the last giveaway](${yesterdaysLink})</sub>`);
      template.yesterdaysWinner = { name: winnerObj.wiener, link: winnerObj.lastLink };
    } catch (err) {
      const msg = `Error in getPostObject extracting winner from yesterday's post. Error: ${err}`;
      logsOn && console.error(msg);
      localStorage.setItem(`errors-createMyPost-${formatDate(new Date().getTime())}`, msg);
    }
  } else if (usag === 'edge') { // JOKE of the day
    const randomId = Math.floor(Math.random() * allJokes.length - 1) + 1;
    template.body = template.body.replace('{X2}', `${allJokes[randomId].replace('\n','\n    ')}`);
  } else if (usag === 'firefox') {
    const yestLink = localStorage.getItem(`${yesterday}1`)
      || localStorage.getItem(`${yesterday}2`) || localStorage.getItem(`${yesterday}3`);
    template.body = template.body.replace(
      '{X3}', yestLink ? `- Link to my YESTERDAY's FREE Resteem post: ${yestLink}` : ''
    );
    const whichCat = Math.random() >= 0.5 ? 'MOVIE' : 'SONG';
    const randomId = Math.floor(Math.random() * ninetiesDb[whichCat.toLowerCase()].length - 1) + 1;
    const result = ninetiesDb[whichCat.toLowerCase()][randomId];
    template.body = template.body.replace(
      '{X4}', `
  ${whichCat=='MOVIE'?'':'<div class="pull-right"><sub>More on the #bravopapa channel!</sub></div>'}

  <h1>NOSTALGIA TIME! TODAY'S '90s ${whichCat} is:</h1>
> ${result}

[${whichCat.toLowerCase()}](https://www.google.com/search?q=${encodeURIComponent(result.split(' (')[0])}) &nbsp; <sub><sub>( open it in a new tab )</sub></sub>`
    );
  }
  return template;
}

const getNewTitle = (oldTitle) => {
  const whatBrowser = extractUA();
  return oldTitle.replace(postStatus.open[whatBrowser], postStatus.closed[whatBrowser]);
}

let allJokes = ["Person 1: Hey Rachyl, do you remember me?\n\nPerson 2: Wrong number.\n\nPerson 1: What’s your number then?",
	"Mom: How make chicken\nDaughter: What?\nMom: Where buy chicken\nDaughter: Mom, this isn’t Google.\nMom: Avocado",
	"Autocorrect has become my worst enema.",
	"Thanks to autocorrect, 1 in 5 children will be getting a visit from Satan this Christmas.",
	"“I feel like carp today”\n\n“Yeah, you look a little fishy”",
	"The guy who invented predictive text died last night.\n\nHis funfair is next monkey.",
	"The guy who invented auto-correct for smart phones passed away today.\n\nRestaurant in peace.",
	"Q: What do you call an iPhone that isn’t kidding around?\n\nA: Dead Siri-ous",
	"Q: Why was the cell phone wearing glasses?\n\nA: It lost its contacts.",
	"Q: What did the grandma cat say to her grandson when she saw him slouching?\n\nA: You need to pay more attention to my pawsture.",
	"Q: Wanna hear a bad cat joke?\n\nA: Just kitten!",
	"Q. What does a cat have that no other animal has?\n\nA. Kittens.",
	"Q: What did the cat say when the mouse got away?\n\nA: You’ve got to be kitten me!",
	"Q: Why don’t cats play poker in the jungle?\n\nA: There are too many cheetahs.",
	"Q: Why did the can crusher quit his job?\nA: Because it was soda pressing.",
	"Q: Why was the cat sitting on the computer?\n\nA: To keep an eye on the mouse!",
	"Q: Why did the cat wear a dress?\n\nA: She was feline fine.",
	"Q: What did the cat say when he lost all his money?\n\nA: I’m paw!",
	"Q: Why don’t cats like online shopping?\n\nA: They prefer a cat-alogue.",
	"Q: What do you call a pile of kittens?\n\nA: A meowntain",
	"Why is it so hard for a leopard to hide? Because he’s always spotted.",
	"What is a cat’s favorite song? Three Blind Mice.",
	"What do you call a cat that lives in an igloo? An eskimew!",
	"What do cats like to eat for breakfast? Mice Krispies.",
	"What do you call the cat that was caught by the police? The purrpatrator.",
	"Why don’t cats play poker in the jungle? Too many cheetahs.",
	"Q: What’s worse than raining cats and dogs?\nA: Hailing taxis",
	"Did you hear about the monkeys who shared an Amazon account? They were Prime mates.",
	"Don’t use “beef stew” as a computer password. It’s not stroganoff.",
	"Q. What is the biggest lie in the entire universe?\n\nA. “I have read and agree to the Terms & Conditions.”",
	"Q. What do you call it when you have your mom’s mom on speed dial?\n\nA. Instagram.",
	"Q. What should you do after your Nintendo game ends in a tie?\n\nA. Ask for a Wii-match!",
	"Why are iPhone chargers not called Apple Juice?!",
	"Q. How does a computer get drunk?\n\nA. It takes screenshots.",
	"Q. Why did the PowerPoint Presentation cross the road?\n\nA. To get to the other slide.",
	"PATIENT: Doctor, I need your help. I’m addicted to checking my Twitter!\n\nDOCTOR: I’m so sorry, I don’t follow.",
	"Have you heard of that new band “1023 Megabytes”? They’re pretty good, but they don’t have a gig just yet.",
	"I just got fired from my job at the keyboard factory. They told me I wasn’t putting in enough shifts.",
	"Person 1: Do you know how to use Outlook?\n\nPerson 2: As a matter of fact, I Excel at it.\n\nPerson 1: Was that a Microsoft Office pun?\n\nPerson 2: Word.",
	"My computer suddenly started belting out “Someone Like You.” It’s a Dell.",
	"I tried to say, “I’m a functional adult,” but my phone changed it to “fictional adult,” and I feel like that’s more accurate.",
	"Q: Why did the computer show up at work late?\n\nA: It had a \u2028hard drive.",
	"Person 1: Hey Rachyl, do you remember me?\n\nPerson 2: Wrong number.\n\nPerson 1: What’s your number then?",
	"If you sit down to enjoy a hot cup of coffee, then your boss will ask you to do something that will last until the coffee is cold.\n\n ",
	"Barista: How do you take your coffee?\n\nMe: Very, very seriously.",
	"Sleep is a weak substitute for coffee.",
	"Q: What do you call sad coffee?\nA: Despresso.",
	"Q: What’s the best Beatles song?\nA: Latte Be!",
	"Q: Why do they call coffee mud?\n\nA: Because it was ground a couple of minutes ago.",
	"Q: How are coffee beans like kids?\nA: They’re always getting grounded!",
	"Q: What’s it called when you steal someone’s coffee?\nA: Mugging!",
	"Q: How does a tech guy drink coffee?\nA: He installs Java!",
	"Q: How did the hipster burn his tongue?\n\nA: He drank his coffee before it was cool.",
	"Q: Why are Italians so good at making coffee?\nA: Because they know how to espresso themselves.",
	"Q: How are coffee beans like kids?\nA: They’re always getting grounded!",
	"If the local coffee shop has awarded you “Employee of the Month” and you don’t even work there, you may be drinking too much coffee.",
	"Coffee is the most important meal of the day",
	"Spouse #1: Honey, this coffee tastes like dirt.\nSpouse #2: That’s not surprising, dear, it was just ground this morning.",
	"Q: Where do birds go for coffee?\nA: To the NESTcafe",
	"Soup of the day: Coffee.",
	"Q: What’s the opposite of coffee?\nA: Sneezy.",
	"There are two types of people in this world: People who love Starbucks and liars.",
	"An SEO expert walks into a bar, bars, pub, tavern, public house, Irish pub, drinks, beer, alcohol",
	"Q: What’s Homer Simpson’s least favorite style of beer?\n\nA: Flanders Red Ale.\n\n ",
	"Q: What’s a shepherd’s favorite style of beer?\n\nA: Lambic.\n\n ",
	"Q: What’s a composer’s favorite style of beer?\n\nA: Bock.\n\n ",
	"Q: What’s a pharmacist’s favorite style of beer?\n\nA: Pilsner.\n\n-By Sam Benson Smith-",
	"A lizard walks into a bar pushing a baby in a stroller. “What’s your kid’s name?” asks the bartender. “Tiny,” says the lizard. “Because he’s my newt.”",
	"An amnesiac walks into a bar. He goes up to a beautiful blonde and says, “So, do I come here often?”",
	"The barman says, “We don’t serve time travelers in here.”\n\n A time traveler walks into a bar.",
	"A penguin walks into a bar, goes to the counter, and asks the bartender, “Have you seen my brother?”\n\nThe bartender says, “I don’t know. What does he look like?”",
	"A horse walks into a bar. The bartender says, “Hey.”\n\nThe horse says, “You read my mind, buddy.”",
	"Two men walk into a bar. You’d think at least one of them would have ducked.",
	"Marriage is a three-ring circus: engagement ring, wedding ring, and suffering.",
	"Wife: “Our new neighbor always kisses his wife when he leaves for work. Why don’t you do that?” Husband: “How can I? I don’t even know her.”",
	"Q: If love is “grand,” what is divorce? A: A hundred grand, or more.",
	"Q: Whats the difference between love and marriage? A: Love is blind and marriage is an eye-opener!",
	"My son wanted to know what it’s like to be married. I told him to leave me alone and when he did, I asked him why he was ignoring me.",
	"Son: What’s the difference between love and marriage? Father: Love is blind. Marriage is an eye opener.",
	"If I have to choose between a husband and shoes, I choose shoes. They tend to last longer and are easier to replace.",
	"Man: “I haven’t spoken to my wife in 18 months.” Friend: “Why not?” Man: “I don’t like to interrupt her.”",
	"Wife: Do you want dinner? Husband: Sure, what are my choices? Wife: Yes and no.",
	"Son: Dad, I’ve heard that in some parts of the world a man doesn’t know his wife until he marries her. Father: Son, that’s true everywhere.",
	"Every man wants a beautiful wife, a smart wife, a loving wife, a sexy wife, and a cooperative wife. Sadly, bigamy is against the law.",
	"If a man opens the car door for his wife, you can be sure of one thing — either the car is new or the wife is."
];

const allQuotes = ["No guts, no story. Chris Brady","My life is my message. Mahatma Gandhi","Screw it, let’s do it. Richard Branson","Boldness be my friend. William Shakespeare","Keep going. Be all in. Bryan Hutchinson","My life is my argument. Albert Schweitzer","Dream big. Pray bigger.","Leave no stone unturned. Euripides","Fight till the last gasp. William Shakespeare","Stay hungry. Stay foolish. Steve Jobs ","Broken crayons still color. Unknown ","And so the adventure begins.","If you want it, work for it.","You can if you think you can. George Reeves","Whatever you are, be a good one. Abraham Lincoln","Impossible is for the unwilling. John Keats","Grow through what you go through.","The wisest mind has something yet to learn. George Santanaya","Take the risk or lose the chance.","Do it with passion or not at all.","The past does not equal the future. Tony Robbins","Good things happen to those who hustle. Anaïs Nin","At the end of hardship comes happiness.","Don’t dream your life, live your dream.","If it matters to you, you’ll find a way. Charlie Gilkey","Forget about style; worry about results. Bobby Orr","Whatever you do, do with all your might. Marcus Tullius Cicero","Dream without fear. Love without limits.","Every noble work is at first impossible. Thomas Carlyle","If you’re going through hell, keep going. Winston Churchill","You can do anything you set your mind to.","We are twice armed if we fight with faith. Plato","Be faithful to that which exists within yourself. André Gide","Persistence guarantees that results are inevitable. Paramahansa Yogananda","In life you need either inspiration or desperation. Tony Robbins","I would rather die on my feet than live on my knees. Euripides","The true success is the person who invented himself. Al Goldstein","Don’t tell people your plans. Show them your results.","Let him that would move the world first move himself. Socrates","Go forth on your path, as it exists only through your walking. Augustine of Hippo","We can do anything we want to if we stick to it long enough. Helen Keller","It does not matter how slowly you go as long as you do not stop. Confucius","It is better to live one day as a lion, than a thousand days as a lamb. Roman proverb","Life is fragile. We’re not guaranteed a tomorrow so give it everything you’ve got. Tim Cook","The two most important days in your life are the day you are born and they day you find out why. Mark Twain","Fall seven times, stand up eight. Japanese proverb (This is one of my favorite short quote. Leave a reply here and let me know what’s yours!)","When nothing goes right, go left. ","Life is too short to learn German. Oscar Wilde","Why do they put pizza in a square box?","Do crabs think we walk sideways? Bill Murray","Don’t be humble, you’re not that great. Indira Gandhi","I intend to live forever. So far, so good. Steven Wright","My life feels like a test I didn’t study for.","Why is there an expiration date on sour cream? George Carlin","This suspense is terrible. I hope it will last. Oscar Wilde","I drive way too fast to worry about cholesterol. Steven Wright","A day without sunshine is like, you know, night. Steve Martin","In heaven, all the interesting people are missing. Friedrich Nietzsche","The last woman I was in was the Statue of Liberty. Woddy Allen","Women want love to be a novel. Men, a short story. Daphne du Maurier","Guests, like fish, begin to smell after three days. Benjamin Franklin","Go to Heaven for the climate, Hell for the company. Mark Twain","Whoever named it necking is a poor judge of anatomy. Groucho Marx","Change is inevitable – except from a vending machine. Robert C. Gallagher","I bet giraffes don’t even know what farts smell like. Bill Murray","Every novel is a mystery novel if you never finish it.","Why is the slowest traffic of the day called ‘rush hour’?","It’s easy to quit smoking. I’ve done it hundreds of times. Mark Twain","The risk I took was calculated, but man, I am bad at math.","I couldn’t repair your brakes, so I made your horn louder. Steven Wright","Do not read the next sentence. You little rebel, I like you.","Just when I discovered the meaning of life, they changed it. George Carlin","Always borrow money from a pessimist. He won’t expect it back. Oscar Wilde ","If truth is beauty, how come no one has their hair done in a library? Lily Tomlin","I love deadlines. I love the whooshing noise they make as they go by. Douglas Adams","I never feel more alone than when I’m trying to put sunscreen on my back. Jimmy Kimmel","Those are my principles, and if you don’t like them… well, I have others. Groucho Marx","The key to eating healthy is not eating any food that has a TV commercial. Mike Birbiglia","I’ve got to keep breathing. It’ll be my worst business mistake if I don’t. Steve Martin","There are three types of people in this world: those who can count, and those who can’t.","The closest a person ever comes to perfection is when he fills out a job application form.","Go! ","Love.","Begin.","Let go.","Breathe.","Slow down.","Let it be.","Go for it.","I love you.","Keep going.","Choose joy.","Enjoy today.","C’est la vie.","Choose happy.","Keep it cool.","Take it easy.","Be in the now.","Live the moment.","Choose to shine.","No pain, no gain.","Do it. With love.","Prove them wrong. ","I can and I will.","It is what it is.","Love conquers all.","Keep your chin up.","Follow your heart.","Don’t rush things.","You only live once.","Never stop dreaming.","Now is all you have.","Keep moving forward.","This too shall pass.","Every moment matters.","Love more. Worry less.","Dust settles. I don’t.","Nothing lasts forever.","Work hard. Stay humble.","Enjoy the little things.","The best is yet to come.","Better things are coming.","Collect moments – not things.","Feel the fear and do it anyway.","You matter. ","You are loved.","Actually, you can.","Yes!! Yes!! You can do it!","Focus on the good.","You are doing great.","We rise by lifting others.","Be happy. Be bright. Be you.","Every day is a second chance.","You are amazing. Remember that.","Darling, you are a work of art.","Each day provides its own gifts. Marcus Aurelius","Happiness looks gorgeous on you.","You are capable of amazing things.","You are somebody’s reason to smile.","Try Again. Fail again. Fail better. Samuel Beckett","Nothing is worth more than this day. Johann Wolfgang von Goethe","Think like a proton, always positive.","You are stronger than you think you are.","Focus on the journey, not the destination. Greg Anderson","Believe you can and you’re halfway there. Theodore Roosevelt ","Once you choose hope, anything’s possible. Christopher Reeve","You make mistakes. Mistakes don’t make you.","Breathe. It’s just a bad day, not a bad life.","The first step is you have to say that you can. Will Smith","Start every day off with a smile and get it over with. W. C. Fields","If you want to lift yourself up, lift up someone else. Booker T. Washington","It’s okay to not be okay as long as you are not giving up.","If you feel like giving up, look back at how far you’ve come.","Every day may not be good but there is something good in every day.","Don’t go through life, grow through life. Eric Butterworth","A problem is a chance for you to do your best. Duke Ellington","You are amazing. As you are. Stronger than you know. More beautiful than you think. Tia Sparkles","Everything is going to be okay in the end. If it’s not the okay, it’s not the end.","No rain. No flowers. ","Shine like the stars.","You make my heart smile.","You will forever be my always.","Your voice is my favorite sound.","Throw kindness around like confetti.","My favorite place is inside your hug. ","I still fall in love with you every day.","You smile, I smile. That’s how it works.","She was a rainbow, but he was color blind.","We were born to be real, not to be perfect.","When I count my blessings, I count you twice.","By the way, I’m wearing the smile you gave me.","If you are not too long, I will wait here for you all my life. Oscar Wilde","When it rains look for rainbows. When it’s dark look for stars.","To the world you may be one person, but to one person you are the world. Bill Wilson","I love you not only for what you are, but for what I am when I am with you. Ray Croft","You have to be odd to be number one. Dr. Seuss ","Please all, and you will please none. Aesop","The fool wonders, the wise man asks. Benjamin Disraeli","A smooth sea never made a skillful sailor.","Pain is inevitable. Suffering is optional.","A man can’t ride your back unless it’s bent. Martin Luther King Jr","Don’t raise your voice. Improve your argument.","Chop your own wood and it will warm you twice. Henry Ford","Some people are so poor, all they have is money. Jack Kerouac","All generalizations are false, including this one. Mark Twain","It’s not what you look at that matters, it’s what you see. Henry David Thoreau","There is no saint without a past, no sinner without a future. Augustine of Hippo ","We make a living by what we get, but we make a life by what we give. Winston Churchill","It’s so strange that autumn is so beautiful; yet everything is dying.","It’s no wonder that truth is stranger than fiction. Fiction has to make sense. Mark Twain","The man who wants to lead the orchestra must turn his back on the crowd. James Crook","What counts can’t always be counted; what can be counted doesn’t always count. Albert Einstein","As a well-spent day brings happy sleep, so a life well spent brings happy death. Leonardo da Vinci","Life is not about how fast you run or how high you climb, but how well you bounce. Vivian Komori","Concentration is the ability to think about absolutely nothing when it is absolutely necessary. Ray Knight","It is better to remain silent and be thought a fool than to open one’s mouth and remove all doubt. Mark Twain","Be a voice. Not an echo. ","Seek the seeker. Ramana Maharshi","No pressure, no diamonds. Thomas Carlyle","Every wall is a door. Ralph Waldo Emerson","The only truth is music. Jack Kerouac","Silence is an answer too.","Stay foolish to stay sane. Maxime Lagacé","If youth knew; if age could. Sigmund Freud","Time is the soul of this world. Pythagoras","Stars can’t shine without darkness.","He not busy being born is busy dying. Bob Dylan","It takes a long time to become young. Pablo Picasso","Be who you needed when you were young.","Innocence is courage and clarity both. Osho","Find what you love and let it kill you. Charles Bukowski","Sadness flies away on the wings of time. Jean de La Fontaine","I am not young enough to know everything. Oscar Wilde","It is not length of life, but depth of life. Ralph Waldo Emerson","Life is like the ocean, it goes up and down. Vanessa Paradis","The eyes are useless when the mind is blind.","You’ve gotta know what death is to know life. Jack Kevorkian","Don’t let yesterday take up too much of today. Will Rogers","Forgiveness is giving up hope for a better past.","Be kind to unkind people, they need it the most.","Solitary trees, if they grow at all, grow strong. Winston Churchill","Character like a photograph, develops in darkness.","The bird a nest, the spider a web, man friendship. William Blake","Life is a question and how we live it is our answer. Gary Keller ","God provides the wind, but man must raise the sails. Augustine of Hippo","Art is the lie that enables us to realize the truth. Pablo Picasso","Enlightenment is when a wave realizes it is the ocean.","The truth isn’t always beauty, but the hunger for it is. Nadine Gordimer","This is your life, and it’s ending one minute at a time.","Hearts are wild creatures, that’s why our ribs are cages.","Life without love is like a tree without blossoms or fruit. Khalil Gibran","Your faith can move mountains and your doubt can create them.","The knowledge of happiness brings the knowledge of unhappiness. Swami Vivekananda","There are those who give with joy, and that joy is their reward. Khalil Gibran","Life is the car, your heart is the key and God is the chauffeur. Sri Sathya Sai Baba","You are not a drop in the ocean. You are the entire ocean in a drop. Rumi","Normality is a paved road: it’s comfortable to walk, but no flowers grow on it.","One is never afraid of the unknown; one is afraid of the known coming to an end. Jiddu Krishnamurti","When you’re happy you enjoy the music, when you’re sad you understand the lyrics.","When you’ve seen beyond yourself, then you may find, peace of mind is waiting there. George Harrison","So it goes. Kurt Vonnegut ","Live the life you’ve dreamed. Henry David Thoreau","Life is not fair; get used to it. Bill Gates","Life is a long lesson in humility. James M. Barrie","Life is a lively process of becoming. Douglas MacArthur","The unexamined life is not worth living. Socrates","Life is largely a matter of expectation. Homer","Don’t count the days. Make the days count.","Anything worth doing is worth doing slowly. Mae West","Don’t wait. Life goes faster than you think.","Be soft. Do not let the world make you hard.","Life is too important to be taken seriously. Oscar Wilde","Life is either a daring adventure or nothing. Helen Keller","The sole meaning of life is to serve humanity. Leo Tolstoy","Love the life you live. Lead the life you love. Bob Marley","Life is accepting what is and working from that. Gloria Naylor","We are all, right now, living the life we choose. Peter McWilliams","Not life, but good life, is to be chiefly valued. Socrates","Live your life, do your work, then take your hat. Henry David Thoreau ","Life got to be about more than just solving problems. Elon Musk","Life isn’t as serious as the mind makes it out to be. Eckhart Tolle","Life is about making an impact, not making an income. Kevin Kruse","The quality of life is more important than life itself. Alexis Carrel","You have to die a few times before you can really live. Charles Bukowski","What’s coming will come and we’ll meet it when it does. Hagrid","Life shrinks or expands in proportion to one’s courage. Anaïs Nin","Life is defined more by its risks than by its samenesses. Mary Anne Radmacher","You only live once, but if you do it right, once is enough. Mae West","Sometimes life has its way with you when you least expect it. Jon Hamm","Life isn’t about getting and having, it’s about giving and being. Kevin Kruse","Life can only be understood backwards; but it must be lived forwards. Soren Kierkegaard","Life is amazing. Life is fucking messy. Life is what you make of it. Dwayne Johnson","Life is not a problem to be solved, but a reality to be experienced. Soren Kierkegaard","Nowadays people know the price of everything and the value of nothing. Oscar Wilde","Only one life that soon is past, only what’s done with love will last.","Don’t be afraid your life will end. Be afraid that it will never begin. Grace Hansen","To live is the rarest thing in the world. Most people exist, that is all. Oscar Wilde","Life is like riding a bicycle. To keep your balance, you must keep moving. Albert Einstein","In three words I can sum up everything I’ve learned about life: it goes on. Robert Frost","Life really does begin at forty. Up until then, you are just doing research. Carl Gustav Jung","The meaning of life is to find your gift. The purpose of life is to give it away. William Skakespeare","Life, it seems, is nothing if not a series of initiations, transitions, and incorporations. Alan Dundes","Life becomes harder for us when we live for others, but it also becomes richer and happier. Albert Schweitzer","Life is not measured by the number of breaths we take, but by the moments that take our breath away. Maya Angelou","Life is pure adventure, and the sooner we realize that, the quicker we will be able to treat life as art. Maya Angelou","I’ve never been poor, only broke. Being poor is a frame of mind. Being broke is only a temporary situation. Mike Todd","Enjoy the little things in life because one day you’ll look back and realize they were the big things.","I think people spend too much time staring into screens and not enough time drinking wine, tongue kissing, and dancing under the moon. Rachel Wolchin","To love is to act. Victor Hugo ","All you need is love. John Lennon","Do all things with love. Og Mandino","Every lover is a soldier. Ovid","Who, being loved, is poor? Oscar Wilde","Speak low, if you speak love. William Shakespeare","Love is the absence of judgment. Dalai Lama","If you wished to be loved, love. Lucius Annaeus Seneca","Love the sinner and hate the sin. Augustine of Hippo","If a thing loves, it is infinite. William Blake","In true love, you attain freedom. Thich Nhat Hanh","Economized love is never real love. Honore De Balzac","Love does not dominate; it cultivates. Johann Wolfgang von Goethe","The more you judge, the less you love. Honore de Balzac","Lovers quarrels are the renewal of love. Terence","Life is a game and true love is a trophy. Rufus Wainwright ","To love is to receive a glimpse of heaven. Karen Sunde","Love is the flower you’ve got to let grow. John Lennon","If love appears, boundaries will disappear. Osho","Intense love does not measure, it just gives. Mother Teresa","They do not love that do not show their love. William Shakespeare","Absence sharpens love, presence strengthens it. Benjamin Franklin","The more you love, the more you become lovable. Osho","You cannot save people, you can just love them. Anaïs Nin","Love is a thing that is full of cares and fears. Ovid","It is love alone that gives worth to all things. Teresa of Avila","Life in abundance comes only through great love. Elbert Hubbard","Love does not claim possession, but gives freedom. Rabindranath Tagore","The art of love is largely the art of persistence. Albert Ellis","If you judge people, you have no time to love them. Mother Teresa","Never love anyone who treats you like you’re ordinary. Oscar Wilde","You give me the kind of feeling people write novels about.","Follow love and it will flee, flee love and it will follow. John Gay","Love is like the wind, you can’t see it but you can feel it. Nicholas Sparks","Stay away from people who make you feel like you’re hard to love.","Perhaps one did not want to be loved so much as to be understood. George Orwell","Never let an opportunity to tell someone how much they mean to you.","The quickest way to get someone’s attention is to no longer want it.","True love is like ghosts, which everyone talks about and few have seen. Francois de La Rochefoucauld","Spread love everywhere you go. Let no one ever come to you without leaving happier. Mother Teresa","Do what you love. Know your own bone; gnaw at it, bury it, unearth it, and gnaw it still. Henry David Thoreau","Love needs great courage. It needs great courage because it needs the sacrifice of the ego. Osho","I don’t have time to worry about who doesn’t like me. I’m too busy loving people who love me.","Do not seek the because – in love there is no because, no reason, no explanation, no solutions. Anaïs Nin","Whoever loves becomes humble. Those who love have, so to speak, pawned a part of their narcissism. Sigmund Freud","You are enough. ","Nobody is perfect.","Make yourself a priority.","This is who the fuck I am. Lady Gaga","Find yourself, and be that.","Different doesn’t mean wrong.","Where’s your will to be weird? Jim Morrison ","And now I’ll do what’s best for me.","Above all things, reverence yourself. Pythagoras","Self-respect knows no considerations. Mohandas Gandhi","No one is laughable who laughs at himself. Lucius Annaeus Seneca","Why fit in when you were born to stand out? Dr. Seuss","Personal love is concentrated universal love. Maharishi Mahesh Yogi","You are not designed for everyone to like you.","We must be our own before we can be another’s. Ralph Waldo Emerson","Accept who you are. Unless you’re a serial killer. Ellen DeGeneres","Beauty begins the moment you decide to be yourself. Coco Chanel","Wanting to be someone else is a waste of who you are. Kurt Cobain","To love oneself is the beginning of a lifelong romance. Oscar Wilde","Whatever makes you weird is probably your greatest asset.","If you are lonely when you’re alone, you are in bad company. Jean-Paul Sartre","The worst loneliness is not to be comfortable with yourself. Mark Twain","I’m currently under construction. Thank you for your patience.","The reward for conformity is that everyone likes you but yourself. Rita Mae Brown","Be yourself. People don’t have to like you, and you don’t have to care.","Your value doesn’t decrease based on someone’s inability to see your worth.","It is better to be hated for what you are than to be loved for what you are not. André Gide","I found that there is only one thing that heals every problem, and that is: to know how to love yourself. Louise Hay","To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment. Ralph Waldo Emerson","Smile, it’s free therapy.","Freedom lies in being bold. Robert Frost","A happy wife is a happy life. Gavin Rossdale","Happiness lies in perspective.","Boredom: the desire for desires. Leo Tolstoy","Do more of what makes you happy.","Happiness depends upon ourselves. Aristotle","The less I needed, the better I felt. Charles Bukowski","Be happy in the moment, that’s enough. Mother Teresa","Happiness can exist only in acceptance. George Orwell","Man is the artificer of his own happiness. Henry David Thoreau","One of the keys to happiness is a bad memory. Rita Mae Brown","To live happily is an inward power of the soul. Marcus Aurelius","Anything you’re good at contributes to happiness. Bertrand Russell","A happy soul is the best shield for a cruel world. Atticus","There is no way to happiness. Happiness is the way. Thich Nhat Hanh","Never expect anything. You’ll never be disappointed.","Work out your own salvation. Do not depend on others. Buddha ","Happiness is the absence of the pursuit of happiness.","Stay true to you and you will end up incredibly happy.","Happiness is needing less. Unhappiness is wanting more.","The best way to pay for a lovely moment is to enjoy it. Richard Bach","If you carry joy in your heart, you can heal any moment. Carlos Santana","Life’s greatest happiness is to be convinced we are loved. Victor Hugo","Be happy with what you have. Be excited about what you want. Alan Cohen","Find ecstasy in life; the mere sense of living is joy enough. Emily Dickinson","To be content means that you realize you contain what you seek. Alan Cohen","Happy are those who dare courageously to defend what they love. Ovid","Whatever it is, find something to be excited about for tomorrow.","Doing what you like is freedom. Liking what you do is happiness. Frank Tyger","The key to happiness is doing something you like every single day. Victor Pride","We don’t laugh because we’re happy – we’re happy because we laugh. William James","For every minute you are angry you lose sixty seconds of happiness. Ralph Waldo Emerson","Happiness is not a station you arrive at, but a manner of traveling. Margaret Lee Runbeck","True happiness arises, in the first place, from the enjoyment of one’s self. Joseph Addison","Base your happiness on taking action toward those goals, not on attaining them. Laura J. Tong","A lifetime of happiness! No man alive could bear it: it would be hell on earth. George Bernard Shaw","Most people have never learned that one of the main aims in life is to enjoy it. Samuel Butler","Happiness cannot be accumulated. What is accumulated is always destructed by time. Jiddu Krishnamurti","Happiness resides not in possessions, and not in gold, happiness dwells in the soul. Democritus","A friend is a second self. Aristotle","Choose people who lift you up. Michelle Obama","Find your tribe. Love them hard.","Try to be a rainbow in someone’s cloud.","Love is blind; friendship closes its eyes. Friedrich Nietzsche","Any day spent with you is my favorite day.","The greatest gift is a portion of thyself. Ralph Waldo Emerson","The only way to have a friend is to be one. Ralph Waldo Emerson","Friends are the siblings God never gave us. Mencius","Rare as is true love, true friendship is rarer. Jean de La Fontaine","The good man is the friend of all living things. Mahatma Gandhi","One loyal friend is worth ten thousand relatives. Euripides","Treasure your relationships, not your possessions. Anthony J. D’Angelo ","Friendship always benefits; love sometimes injures. Seneca","The language of friendship is not words but meanings. Henry David Thoreau","Friends? You don’t need more than your few close ones. Alden Tan","Wherever we are, it is our friends that make our world. Henry Drummond","It’s a beautiful thing to love others just as they are.","My best friend is the one who brings out the best in me. Henry Ford","If you have one true friend you have more than your share. Thomas Fuller","The real business of life is trying to understand each other. Gilbert Parker","People are lonely because they build walls instead of bridges. Joseph F. Newton","Friends show their love in times of trouble, not in happiness. Euripides","A friend is someone who knows all about you and still loves you. Elbert Hubbard","The greatest gift of life is friendship, and I have received it. Hubert H. Humphrey","True friendship comes when the silence between two people is comfortable. David Tyson","‘Enough’ is a feast. Buddhist proverb","Count your blessings. Og Mandino","Be obsessively grateful.","Gratitude changes everything.","Gratitude is the sign of noble souls. Aesop","Start each day with a grateful heart.","Joy is the simplest form of gratitude. Karl Barth","Expect nothing and appreciate everything.","A grateful heart is a magnet for miracles.","Gratitude is riches. Complaint is poverty. Doris Day","Silent gratitude isn’t very much to anyone. Gertrude Stein","Don’t forget who was with you from the start.","When one has a grateful heart, life is so beautiful. Roy T. Bennett","Don’t cry because it’s over, smile because it happened. Ludwig Jacobowski ","Gratitude is the fairest blossom which springs from the soul. Henry Ward Beecher","The essence of all beautiful art, all great art, is gratitude. Friedrich Nietzsche","Pull over to the side of your journey and look how far you’ve come.","How lucky I am to have something that makes saying goodbye so hard. Winnie the Pooh","Gratitude is not only the greatest of virtues, but the parent of all others. Marcus Tullius Cicero","Kindness is wisdom. Philip James Bailey","Kindness is contagious.","Fair and softly goes far. Miguel de Cervantes","Kindness is always beautiful.","Real kindness seeks no return.","Be gentle first with yourself. Lama Yeshe","Do small things with great love. Mother Teresa","You will never regret being kind.","In the end, only kindness matters.","For it is in giving that we receive. Francis of Assisi","No one has ever become poor by giving. Anne Frank","Kind people are the best kind of people.","Kindness is not an act, it’s a lifestyle.","The more sympathy you give, the less you need. Malcolm S. Forbes","In a world where you can be anything, be kind.","Be kind to unkind people. They need it the most.","Be kind, for everyone you meet is fighting a hard battle Ian Maclaren","Be kind whenever possible. It is always possible. Dalai Lama","Kindness, I’ve discovered, is everything in life. Isaac Bashevis","A warm smile is the universal language of kindness. William Arthur Ward","My religion is very simple. My religion is kindness. Dalai Lama","Be somebody who makes everybody feel like a somebody.","We are all different. Don’t judge, understand instead. Roy T. Bennett","If you can’t feed a hundred people, then feed just one. Mother Teresa","What wisdom can you find that is greater than kindness? Jean-Jacques Rousseau","No act of kindness, no matter how small, is ever wasted. Aesop ","You can accomplish by kindness what you cannot by force. Publilius Syrus","The end result of kindness is that it draws people to you. Anita Roddick","Kindness is like snow – it beautifies everything it covers. Khalil Gibran","We shall never know all the good that a simple smile can do. Mother Teresa","It’s nice to be important, but it’s more important to be nice.","How you make others feel about themselves says a lot about you.","Be kinder to yourself. And then let your kindness flood the world.","How do we change the world? One random act of kindness at the time.","I don’t worry about people misinterpreting my kindness for weakness. Jason Bateman","Wherever there is a human being, there is an opportunity for a kindness. Lucius Annaeus Seneca","You are your choices. Lucius Annaeus Seneca","Be true to who you are.","My forte is awkwardness. Zach Galifianakis","We are what we believe we are. C.S. Lewis","Do as you wish. Be as you are.","It’s ok to put yourself first.","Know who you are and know it’s enough.","The ultimate mystery is one’s own self. Sammy Davis Jr.","Character is simply habit long continued. Plutarch","This above all: to thine own self be true. William Shakespeare","Adventure is not outside man; it is within. George Eliot","You are who you are when nobody’s watching. Stephen Fry","To know oneself, one should assert oneself. Albert Camus","The things that we love tell us what we are. Thomas Aquinas","When I am silent, I have thunder hidden inside. Rumi","I may be no better, but at least I am different. Jean-Jacques Rousseau","There is no competition because nobody can be me.","I am not the perishable body, but the eternal Self. Ramana Maharshi","What I’m looking for is not out there, it is in me. Helen Keller","Being entirely honest with oneself is a good exercise. Sigmund Freud","Sometimes it’s only madness that makes us what we are.","As long as you can find yourself, you’ll never starve. Suzanne Collins","Self-esteem is the reputation we acquire with ourselves. Nathaniel Branden","Knowing others is wisdom, knowing yourself is enlightenment. Lao Tzu","The only tyrant I accept in this world is the still voice within. Mohandas Gandhi ","Getting in touch with your true self must be your first priority. Tom Hopkins","Life isn’t about finding yourself. Life is about creating yourself. George Bernard Shaw","Never be an imitator, be always original. Don’t become a carbon copy. Osho","The best way to find yourself is to lose yourself in the service of others. Mohandas Gandhi","Life is really a dance if you are original, and you are meant to be original. Osho","He who controls others may be powerful, but he who has mastered himself is mightier still. Lao Tzu","What you get by achieving your goals is not as important as what you become by achieving your goals. Henry David Thoreau","The first half of life is devoted to forming a healthy ego. The second is going inward and letting go of it. Carl Gustav Jung","Dreams don’t work unless you do.","Everything you can imagine is real. Pablo Picasso","If you can dream it, you can do it. Walt Disney","Don’t dream your life, live your dream.","Nothing happens unless first we dream. Carl Sandburg","The dreamers are the saviors of the world. James Allen ","If you give up on your dreams, what’s left? Jim Carrey","It may be that those who do most, dream most. Stephen Butler Leacock","Make your dreams happen. Die with memories, not dreams.","If it’s still in your mind, it is worth taking the risk.","Trust in dreams, for in them is hidden the gate to eternity. Khalil Gibran","I dream. Sometimes I think that’s the only right thing to do. Haruki Murakami","Dreams are often most profound when they seem the most crazy. Sigmund Freud","The biggest adventure you can take is to live the life of your dreams. Oprah Winfrey","The future belongs to those who believe in the beauty of their dreams. Eleanor Roosevelt","You can’t put a limit on anything. The more you dream, the farther you get. Michael Phelps","Go confidently in the direction of your dreams and live the life you have imagined. Henry David Thoreau","You are beautiful.","Be beautiful your own way.","There is beauty in simplicity.","To love beauty is to see light. Victor Hugo","Beauty awakens the soul to act. Dante Alighieri","Imperfection is beauty, madness is genius.","Beauty is the promise of happiness. Stendhal","A beautiful thing is never perfect. Egyptian proverb","Do something wonderful, people may imitate it. Albert Schweitzer ","Everything has beauty, but not everyone sees it. Confucius","Beauty always promises, but never gives anything. Simone Weil","The human soul needs actual beauty more than bread. D. H. Lawrence","Beauty begins the moment you decide to be yourself. Coco Chanel","I’ve never seen a smiling face that was not beautiful.","If the path be beautiful, let us not ask where it leads. Anatole France","Beauty is not in the face; beauty is a light in the heart. Khalil Gibran","Think of all the beauty still left around you and be happy. Anne Frank","Sometimes you need to close your eyes to see the real beauty.","For me the greatest beauty always lies in the greatest clarity. Gotthold Ephraim Lessing","The truth is not always beautiful, nor beautiful words the truth. Lao Tzu","I don’t think of all the misery, but of the beauty that still remains. Anne Frank","You are imperfect, permanently and inevitably flawed. And you are beautiful. Amy Bloom","The best and most beautiful things in the world cannot be seen or even touched – they must be felt with the heart. Helen Keller","Time is money. Benjamin Franklin","Time is all we have.","Good things take time.","Time eases all things. Sophocles","Lost time is never found again. Benjamin Franklin","Time brings all things to pass. Aeschylus","Time is the wisest counsellor of all. Pericles","Time is but the stream I go fishing in. Henry David Thoreau","The trouble is, you think you have time. Jack Kornfield","Nothing is so dear and precious as time. French proverb","Time you enjoy wasting isn’t wasted time.","Time is a game played beautifully by children. Heraclitus","Don’t wait. The time will never be just right. Mark Twain","Time is what we want most, but what we use worst. William Penn","It’s not about having time, it’s about making time.","The two most powerful warriors are patience and time. Leo Tolstoy ","In seed time learn, in harvest teach, in winter enjoy. William Blake","Taking crazy things seriously is a serious waste of time. Haruki Murakami","Being rich is having money, being wealthy is having time. Stephen Swid","Be patient and tough; one day this pain will be useful to you. Ovid","Your time is limited, so don’t waste it living someone else’s life. Steve Jobs","If you love life, don’t waste time for time is what life is made up of. Bruce Lee","Own less. Do more.","Simplify, simplify. Henry David Thoreau","Order brings peace. St-Augustine","More life, less rush.","Buy less, choose well. Vivienne Westwood","Do more of what matters. Anthony Ongaro","Fewer things. More peace.","Brevity is the soul of wit. William Shakespeare","Stop the glorification of busy.","Simplicity is the soul of efficiency. Austin Freeman","Once you need less, you will have more.","I make myself rich by making my wants few. Henry David Thoreau","Owning less is better than organizing more. Joshua Becker","He is richest who is content with the least. Socrates","Learn to say no without explaining yourself.","Who is rich? He that rejoices in his portion. Benjamin Franklin","Owning less is great, wanting less is better. Joshua Becker ","Someone else is happy with less than you have.","You don’t need more space. You need less stuff.","Minimalism is not deprivation, it’s liberation.","The most important things in life aren’t things. Anthony J. D’Angelo","A place for everything, everything in its place. Benjamin Franklin","There is more to life than increasing its speed. Mahatma Gandhi","It is quality rather than quantity that matters. Lucius Annaeus Seneca","The need for less often result in a life of more. Brian Gardner","Love people, use things. The opposite never works. The Minimalists","The verbal expression of simplicity is ‘no thanks’.","Remember, you probably already have more than you need.","Owning things has a cost, and money is the least of it. David Cain","Life is really simple, but we insist on making it complicated. Confucius","I was living the American dream and I realized it wasn’t my dream. Joshua Fields Millburn","Stop pressing rewind on things that should be deleted in your life.","The more possessions you have, the less time you have to enjoy them.","My goal is no longer to get more done, but rather to have less to do. Francine Jay","Being a minimalist means you value yourself more than material things.","Getting all of that stuff out of your life (and your mind) is addictive. Tynan","Instead of working so hard to make ends meet, work on having fewer ends. Courtney Carver","It’s not the daily increase but daily decrease. Hack away at the unessential. Bruce Lee","Minimalism is not about having less, it’s about making room for more of what matters.","Don’t buy shit you don’t need, with money you don’t have, to impress people you don’t like. Tyler Durden, Fight Club","Our economy is based on spending billions to persuade people that happiness is buying things. Philip Slater","You don’t need to remove clutter if you don’t let it enter your home or office in the first place. Jeri Dansky","Stop trying to impress others with the things that you own. Begin inspiring them by the way you live.","What is minimalism then? It’s living lightly and gracefully on the earth. It’s uncovering who you are. Francine Jay","No ego, no pain. Chien-ju","What we think, we become. Buddha","I don’t mind what happens. Jiddu Krishnamurti","He who is contented is rich. Lao Tzu","Smile, breathe and go slowly. Thich Nhat Hanh","Even monkeys fall from trees. Japanese proverb","Confine yourself to the present. Marcus Aurelius","Enough is abundance to the wise. Euripides","Inhale the future. Exhale the past.","He who knows he has enough is rich. Lao Tzu","Wherever you are, be totally there. Eckart Tolle","Water which is too pure has no fish. Ts’ai Ken T’an","The essence of the Way is detachment. Bodhidharma","Neither seek nor avoid, take what comes. Swami Sivananda","If it comes; let it. If it goes; let it.","Be like a tree. Let the dead leaves drop. Rumi ","The greatest achievement is selflessness.","If all you can do is crawl, start crawling. Rumi","There are no problems without consciousness. Carl Gustav Jung","The quieter you become, the more you can hear. Baba Ram Dass","If you are too busy to laugh, you are too busy.","When the disciple is ready, the master appears. Osho","Everything has beauty, but not everyone sees it. Confucius","The greatest effort is not concerned with results.","Give this moment your attention – and affection. Alex Blackwell","Who looks outside dreams, who looks inside awakens. Carl Gustav Jung","There is no path to happiness. Happiness is the path. Buddha","New beginnings are often disguised as painful endings. Lao Tzu","Awareness is freedom, it brings freedom, it yields freedom. Jiddu Krishnamurti","The only way you can endure your pain is to let it be painful. Shunryu Suzuki","Be not afraid of going slowly, be afraid only of standing still. Chinese proverb","Contentment comes not so much from great wealth as from few wants. Epictetus","Tension is who you think you should be, relaxation is who you are. Chinese proverb","The purpose of religion is to control yourself, not criticize others. Dalai Lama","I believe that the only true religion consists of having a good heart. Dalai Lama","The softest things in the world overcome the hardest things in the world. Lao Tzu","Do not listen with the intent to reply. But with the intent to understand.","A gem cannot be polished without friction, nor a man perfected without trials. Chinese proverb","You have succeeded in life when all you really want is only what you really need. Vernon Howard","Open your mouth only if what you are going to say is more beautiful than silence.","Life is now. There was never a time when your life was not now, nor will there ever be. Eckhart Tolle","When you talk, you are only repeating what you already know. But if you listen, you may learn something new. Dalai Lama","If you are depressed, you are living in the past. If you are anxious, you are living in the future. If you are at peace, you are living in the present. Lao Tzu","Peace is every step. Thich Nhat Hahn","My aim in life is not to judge. Jeanne Moreau","A smile is the beginning of peace. Mother Teresa","Nonviolence is a weapon of the strong. Mohandas Gandhi","Peace is the only battle worth waging. Albert Camus","Nobody can bring you peace but yourself. Ralph Waldo Emerson","Freedom from desire leads to inner peace. Lao Tsu","It is possible to choose peace over worry.","There is no way to peace, peace is the way. A.J. Muste","Peace is costly but it is worth the expense. African proverb","Forgive, son; men are men; they needs must err. Euripides","Peace comes from within. Do not seek it without. Buddha","Let nothing and no one disturb your inner peace. Luminita Saviuc","Peace and justice are two sides of the same coin. Dwight D. Eisenhower","Peace of mind comes from not wanting to change others. Gerald Jampolsky","Don’t hurry. Don’t worry. Do your best and let it rest.","To the mind that is still, the whole universe surrenders. Lao Tzu","I know but one freedom and that is the freedom of the mind. Antoine de Saint-Exupery","Let loose of what you can’t control. Serenity will be yours.","He is happiest, be he king or peasant, who finds peace in his home. Johann Wolfgang von Goethe","Forgiveness does not change the past, but it does enlarge the future. Paul Boese","We must learn to live together as brothers or perish together as fools. Martin Luther King Jr ","Peace cannot be kept by force; it can only be achieved by understanding. Albert Einstein","When the power of love overcomes the love of power the world will know peace. Jimi Hendrix","The ability to observe without evaluating is the highest form of intelligence. Jiddu Krishnamurti","Our task must be to free ourselves by widening our circle of compassion to embrace all living creatures and the whole of nature and its beauty. Albert Einstein","Time discovers truth. Lucius Annaeus Seneca","Truth is a pathless land. Jiddu Krishnamurti","Seek truth and you will find a path. Frank Slaughter","Adversity is the first path to truth. Lord Byron","Falsehood is easy, truth so difficult. George Eliot","Truth is on the side of the oppressed. Malcolm X","The object of the superior man is truth. Confucius","The truth is rarely pure and never simple. Oscar Wilde","Be truthful, nature only sides with truth. Adolf Loos","There is no truth. There is only perception. Gustave Flaubert","We have art in order not to die of the truth. Friedrich Nietzsche","Man is the only creature that refuses to be what he is. Albert Camus","Rather than love, than money, than fame, give me truth. Henry David Thoreau","We search something permanent, something that will last. Jiddu Krishnamurti","Seek not greatness, but seek truth and you will find both. Horace Mann ","To believe in something, and not to live it, is dishonest. Mohandas Gandhi","If you tell the truth, you don’t have to remember anything. Mark Twain","In a time of deceit telling the truth is a revolutionary act. George Orwell","The truth is not for all men, but only for those who seek it. Ayn Rand","The truth will set you free, but first it will make you miserable. James A. Garfield","Do not love leisure. Waste not a minute. Be bold. Realize the Truth, here and now. Swami Sivananda","Truth is always new. Truth is seeing a smile, a person, life, like if it was the first time. Jiddu Krishnamurti","A man who is protecting himself constantly through knowledge is obviously not a truth-seeker. Jiddu Krishnamurti","Be who you are and say what you feel, because those who mind don’t matter, and those who matter don’t mind. Bernard M. Baruch","Know thyself. Socrates","Wisdom begins in wonder. Socrates","If you judge, investigate. Lucius Annaeus Seneca","Doubt grows with knowledge. Johann Wolfgang von Goethe","Everything popular is wrong. Oscar Wilde","What you seek is seeking you. Rumi","Observe all men, thyself most. Benjamin Franklin","Doubt is the origin of wisdom. Augustine of Hippo","Nature does nothing uselessly. Aristotle","Listen to many, speak to a few. William Shakespeare","A closed mouth catches no flies. Miguel de Cervantes","Never confuse motion with action. Benjamin Franklin","I’m wise because I’ve been foolish.","Do what is right, not what is easy.","Silence is true wisdom’s best reply. Euripides","Wisdom comes only through suffering. Aeschylus","A loving heart is the truest wisdom. Charles Dickens","An overflow of good converts to bad. William Shakespeare","To find yourself, think for yourself. Socrates","My life is perfect even when it’s not. Ellen DeGeneres","In teaching others we teach ourselves.","Maturity comes with experience, not age.","Pain is inevitable. Suffering is optional. Haruki Murakami","It is better to travel well than to arrive. Buddha","What’s meant to be will always find a way.","Love is too young to know what conscience is. William Shakespeare","Wisely, and slow. They stumble that run fast. William Shakespeare ","With wisdom, comes the desire for simplicity.","Wise is he who collects the wisdom of others. Juan Guerra Caceras","Nothing has more strength than dire necessity. Euripides","He who would travel happily must travel light. Antoine de Saint-Exupery","When knowledge becomes rigid, it stops living. Anselm Kiefer","Wealth is the ability to fully experience life. Henry David Thoreau","Memory is the old, and it is afraid of the new. Osho","Nothing external to you has any power over you. Ralph Waldo Emerson","The most certain sign of wisdom is cheerfulness. Michel de Montaigne","Not being able to govern events, I govern myself. Michel de Montaigne","The mind is everything. What you think you become. Buddha","Happy is the hearing man; unhappy the speaking man. Ralph Waldo Emerson","Honesty is the first chapter in the book of wisdom. Thomas Jefferson","Who looks outside, dreams; who looks inside, awakes. Carl Gustav Jung","Most powerful is he who has himself in his own power. Lucius Annaeus Seneca","I don’t like that man. I must get to know him better. Abraham Lincoln","Complete abstinence is easier than perfect moderation. Augustine of Hippo","When you give yourself, you receive more than you give. Antoine de Saint-Exupery","If you think you know the answer, you’re far from wise. Trent Hamm","Judge a man by his questions rather than by his answers. Voltaire","We all make choices, but in the end our choices make us.","I am not what happened to me, I am what I choose to become. Carl Gustav Jung","He who knows that enough is enough will always have enough. Lao Tzu","He who knows, does not speak. He who speaks, does not know. Lao Tzu","The wisest man is generally he who thinks himself the least so. Nicolas Baileau","Never let the things you want make you forget the things you have.","Nothing ever goes away until it has taught us what we need to know.","As far as I’m concerned, I prefer silent vice to ostentatious virtue. Albert Einstein","To become a spectator of one’s own life is to escape the suffering of life. Oscar Wilde","A fool thinks himself to be wise, but a wise man knows himself to be a fool. William Shakespeare","Insanity is doing the same thing, over and over again, but expecting different results. Albert Einstein","Whenever you find yourself on the side of the majority, it is time to pause and reflect. Mark Twain","Courage, dear heart. C.S. Lewis","He who is brave is free. Lucius Annaeus Seneca","From caring comes courage. Lao Tzu","Don’t stop until you’re proud.","Courage doesn’t always roar. Mary Anne Radmacher","What keeps me going is goals. Muhammad Ali","Life is tough but so you are.","Fortune and love favor the brave. Ovid","I’m strong because I’ve been weak.","The best way out is always through. Robert Frost","There is no education like adversity. Benjamin Disraeli","One man with courage makes a majority. Andrew Jackson","I’m fearless because I’ve been afraid.","The pain you feel now, will be a strength after some time.","Diligence is the mother of good fortune. Benjamin Disraeli","Because of a great love, one is courageous. Lao Tzu","Tough times never last, but tough people do.","Great deeds are usually wrought at great risks. Herodotus","He that can have patience can have what he will. Benjamin Franklin","Rock bottom has built more heroes than privilege.","I’ve never met a strong person with an easy past.","Things that were hard to bear are sweet to remember. Lucius Annaeus Seneca","Courage is like a muscle; it is strengthened by use. Ruth Gordon","It doesn’t matter how slow you go as long as you don’t stop. Confucius ","Rock bottom became the solid foundation on which I rebuilt my life. J. K. Rowling","The weak can never forgive. Forgiveness is the attribute of the strong. Mahatma Gandhi","Be faithful in small things because it is in them that your strength lies. Mother Teresa","The world breaks everyone, and afterwards many are strong at the broken places. Ernest Hemingway","People cry, not because they’re weak. It’s because they’ve been strong for too long. Johnny Depp","Life is very interesting. In the end, some of your greatest pains become your greatest strengths. Drew Barrymore","Persevere and get it done. George Allen Sr","Never, never, never give up. Winston Churchill","Much effort, much prosperity. Euripides","Slow and steady wins the race.","How long should you try? Until. Jim Rohn","If you don’t ask, you don’t get. Stevie Wonder","Nothing worth having comes easy.","I will not walk backward in life. J. R. R. Tolkien","It’s pain that changes our lives. Steve Martin","Our whole life is solving puzzles. Erno Rubik","The struggle is part of the story.","Persevere in virtue and diligence. Plautus","Life is short and progress is slow. Gabriel Lippmann","No great thing is created suddenly. Epictetus","God helps those who help themselves. Benjamin Franklin","Patience is the companion of wisdom. Augustine of Hippo","Perseverance, secret of all triumphs. Victor Hugo","Victory belongs to the most persevering. Napoleon Bonaparte","I’m a slow walker, but I never walk back. Abraham Lincoln","In the middle of difficulty lies opportunity. Albert Einstein","Never give up on the things that make you smile.","He that can have patience can have what he will. Benjamin Franklin","A lost battle is a battle one thinks one has lost. Jean-Paul Sartre","Perseverance is a virtue that cannot be understated. Bob Riley","The journey of a thousand miles begins with one step. Lao Tzu","You may see me struggle, but you will never see me quit.","Perseverance is failing 19 times and succeeding the 20th. Julie Andrews","Thankfully, persistence is a great substitute for talent. Steve Martin","You get credit for what you finished, not what you started.","I was taught the way of progress is neither swift nor easy. Marie Curie","Persistence is to the character of man as carbon is to steel. Napoleon Hill","A man will fight harder for his interests than for his rights. Napoleon Bonaparte","Anyone who has ever made anything of importance was disciplined. Andrew Hendrixson","Character consists of what you do on the third and fourth tries. James A. Michener","Nothing is permanent in this wicked world, not even our troubles. Charlie Chaplin","No matter how you feel, get up, dress up, show up and never give up.","Don’t quit. Suffer now and live the rest of your life as a champion. Muhammad Ali","Difficult things take a long time, impossible things a little longer.","It’s not that I’m so smart, it’s just that I stay with problems longer. Albert Einstein ","A river cuts through a rock not because of its power but its persistence.","The will to persevere is often the difference between failure and success. David Sarnoff","Ambition is the path to success. Persistence is the vehicle you arrive in. Bill Bradley","Perseverance is not a long race; it is many short races one after the other. Walter Elliot","Patience, persistence and perspiration make an unbeatable combination for success. Napoleon Hill","Through perseverance many people win success out of what seemed destined to be certain failure. Benjamin Disraeli","Perseverance is the hard work you do after you get tired of doing the hard work you already did. Newt Gingrich","It is the cheerful mind that is persevering. It is the strong mind that hews its way through a thousand difficulties. Swami Sivananda","Belief creates the actual fact. William James","Believing requires action. James E. Faust","Prayer is man’s greatest power. W. Clement Stone","To me faith means not worrying. John Dewey","Set goals. Say prayers. Work hard.","Faith is spiritualized imagination. Henry Ward Beecher","Empty yourself and let God fill you.","God gives where he finds empty hands. Augustine of Hippo","Faith is the quiet cousin of courage. Judith Hanson Lasater","Faith makes things possible, not easy. ","In art as in love, instinct is enough. Anatole France","A man of courage is also full of faith. Marcus Tullius Cicero","Faith: not wanting to know what is true. Friedrich Nietzsche","Unless you believe, you will not understand. Augustine of Hippo","I believe life takes us where we need to be. Sasha Alexander","The Lord is greater than the giants you face. John 4.9","If you’re praying about it. God is working on it.","Live your beliefs and you can turn the world around. Henry David Thoreau","Prayer is to be in love, to be in love with the whole. Osho","Do not pray for an easier life, pray to be a stronger man. John F. Kennedy","Faith is not something to grasp, it is a state to grow into. Mahatma Gandhi","Prayer is the key of the morning and the bolt of the evening. Mahatma Gandhi","When someone shows you who they are, believe them the first time. Maya Angelou","Let life happen to you. Believe me: life is in the right, always. Rainer Maria Rilke","Faith is believing in something when common sense tells you not to.","We must accept finite disappointment, but never lose infinite hope. Martin Luther King Jr","Faith is taking the first step even when you don’t see the whole staircase. Martin Luther King Jr","Pursue some path, however narrow and crooked, in which you can walk with love and reverence. Henry David Thoreau","You can totally do this.","Humor comes from self-confidence. Rita Mae Brown","I think you should just go for it.","We are always the same age inside. Gertrude Stein","Trust is the greatest intelligence. Osho","Confidence is one of the sexiest things. Katherine Jenkins","You have to laugh, especially at yourself. Madonna","Confidence is a stain they can’t wipe off. Lil Wayne","All anything takes, really, is confidence. Rachel Ward","Coffee in one hand. Confidence in the other.","Confidence comes from discipline and training. Robert Kiyosaki","A certain death of an artist is overconfidence. Robin Trower","Your energy introduces you before you even speak.","Act as if what you do makes a difference. It does. William James","Confidence is contagious. So is lack of confidence. Vince Lombardi","As is our confidence, so is our capacity. William Hazlitt","Just trust yourself, then you will know how to live. Johann Wolfgang von Goethe","The most beautiful thing you can wear is confidence. Blake Lively","Talk to yourself like you would to someone you love. Brene Brown","Courage is a mean with regard to fear and confidence. Aristotle","A tiger doesn’t lose sleep over the opinion of sheep.","Stop doubting yourself, work hard and make it happen.","With confidence, you have won before you have started. Marcus Garvey","No one can make you feel inferior without your consent. Eleanor Roosevelt","Confidence cannot find a place wherein to rest in safety. Virgil","As soon as you trust yourself, you will know how to live. Johann Wolfgang von Goethe","Confidence is the most important single factor in this game. Jack Nicklaus","Self-confidence is the first requisite to great undertakings. Samuel Johnson ","All you need is ignorance and confidence and the success is sure. Mark Twain","Concentration comes out of a combination of confidence and hunger. Arnold Palmer","I’m always impressed by confidence, kindness and a sense of humor. Tamara Mellon","Nothing builds self-esteem and self-confidence like accomplishment. Thomas Carlyle","The hardest step she ever took was to blindly trust in who she was. Atticus","Inaction breeds doubt and fear. Action breeds confidence and courage. Dale Carnegie","The circulation of confidence is better than the circulation of money. James Madison","I have great faith in fools – self-confidence my friends will call it. Edgar Allan Poe","Too many people overvalue what they are not and undervalue what they are. Malcolm S. Forbes","Confidence in the goodness of another is good proof of one’s own goodness. Michel de Montaigne","Never bend your head. Always hold it high. Look the world straight in the face. Helen Keller","Confidence is not ‘they will like me’. Confidence is ‘I’ll be fine if they don’t’.","I do not believe in taking the right decision, I take a decision and make it right. Muhammad Ali Jinnah","The more you know who you are and what you want, the less you let things upset you.","My confidence comes from the daily grind – training my butt off day in and day out. Hope Solo","A ‘No’ uttered from the deepest conviction is better than a ‘Yes’ merely uttered to please, or worse, to avoid trouble. Mahatma Gandhi","Go wild, for a while.","Creativity takes courage. Henri Matisse","An artist is an explorer. Henri Matisse","Imagination rules the world. Napoleon Bonaparte","Be anything but predictable.","Creativity is not a competition.","Zeal will do more than knowledge. William Hazlitt ","Pure logic is the ruin of the spirit. Antoine de Saint-Exupery","Without freedom, there is no creation. Jiddu Krishnamurti","Creativity comes from a conflict of ideas. Donatella Versace","The man who has no imagination has no wings. Muhammad Ali","Be yourself; everyone else is already taken. Oscar Wilde","The worst enemy to creativity is self-doubt. Sylvia Plath","The chief enemy of creativity is good sense. Pablo Picasso","You were born an original, don’t die a copy.","I like nonsense, it wakes up the brain cells. Dr. Seuss","Name the greatest of all inventors. Accident. Mark Twain","Originality is nothing but judicious imitation. Voltaire","Creativity is the greatest rebellion in existence. Osho","Consistency is the last refuge of the unimaginative. Oscar Wilde","I begin with an idea, and then it becomes something else. Pablo Picasso","Creativity requires the courage to let go of certainties. Erich Fromm","Creativity – like human life itself – begins in darkness. Julia Cameron","In order to be irreplaceable one must always be different. Coco Chanel","Mystery is at the heart of creativity. That, and surprise. Julia Cameron","No great mind has ever existed without a touch of madness. Aristotle","A work of art is the unique result of a unique temperament. Oscar Wilde","The inner fire is the most important thing mankind possesses. Edith Södergran","There is no innovation and creativity without failure. Period. Brene Brown","To live a creative life, we must lose our fear of being wrong. Joseph Chilton Pearce","A man may die, nations may rise and fall, but an idea lives on. John F. Kennedy","The true sign of intelligence is not knowledge but imagination. Albert Einstein","If you want something new, you have to stop doing something old. Peter F. Drucker","Learn the rules like a pro, so you can break them like an artist. Pablo Picasso","It is better to fail in originality than to succeed in imitation. Herman Melville","Fashion’s not about looking back. It’s always about looking forward. Anna Wintour","The monotony and solitude of a quiet life stimulates the creative mind. Albert Einstein","When you do things from your soul, you feel a river moving in you, a joy. Rumi","I never made one of my discoveries through the process of rational thinking. Albert Einstein","If you want something you never had, you have to do something you’ve never done.","Creativity is allowing yourself to make mistakes. Art is knowing which ones to keep. Scott Adams","The doer alone learneth. Friedrich Nietzsche","Be curious. Not judgmental. Walt Whitman","Sometimes you win, sometimes you learn. John Maxwell ","They know enough who know how to learn. Henry Adams","Life is trying things to see if they work.","The only source of knowledge is experience. Albert Einstein","Any fool can know. The point is to understand. Albert Einstein","I never learned from a man who agreed with me. Robert A. Heinlein","Change is the end result of all true learning. Leo Buscaglia","The important thing is not to stop questioning. Albert Einstein","The wise learns many things from their enemies. Aristophanes","As long as you live, keep learning how to live. Lucius Annaeus Seneca","The noblest pleasure is the joy of understanding. Leonardo da Vinci","Blessed are the curious for they shall have adventures.","The most necessary learning is that which unlearns evil. Antisthenes","I have no special talent. I am only passionately curious. Albert Einstein","I am learning all the time. The tombstone will be my diploma. Eartha Kitt","Your most unhappy customers are your greatest source of learning. Bill Gates","Real learning comes about when the competitive spirit has ceased. Jiddu Krishnamurti","It is only when we forget all our learning that we begin to know. Henry David Thoreau","I like to listen. I have learned a great deal from listening carefully. Most people never listen. Ernest Hemingway","Education is soul crafting. Cornel West","Love is a better teacher than duty. Albert Einstein","Nine tenths of education is encouragement. Anatole France","Those who know how to think need no teachers. Mohandas Gandhi","It is a wise father that knows his own child. William Shakespeare","The highest result of education is tolerance. Helen Keller","Teaching is the highest form of understanding. Aristotle","A book is a dream that you hold in your hands. Neil Gaiman","People only see what they are prepared to see. Ralph Waldo Emerson","Nothing ever becomes real till it is experienced. John Keats","A student of life considers the world a classroom. Harvey Mackay","An investment in knowledge pays the best interest. Benjamin Franklin","Don’t let schooling interfere with your education. Mark Twain","Children have more need of models than of critics. Carolyn Coats","Education is the ability to meet life’s situations. Dr. John G. Hibben","If you think education is expensive, try ignorance. Andy McIntyre","The great aim of education is not knowledge but action. Herbert Spencer ","A child educated only at school is an uneducated child. George Santayana","Teachers open the door, but you must enter by yourself. Chinese proverb","Be brave. Take risks. Nothing can substitute experience. Paulo Coelho","Experience, travel. These are an education in themselves. Euripides","The roots of education are bitter, but the fruit is sweet. Aristotle","There is no greater education than one that is self-driven. Neil deGrasse Tyson","The mind unlearns with difficulty what it has long learned. Lucius Annaeus Seneca","Education is not filling a pail but the lighting of a fire. William Butler Yeats","I cannot teach anybody anything, I can only make them think. Socrates","In this life, all you need is for someone to believe in you. J. R. Martinez","Intelligence plus character – that is the goal of true education. Martin Luther King Jr","If you want happiness for a lifetime, help the next generation. Chinese saying","The mind is not a vessel to be filled, but a fire to be kindled. Plutarch","Education is not preparation for life; education is life itself. John Dewey","Educate the children and it won’t be necessary to punish the men. Pythagoras","The world is a book and those who do not travel read only one page. Augustine of Hippo","It’s not that hard to stay grounded. It’s the way I was brought up. Sidney Crosby","Educating the mind without educating the heart is no education at all. Aristotle","Education is the most powerful weapon which you can use to change the world. Nelson Mandela","To be successful in life what you need is education, not literacy and degrees. Munshi Premchand","Education is what remains after one has forgotten what one has learned in school. Albert Einstein","Do not go where the path may lead, go instead where there is no path and leave a trail. Ralph Waldo Emerson","If you want your children to turn out well, spend twice as much time with them, and half as much money. Abigail Van Buren","Work without love is slavery. Mother Teresa","Don’t be busy, be productive.","Forget shortcuts, work for it.","Work to become, not to acquire.","Well done is better than well said.","Go the extra mile – it’s never crowded.","You have to fight to reach your dream. Lionel Messi","Do your duty today and repent tomorrow. Mark Twain","What is once well done is done forever. Henry David Thoreau","Don’t mistake activity with achievement. John Wooden","All happiness depends on courage and work. Honore de Balzac","You are not your resume, you are your work. Seth Godin","Without hard work, nothing grows but weeds. Gordon B. Hinckley","Let the beauty of what you love be what you do. Rumi","Pleasure in the job puts perfection in the work. Aristotle","I learned the value of hard work by working hard. Margaret Mead","Work hard in silence. Let success make the noise.","Work hard, be kind, and amazing things will happen. Conan O’Brien ","Work until you no longer have to introduce yourself.","As a cure for worrying, work is better than whiskey. Ralph Waldo Emerson","The beginning is the most important part of the work. Plato","The reward of one duty is the power to fulfill another. George Eliot","Once you do something you love, you never have to work again. Willie Hill","Nearly everything you do is of no importance, but it is important that you do it. Mohandas Gandhi","Do not hire a man who does your work for money, but him who does it for love of it. Henry David Thoreau","Without work, all life goes rotten. But when work is soulless, life stifles and dies. Albert Camus","Never work just for money or power. They won’t save your soul or help you sleep at night. Marian Wright Edelman","Leadership is influence. John C. Maxwell","One must steer, not talk. Lucius Annaeus Seneca","We rise by lifting others.","A leader is a dealer in hope. Napoleon Bonaparte","To lead people walk behind them. Lao Tzu","A good example is the best sermon. Benjamin Franklin","Anyone can hold the helm when the sea is calm. Publilius Syrus","The speed of the leader is the speed of the gang. Mary Kay Ash","A ruler should be slow to punish and swift to reward. Ovid","He who is not a good servant will not be a good master. Plato","Each person must live their life as a model for others. Rosa Parks","Leaders don’t create followers, they create more leaders. Tom Peters","The strength of the group is the strength of the leaders. Vince Lombardi","You don’t have to hold a position in order to be a leader. Henry Ford","Build your reputation by helping other people build theirs. Anthony J. D’Angelo","Leadership is the capacity to translate vision into reality. Warren Bennis","When you can’t make them see the light, make them feel the heat. Ronald Reagan ","Keep your fears to yourself, but share your courage with others. Robert Louis Stevenson","To handle yourself, use your head; to handle others, use your heart. Eleanor Roosevelt","To be a leader, bring certainty, to an environment where there isn’t any. Tony Robbins","Example is not the main thing in influencing others. It is the only thing. Albert Schweitzer","A genuine leader is not a searcher for consensus but a molder of consensus. Martin Luther King Jr","May you live your life as if the maxim of your actions were to become universal law. Immanuel Kant","If your actions inspire others to dream more, learn more, do more and become more, you are a leader.","Attitude is everything. Charles Swindoll","Be groovy or leave, man. Bob Dylan","A true man hates no one. Napoleon Bonaparte","What you are comes to you. Ralph Waldo Emerson","Who sows virtue reaps honor. Leonardo da Vinci","Don’t find fault, find a remedy. Henry Ford","A great mind becomes a great fortune. Lucius Annaeus Seneca","Humor is mankind’s greatest blessing. Mark Twain","The greatest remedy for anger is delay. Lucius Annaeus Seneca","Love all, trust a few, do wrong to none. William Shakespeare","Showing off is the fool’s idea of glory. Bruce Lee","Let’s not be narrow, nasty, and negative. T. S. Eliot","Be someone who you would want to be around. Craig Jarrow","Energy and persistence conquer all things. Benjamin Franklin","A great man is always willing to be little. Ralph Waldo Emerson ","Ethics is nothing else than reverence for life. Albert Schweitzer","Humility is the solid foundation of all virtues. Confucius","Goodness is the only investment that never fails. Henry David Thoreau","Be true to your work, your word, and your friend. Henry David Thoreau","A quick temper will make a fool of you soon enough. Bruce Lee","Nothing great was ever achieved without enthusiasm. Ralph Waldo Emerson","Knowledge will give you power, but character respect. Bruce Lee","Strive not to be a success, but rather to be of value. Albert Einstein","Swallow your pride, you will not die, it’s not poison. Bob Dylan","Attention is the rarest and purest form of generosity.","Attitude is a little thing that makes a big difference. Winston Churchill","Don’t talk, act. Don’t say, show. Don’t promise, prove.","Remind yourself that your task is to be a good human being. Marcus Aurelius","Be careless in your dress if you will, but keep a tidy soul. Mark Twain","Let us train our minds to desire what the situation demands. Lucius Annaeus Seneca","Really great people make you feel that you, too, can become great. Mark Twain","Waste no more time arguing about what a good man should be. Be one. Marcus Aurelius","Being both soft and strong is a combination very few have mastered.","The firm, the enduring, the simple, and the modest are near to virtue. Confucius","Life is good when we think it’s good. Life is bad when we don’t think. Douglas Horton","Drop all your scientific attitudes. Become a little more fluid, more melting, more merging. Osho","Instead of asking ‘what do I want from life?’, a more powerful question is, ‘what does life want from me?’. Eckhart Tolle","To hold a pen is to be at war. Voltaire","Easy reading is damn hard writing. Nathaniel Hawthorne","Write what should not be forgotten. Isabel Allende","The first draft of anything is shit. Ernest Hemingway","An author, behind his words, is naked. Terri Guillemets","Tears are words that need to be written. Paulo Coelho","If it sounds like writing, I rewrite it. Elmore Leonard","Every writer I know has trouble writing. Joseph Heller","The wastebasket is a writer’s best friend. Isaac Bashevis Singer","A word after a word after a word is power. Margaret Atwood","If I don’t write to empty my mind, I go mad. Lord Byron","The best style is the style you don’t notice. Somerset Maugham","Fill your paper with the breathings of your heart. William Wordsworth","The scariest moment is always just before you start. Stephen King","A professional writer is an amateur who didn’t quit. Richard Bach","You must stay drunk on writing so reality cannot destroy you. Ray Bradbury","One day I will find the right words, and they will be simple. Jack Kerouac ","We write to taste life twice, in the moment and in retrospect. Anaïs Nin","The art of writing is the art of discovering what you believe. Gustave Flaubert","There is no greater agony than bearing an untold story inside you. Maya Angelou","There is no real ending. It’s just the place where you stop the story. Frank Herbert","Writing is an exploration. You start from nothing and learn as you go. E. L. Doctorow","The purpose of a writer is to keep civilization from destroying itself. Albert Camus","The most beautiful things are those that madness prompts and reason writes. André Gide","There is nothing to writing. All you do is sit down at a typewriter and bleed. Ernest Hemingway","Write with conviction. Pick a side and be bold. And if you’re wrong, admit it. Jeff Goins","Imagination is like a muscle. I found out that the more I wrote, the bigger it got. Philip Jose Farmer","We have to continually be jumping off cliffs and developing our wings on the way down. Kurt Vonnegut","All you have to do is write one true sentence. Write the truest sentence that you know. Ernest Hemingway","Better to write for yourself and have no public, than to write for the public and have no self. Cyril Connolly","Change before you have to. Jack Welch","To say goodbye is to die a little. Raymond Chandler","There is nothing so stable as change. Bob Dylan","It is in changing that we find purpose. Heraclitus","Every day is a chance to change your life.","In a gentle way, you can shake the world. Mahatma Gandhi","Our only security is our ability to change. John Lilly","Change your thoughts and you change your world. Norman Vincent Peale","Intelligence is the ability to adapt to change. Stephen Hawking","No map is possible because life goes on changing. Osho","If it doesn’t challenge you, it won’t change you.","It is never too late to be what you might have been. George Eliot","Change is not merely necessary to life – it is life. Alvin Toffler","If you want to make enemies, try to change something. Woodrow Wilson","Failure is not fatal, but failure to change might be. John Wooden","You affect your subconscious mind by verbal repetition. W. Clement Stone","When you blame others, you give up your power to change. Robert Anthony","It is not necessary to change. Survival is not mandatory. W. Edwards Deming ","Prayer does not change God, but it changes him who prays. Soren Kierkegaard","To improve is to change; to be perfect is to change often. Winston Churchill","To change one’s life: Start immediately. Do it flamboyantly. William James","Only the new, accepted deeply and totally, can transform you. Osho","No matter what people tell you, words and ideas can change the world. Robin Williams","Life belongs to the living, and he who lives must be prepared for changes. Johann Wolfgang von Goethe","Let your smile change the world, but don’t let the world change your smile.","The world hates change, yet it is the only thing that has brought progress. Charles Kettering","To change the world I have to change myself, break away from my conditioning. Jiddu Krishnamurti","Everyone thinks of changing the world, but no one thinks of changing himself. Leo Tolstoy","You can’t start the next chapter of your life if you keep re-reading the last one.","The ones who are crazy enough to think they can change the world are the ones who do. Steve Jobs","The secret of change is to focus all of your energy, not on fighting the old, but on building the new. Socrates","Much effort, much prosperity. Euripides","Make your life a masterpiece. Brian Tracy","Success is the child of audacity. Benjamin Disraeli","The best revenge is massive success. Franck Sinatra","A goal without a plan is just a wish. Antoine de Saint-Exupery","We aim above the mark to hit the mark. Ralph Waldo Emerson","I never dream of success. I worked for it. Estee Lauder","The harder the battle the sweeter the victory. Bob Marley","Action is the foundational key to all success. Pablo Picasso","The secret of success is constancy of purpose. Benjamin Disraeli","What you think today is what you live tomorrow. Remez Sasson","Success is where preparation and opportunity meet. Bobby Unser","Be content to act, and leave the talking to others. Baltasar","Success is how high you bounce when you hit bottom. George S. Patton","No one knows what to say in the loser’s locker room. Muhammad Ali","If you have no critics you’ll likely have no success. Malcolm X","Everybody pities the weak; jealousy you have to earn. Arnold Schwarzenegger","The measure of success is happiness and peace of mind. Bobby Davro","I couldn’t wait for success, so I went ahead without it. Jonathan Winters","Start where you are. Use what you have. Do what you can. Arthur Ashe","Before anything else, preparation is the key to success. Alexander Graham Bell","Success is the accumulation of small advantages over time. Aaron Lynn","The path to success is to take massive, determined action. Tony Robbins","The secret of my success is a two word answer: Know people. Harvey S. Firestone","Don’t let what you cannot do interfere with what you can do. John R. Wooden","I find that the harder I work, the more luck I seem to have. Thomas Jefferson ","It’s not whether you get knocked down, it’s whether you get up. Vince Lombardi","Judge your success by what you had to give up in order to get it. Dalai Lama","The successful warrior is the average man, with laser-like focus. Bruce Lee","I attribute my success to this – I never gave or took any excuse. Florence Nightingale","My success isn’t a result of arrogance – it’s a result of belief. Conor McGregor","Success is the sum of small efforts, repeated day in and day out. Robert Collier","I always wanted to be the best and to get the most out of myself. Sidney Crosby","Success is only meaningful and enjoyable if it feels like your own. Michelle Obama","Success is largely a matter of holding on after others have let go. William Feather","Success usually comes to those who are too busy to be looking for it. Henry David Thoreau","I want to be the best, so whatever comes with that, I’ll have to accept. Sidney Crosby","Success is nothing more than a few simple disciplines, practiced every day. Jim Rohn","I’ve failed over and over and over again in my life and that is why I succeed. Michael Jordan","Success is the ability to go from failure to failure without losing your enthusiasm. Winston Churchill","Fear and time are inseparable. Jiddu Krishnamurti","Fear is stupid. So are regrets. Marilyn Monroe","Where fear is, happiness is not. Lucius Annaeus Seneca","Take every chance. Drop every fear.","Always do what you are afraid to do. Ralph Waldo Emerson","Fear makes the wolf bigger than he is. German proverb","Fear is the voice of the rational mind.","Fear is destructive; love is a creative energy. Osho","If it scares you, it might be a good thing to try. Seth Godin","Limits, like fear, is often an illusion. Michael Jordan","Fear tricks us into living a boring life. Donald Miller","To conquer fear is the beginning of wisdom. Bertrand Russell","People living deeply have no fear of death. Anaïs Nin","I’ll tell you what freedom is to me: no fear.","Fear is temporary. Regrets last forever.","The only thing we have to fear is fear itself. Franklin D. Roosevelt","Thinking will not overcome fear but action will. W. Clement Stone","Curiosity will conquer fear even more than bravery will. James Stephens","The constant assertion of belief is an indication of fear. Jiddu Krishnamurti","Everything you’ve ever wanted is on the other side of fear. George Addair","Nothing in life is to be feared. It is only to be understood. Marie Curie","The mind that is always after explanations is an afraid mind. Osho","Sometimes the fear won’t go away, so you’ll have to do it afraid. ","Courage is resistance to fear, mastery of fear, not absence of fear. Mark Twain","Fear has two meanings – Forget Everything And Run or Face Everything And Rise.","Fear is the absence of love. Do something with love, forget about fear. If you love well, fear disappears. Osho","Don’t worry, be happy. Bobby McFerrin","Worry less, smile more.","Pray, and let God worry. Martin Luther","What worries you, masters you. John Locke","Anxiety is the dizziness of freedom. Soren Kierkegaard","It’s ok to worry – it means you care. ","The sovereign cure for worry is prayer. William James","Worry often gives a small thing a big shadow. Swedish proverb","Most things I worry about never happen anyway. Tom Petty","You can destroy your now by worrying about tomorrow. Janis Joplin","I never worry about action, but only about inaction. Winston Churchill","As a cure for worrying, work is better than whiskey. Thomas A. Edison","A day of worry is more exhausting than a day of work. John Lubbock","The mind that is anxious about the future is miserable. Lucius Annaeus Seneca","I try not to worry about things I can’t do anything about. Christopher Walken","Worry is a useless mulling over of things we cannot change. Peace Pilgrim","We want predictability, even though it’s impossible to get. Henri Junttila","The problem is that worrying doesn’t actually solve anything. Celestine Chua","Let our advance worrying become advance thinking and planning. Winston Churchill","Throw off your worries when you throw off your clothes at night. Napoleon Bonaparte","Worry never robs tomorrow of its sorrow, it only saps today of its joy. Leo Buscaglia","My life has been full of terrible misfortunes most of which never happened. Michel de Montaigne","Worry is like a rocking chair: it gives you something to do but never gets you anywhere. Erma Bombeck","Stumbling is not falling. Malcolm X","Turn your wounds into wisdom. Oprah Winfrey","Better an ‘oops’ than a ‘what if’.","Failure’s a natural part of life. John Malkovich","Giving up is the greatest failure. Jack Ma","Not failure, but low aim, is crime. James Russell Lowell","If you never try you’ll never know.","I never lose. Either I win or I learn.","Mistakes are the portals of discovery. James Joyce","Avoiding failure is to avoid progress.","My reputation grows with every failure. George Bernard Shaw","Failure is success if we learn from it. Malcolm Forbes","Reward worthy failure – experimentation. Bill Gates","Failure is a detour, not a dead-end street. Zig Ziglar","Experience is the name we give to our mistakes. Oscar Wilde","Remember that failure is an event, not a person. Zig Ziglar","There are no mistakes or failures, only lessons. Denis Waitley","Fear of failure has always been my best motivator. Douglas Wood","Failure is not falling down but refusing to get up. Chinese proverb","You have to be able to accept failure to get better. LeBron James","Failure is not fatal, but failure to change might be. John Wooden","There are some defeats more triumphant than victories. Michel de Montaigne","Failure is the condiment that gives success its flavor. Truman Capote","Success is not a good teacher, failure makes you humble. Shahrukh Khan","The sooner you fail, the less afraid you are to fail again. Brendan Baker","Error is just as important a condition of life as truth. Carl Gustav Jung","Once you can accept failure, you can have fun and success. Rickey Henderson","Testing leads to failure, and failure leads to understanding. Burt Rutan","Ambitious failure, magnificent failure, is a very good thing. Guy Kawasaki","Do not fear mistakes. You will know failure. Continue to reach out. Benjamin Franklin","Life is a succession of lessons which must be lived to be understood. Helen Keller ","The season of failure is the best time for sowing the seeds of success. Paramahansa Yogananda","You get knocked down, you get up, brush yourself off, and you get back to work. Barack Obama","I’d rather be a failure at something I love than a success at something I hate. George Burns","The only failure one should fear, is not hugging to the purpose they see as best. George Eliot","Regrets belong to the past. Marlon Brando","Life’s too short for regrets. Nicholas Hoult","Remorse is the poison of life. Charlotte Bronte","You will never regret being kind.","My head has got regrets, but I haven’t. Frank Bruno","There are no regrets in life, just lessons. Jennifer Aniston","Never regret something that made you smile.","Regret for wasted time is more wasted time. Mason Cooley","Fear is only temporary. Regrets last forever. ","Regrets are ridiculous, so I don’t regret, no. Nicole Kidman","Regrets are the natural property of grey hairs. Charles Dickens","I have often regretted my speech, never my silence. Publilius Syrus","In the end, we only regret the chances we didn’t take.","Never look back unless you are planning to go that way. Henry David Thoreau","A man is not old until regrets take the place of dreams. John Barrymore","Never make permanent decisions based on temporary feelings.","Before it’s too late, tell them everything you’ve ever wanted to say.","Never regret anything because one time it was exactly what you wanted.","I don’t regret a thing I’ve done. I only regret the things I didn’t do. Ingrid Bergman","Be so good they can’t ignore you. Steve Martin","Be happy. It drives people crazy.","Silence is the best reply to a fool.","The haters always scream the loudest. Tucker Max","They told me I couldn’t. That’s why I did.","I don’t have to be what you want me to be. Muhammad Ali","Your opinion of me doesn’t define who I am.","Hustle until your haters ask if you’re hiring.","Learn not to give a fuck, you will be happier.","To refrain from imitation is the best revenge. Marcus Aurelius","Have you ever met a hater doing better than you?","I destroy my enemies when I make them my friends. Abraham Lincoln","You never look good trying to make someone look bad.","Ask for help, they laugh. Do it yourself, they hate.","Haters keep on hating, cause somebody’s gotta do it. Chris Brown","Always forgive your enemies. Nothing annoys them so much. Oscar Wilde ","Your love makes me strong, your hate makes me unstoppable. Cristiano Ronaldo","If they don’t know you personally, don’t take it personal.","You pick up some fans and a handful of haters along the way. Bruno Mars","The best revenge is to be unlike him who performed the injury. Marcus Aurelius","Dear haters, I’m flattered that I’m a trending topic in your life.","Whenever you are confronted with an opponent. Conquer him with love. Mohandas Gandhi","Don’t worry about those who talk behind your back, they’re behind you for a reason.","A hater is nothing but a fan. They just don’t know how to express it in positive way. Bar Refaeli","Haters don’t really hate you, they hate themselves. You’re a reflection of what they wish to be.","I’m thankful for all those difficult people in my life, they have shown me exactly who I don’t want to be.","Doubts are death. Maharishi Mahesh Yogi","Inactivity is death. Benito Mussolini","Security is a kind of death. Tennessee Williams","My life, my death, my choice. Terry Pratchett","Death is a debt we all must pay. Euripides","Death is the final wake-up call. Douglas Horton","Death, only, renders hope futile. Edgar Rice Burroughs","Every man dies. Not every man lives. William Wallace","Death is the beginning of something. Edith Piaf","Our business is with life, not death. George Wald","I don’t want to die without any scars. Chuck Palahniuk","Death is a distant rumor to the young. Andrew A. Rooney","Death is just life’s next big adventure. J. K. Rowling","Enjoy life now – one day you’ll be dead.","He who doesn’t fear death dies only once. Giovanni Falcone","Grief does not change you, it reveals you. John Green","Death is frightening, and so is Eternal Life. Mason Cooley","The idea is to die young as late as possible. Ashley Montagu","I would rather die of passion than of boredom. Vincent van Gogh","You cannot save people, you can only love them.","I feel monotony and death to be almost the same. Charlotte Bronte","If by my life or death I can protect you, I will. J. R. R. Tolkien","Guilt is perhaps the most painful companion of death. Coco Chanel","A man who won’t die for something is not fit to live. Martin Luther King Jr","A man who lives fully is prepared to die at any time. Mark Twain","Do not fear death so much but rather the inadequate life. Bertolt Brecht","The death of something can become your greatest strength.","A thing is not necessarily true because a man dies for it. Oscar Wilde","Even death is not to be feared by one who has lived wisely. Buddha","I have no fear of death. More important, I don’t fear life. Steven Seagal","Our dead are never dead to us, until we have forgotten them. George Eliot","My fear was not of death itself, but a death without meaning. Huey Newton","Don’t take life too seriously. You’ll never get out of it alive. Elbert Hubbard ","Death is the only pure, beautiful conclusion of a great passion. D. H. Lawrence","Take care of your life and the Lord will take care of your death. George Whitefield","To the well-organized mind, death is but the next great adventure. J.K. Rowling","If life must not be taken too seriously, then so neither must death. Samuel Butler","It is not death or pain that is to be dreaded, but the fear of pain or death. Epictetus","It is the unknown we fear when we look upon death and darkness, nothing more. J.K. Rowling","We all die. The goal isn’t to live forever, the goal is to create something that will. Chuck Palahniuk","Life is too short to wait. ","Life is too short to worry.","Well, you and I only have one life.","Life is too short to be little. Benjamin Disraeli","Life is too short to be serious.","Life is too short to be miserable. Rita Mae Brown","Life is too short not to experiment. Jamelia","Life is short. Do stuff that matters.","Life is too short to even care at all.","Life is a one-time offer. Use it well.","Smile. Life is too short to be unhappy.","Don’t wait. Life goes faster than you think.","Time flies, whether you’re wasting it or not. Crystal Woods","Go for it now. The future is promised to no one. Wayne Dyer","Expect an early death – it will keep you busier. Martin H. Fischer","Life is short. Smile while you still have teeth.","Life is too short to spend it at war with yourself.","Life is so, so short. Bible says it’s like a vapor. Muhammad Ali","Life is too short to harbor any hostilities towards anybody. Peabo Bryson","Holding a grudge is letting someone live rent-free in your head.","Be patient and understanding. Life is too short to be vengeful or malicious. Phillips Brooks","Life is too short to hide your feelings. Don’t be afraid to say what you feel.","Life is so short, so beautiful. Don’t be so serious about the work. Enjoy the life. Jack Ma ","Life is too short to worry about stupid things. Have fun. Regret nothing, and don’t let people bring you down."];

if (usag !== 'edge') allJokes = [];

// ============================================================
// [[[[[[ ENTRY POINT ]]]]]] -- From: resteem-users-links.js
function processUsersComments(takeNap, w, allResteemsForPostDone, allResteemsForPostHasFailure) {
  try {
    readComments(() => {
      if (!users.length) {
        allResteemsForPostDone();
        return;
      }
      replyToPost(() => {
        startResteems(w, allResteemsForPostDone, allResteemsForPostHasFailure);
      }, w);
    }, takeNap, w);
  } catch (err) { // replyToPost and startResteems/execService don't throw errs (only write in LS)
    allResteemsForPostHasFailure(err);
  }
}

let oldSeparatorDelBtn = null;
let anchorsComments = [];
let toResteem = {};
let upvotedLinks = {};
let users = [];
let firstTenToUpvAndFollow = [];
let commentIds = [];
let blacklist = ['resteem.bot','samarth7080'];

async function readComments(k, takeNap = true, w) {
  const target = w ? w.document : document;
  try {
    if (usag === 'chrome') {
      const msg = 'What the hell r u doing? You\'re on your (only semi-bot) main account!';
      alert(msg);
      throw msg;
    }

    await expandIfMyPostAndHidden(w, 'some--user');

    // RESET VARS
    oldSeparatorDelBtn = null;
    toResteem = {};
    upvotedLinks = {};
    users = [];
    firstTenToUpvAndFollow = [];
    failed = [], warnings = [];

    const commentsSection = target.getElementsByClassName('Post_comments__content')[0];
    if (!commentsSection) throw new Error('Cannot run readComments on this page, no comments section!');
    logsOn && console.debug('Getting links from comments..');
    await nap(2000); // in case page not fully loaded?
    anchorsComments = commentsSection.getElementsByTagName('a');
    commentIds = Object.keys(anchorsComments);
    const lastAnchor = anchorsComments[commentIds[commentIds.length - 5]];

    if (!lastAnchor) { // || isMySeparator(lastAnchor)) // removed to allow upvoted comments
      logsOn && console.debug('>>>>> NO LINKS ON YOUR POST YET.');
      k();
    }
    if (takeNap) {
      // [-- DELAYS (to avoid resources congestion) --]
      if (usag === 'opr') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 360 secs = 6 mins ======= ]]=`);
        await nap(360000);
      } else if (usag === 'edge') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 900 secs = 15 min ======= ]]=`);
        await nap(900000);
      }
    }
    let skipNext = false;
    commentIds.forEach((idx) => {
      const anchor = anchorsComments[idx];
      if (isMySeparator(anchor)) {
        // comments already resteemed, discard what found so far:
        toResteem = {};
        if (commentIds.length > +idx + 6 && !anchor.alreadyRemoved) {
          if (!skipNext) {
            logsOn && console.debug(`${now()} -- Found old separator.`);
            const anchors = anchor.offsetParent.querySelectorAll('a');
            const delBtn = anchors[anchors.length - 1];
            oldSeparatorDelBtn = delBtn;
          }
          skipNext = skipNext ? false : true;
        }
        return;
      }
      const rightLink = anchor.href && anchor.href.split('/').length > 4 && notMine(anchor);
      const parent = anchor.offsetParent && anchor.offsetParent.id;
      if ( anchor.href && (anchor.href.indexOf('https://steemit.com/') !== -1 || anchor.href.indexOf('partiko.app') !== -1)
           && parent && rightLink ) {
        const parentArr = parent.split('/');
        const user = parentArr[0].substr(2, parentArr[0].length -1);
        if (usag !== 'opr'
          && firstTenToUpvAndFollow.length < 5 // 10
          && firstTenToUpvAndFollow.indexOf(user) == -1
          && blacklist.indexOf(user) == -1) {
            firstTenToUpvAndFollow.push(user);
        }
        const notAchildComment = parentArr[1].indexOf('/re-gasaeightyfive') == -1
          || parentArr[1].indexOf('/re-marcocasario')  == -1 || parentArr[1].indexOf('/re-cribbio') == -1;
        const link = anchor.href;
        // avoid double links for same user
        if (Object.keys(toResteem).indexOf(user) == -1 && notAchildComment
            && blacklist.indexOf(user) == -1
            && link.indexOf('@resteem.bot') == -1 && link.indexOf('@marcocasario') == -1 && link.indexOf('@rcr.bis') == -1
            && link.indexOf('/trending/') == -1 && link.indexOf('/byteball/') == -1 && link.indexOf('/created/') == -1) {
          if (anchor.offsetParent.textContent.indexOf(' vote') !== -1 &&
            anchor.offsetParent.textContent.indexOf('Reply') !== -1) {
              upvotedLinks[user] = link;
          } else {
            toResteem[user] = link;
          }
        }
      }
    });
    toResteem = Object.assign({}, toResteem, upvotedLinks);
    users = Object.keys(toResteem);
    logsOn && console.debug(`${now()} -- Links to resteem: ${Object.keys(toResteem).length}
      Users: ${JSON.stringify(users)}`); // -->> ${JSON.stringify(toResteem)}
    k();
  } catch (err) {
    logsOn && console.error(`>>> ${err}`);
    localStorage.setItem(`errors-readComments-${formatDate(new Date().getTime())}`, err);
    throw new Error(`readComments -> ${err}`);
  }
}

// ============================================================
const separators = () => ({ // ${Math.random()>=0.5?'':''} // check isMySeparator though!
  firefox: `-----
  <br>Resteems & Upvotes done guys${Math.random()>=0.5?', thanks':''}.`,
  opr: `${Math.random()>=0.5?'#':''} Thanks guys, resteems and upvotes done so far.`,
  edge: `> Reminder: ${Math.random()>=0.5?'resteemed':'re-steemed'} already until this comment`,
});

let taggedUsersStrOpr = '';
let taggedUsersStrFox = '';
let taggedUsersStrFox_old = '';
let taggedUsersStrOpr_old = '';

async function replyToPost(k, w) {
  k();
  return;

  // MI SONO ROTTO IL CAZZO. NO SPAM. BJSS HA PRENOTATO L'APPARTAMENTO DI LUSSO E TE STAI ANCORA QUI A GIOCARE CON STEEMIT E CODICE DI BASSA QUALITA' USANDO CRAPPY-JAVASCRIPT
  let target = w ? w.document : document;
  const upvotedLinksKeys = Object.keys(upvotedLinks);
  if (users.length === 1 || (users.length === upvotedLinksKeys.length && users.every(user => upvotedLinksKeys.indexOf(user) > -1))) {
    logsOn && console.debug(`${now()} -- Only self upvoted users or just one - not leaving comment.`);
    k();
    return;
  }
  try {
    logsOn && console.debug('Deleting old separator.. (but actually only on FOX)');
    if (oldSeparatorDelBtn && usag === 'firefox' && false /* LEAVE IT THERE */) {
      try {
        oldSeparatorDelBtn.click();
        await nap(2000);
        const confirmBtn = target.getElementsByClassName('ConfirmTransactionForm')[0].children[4];
        confirmBtn.click();
        await nap(3000);
      } catch (err) {
        logsOn && console.error('err =============> Unable to delete old separator! Continuing..');
      }
    }
    oldSeparatorDelBtn = null;
    let usersList = [];
    let myComment = separators()[usag];
    if (usag === 'opr') {
      if (users.length === 1) myComment = 'Thanks, done!';
      taggedUsersStrOpr_old = taggedUsersStrOpr;
      usersList = users.filter(e =>
        !Object.keys(upvotedLinks).includes(e) && blacklist.indexOf(e) === -1
      );
      taggedUsersStrOpr = usersList.join(', ');
      if (taggedUsersStrOpr_old === taggedUsersStrOpr) { k(); return console.debug(`Skipping spamming comment - it has same users`); }
      myComment += `\n${taggedUsersStrOpr}`;
    } else if (usag === 'firefox') {
      taggedUsersStrFox_old = taggedUsersStrFox_old;
      usersList = firstTenToUpvAndFollow.filter(e => blacklist.indexOf(e) == -1);
      taggedUsersStrFox = usersList.join('\n - ');
      if (taggedUsersStrFox_old === taggedUsersStrFox_old) { k(); return console.debug(`Skipping spamming comment - it has same users`); }
      myComment += `<h5>Report:</h5>
Resteemed + Upvoted & Followed:
- ${taggedUsersStrFox}
${users.length <= 10 ? '' : `
Resteemed only:
${users.filter(e => !firstTenToUpvAndFollow.includes(e)
  && blacklist.indexOf(e) == -1).join('\n- ')}`}`;
      // logsOn && console.debug('Hack to comment on current (wallet) page - workaround for IE');
      // target = document;
      // await hackToCreatePostInIE(w); // doesnt work adding fake link, would have to scroll done until found
    }
    if (usersList.length === 1) {
      k();
      return console.debug(`skipping comment with just one user.`);
    }
    logsOn && console.debug(`${now()} -- Adding comment: ${myComment}`);
    let replyBtn = target.getElementsByClassName('PostFull__reply')[0]
      .getElementsByTagName('a')[0];
    replyBtn.click();
    await nap(1000);
    let textarea = target.getElementsByTagName('textarea')[0];
    setNativeValue(textarea, myComment, usag === 'edge' && w);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    await nap(500);
    let postReplyBtn = target.querySelectorAll('[type=submit]')[1];
    // postReplyBtn.disabled = false;
    postReplyBtn.click();
    await nap(2000);

    // await hackToCreatePostInIE(null);
  } catch (err) {
    logsOn && console.error(`>>> ${err}`);
    localStorage.setItem(`errors-replyToPost-${formatDate(new Date().getTime())}`, err);
    // no throw err; // more important to continue the resteems..
  }
  k();
}

// NOT USED ANYMORE, fixing setNativeValue.. <<<<<<<<<<<<
async function hackToCreatePostInIE (w) {
  logsOn && console.debug('Opening the dropdown menu..');
  var drop = document.getElementsByClassName('DropdownMenu Header__usermenu left')[0]
  drop.firstChild.click();
  await nap(1000);

  let linkOfPostToOpen;
  if (w === null) {
    return 'PS. NOT OPENING WALLET ANYMORE BECAUSE NOW ITS ON A NEW SITE';
    logsOn && console.debug('Navigating back to the wallet page clicking on wallet button..');
    var blogBtn = document.getElementsByClassName('VerticalMenu menu vertical VerticalMenu')[0]
      .getElementsByTagName('li')[5].firstChild
    blogBtn.click();
    await nap(5000);
    return;
  } else if (w.window) {
    linkOfPostToOpen = w.window.location.href.split('https://steemit.com')[1];
  } else {
    linkOfPostToOpen = w;
  }

  // if (window.location.href !== `https://steemit.com/@${accounts}`) {
    logsOn && console.debug('Clicking on the blog button..');
    var blogBtn = document.getElementsByClassName('VerticalMenu menu vertical VerticalMenu')[0]
      .getElementsByTagName('li')[2].firstChild
    blogBtn.click();
    await nap(5000);
  // }

  // linkOfPostToOpen injected here (twice) VVV
  var myElementToClickToEventuallyComment = `<div class="articles__summary"><div class="articles__resteem"><p class="articles__resteem-text"><span class="articles__resteem-icon"><span class="Icon reblog" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" style="enable-background:new 0 0 512 512;" viewBox="0 0 512 512" x="0px" y="0px" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><path d="M 448 192 l -128 96 v -64 H 128 v 128 h 248 c 4.4 0 8 3.6 8 8 v 48 c 0 4.4 -3.6 8 -8 8 H 72 c -4.4 0 -8 -3.6 -8 -8 V 168 c 0 -4.4 3.6 -8 8 -8 h 248 V 96 L 448 192 Z" /></svg></span></span><!-- react-text: 1353 -->resteemed<!-- /react-text --></p></div><div class="articles__summary-header"><div class="user"><div class="user__col user__col--left"><a class="user__link" href="/@la2410"><div class="Userpic" style='background-image: url("https://steemitimages.com/u/la2410/avatar/small");'></div></a></div><div class="user__col user__col--right"><span class="user__name"><span class="author" itemtype="http://schema.org/Person" itemscope="" itemprop="author"><strong><a href="/@la2410">la2410</a></strong><!-- react-text: 1364 --> <!-- /react-text --><span title="Reputation" class="Reputation"><!-- react-text: 1366 -->(<!-- /react-text --><!-- react-text: 1367 -->40<!-- /react-text --><!-- react-text: 1368 -->)<!-- /react-text --></span></span></span><span class="articles__tag-link"><!-- react-text: 1370 -->in<!-- /react-text --><!-- react-text: 1371 -->&nbsp;<!-- /react-text --><a href="/trending/resteem">resteem</a><!-- react-text: 1373 -->&nbsp;•&nbsp;<!-- /react-text --></span><a class="timestamp__link" href="/resteem/@la2410/free-resteem-and-upvote-service-to-839-followers"><span class="timestamp__time"><span title="‎7‎/‎9‎/‎2018 ‎3‎:‎29‎ ‎PM" class="updated"><span>3 days ago</span></span></span></a></div></div><div class="articles__flag clearfix"><span class="Voting"><span class="Voting__button Voting__button-down"><span class="Voting__button-downvotes">•</span><a title="Flag" class="flag" id="revoke_downvote_button" href="#"><span class="Icon flag1 flag" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" viewBox="0 0 512 512" x="0px" y="0px" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><g><path d="M 368 112 c -11 1.4 -24.9 3.5 -39.7 3.5 c -23.1 0 -44 -5.7 -65.2 -10.2 c -21.5 -4.6 -43.7 -9.3 -67.2 -9.3 c -46.9 0 -62.8 10.1 -64.4 11.2 l -3.4 2.4 v 2.6 v 161.7 V 416 h 16 V 272.7 c 6 -2.5 21.8 -6.9 51.9 -6.9 c 21.8 0 42.2 8.3 63.9 13 c 22 4.7 44.8 9.6 69.5 9.6 c 14.7 0 27.7 -2 38.7 -3.3 c 6 -0.7 11.3 -1.4 16 -2.2 V 126 v -16.5 C 379.4 110.4 374 111.2 368 112 Z M 368 269 c -11 1.4 -23.9 3.5 -38.7 3.5 c -23.1 0 -45 -4.7 -66.2 -9.2 c -21.5 -4.6 -43.6 -13.3 -67.1 -13.3 c -25.7 0 -41.9 3 -51.9 6 V 118.7 c 6 -2.5 21.9 -6.8 51.9 -6.8 c 21.8 0 42.2 4.3 63.9 9 c 22 4.7 43.8 10.6 68.5 10.6 c 14.7 0 28.7 -2 39.7 -3.3 L 368 269 L 368 269 Z" /></g></svg></span></a></span></span></div></div><div class="articles__content hentry with-image " itemtype="http://schema.org/blogPost" itemscope=""><div class="articles__content-block articles__content-block--img"><a class="articles__link" href="/resteem/@la2410/free-resteem-and-upvote-service-to-839-followers"><span class="articles__feature-img-container"><picture class="articles__feature-img"><source media="(min-width: 1000px)" srcset="https://steemitimages.com/256x512/https://cdn.steemitimages.com/DQmX2CU3KgJW4UEqZ8kFU6DTLTtPeA9eDGFaPX7abNmwkV1/8B466B63-C90A-4837-9306-1EECA91A5E5A.jpeg"><img srcset="https://steemitimages.com/640x480/https://cdn.steemitimages.com/DQmX2CU3KgJW4UEqZ8kFU6DTLTtPeA9eDGFaPX7abNmwkV1/8B466B63-C90A-4837-9306-1EECA91A5E5A.jpeg"></picture></span></a></div><div class="articles__content-block articles__content-block--text"><h2 class="articles__h2 entry-title"><a href="${linkOfPostToOpen}"><!-- react-text: 1394 -->FREE RESTEEM &amp; UPVOTE SERVICE TO 839+ FOLLOWERS<!-- /react-text --></a></h2><div class="PostSummary__body entry-content"><a href="${linkOfPostToOpen}">I am starting a free restreem &amp; upvote service to my 839+ Followers!   RULES     Follow me     Upvote this post     Leave Link in Comments</a></div><div class="articles__summary-footer"><span class="Voting"><span class="Voting__inner"><span class="Voting__button Voting__button-up Voting__button--upvoted"><a title="Remove Vote" id="upvote_button" href="#"><span class="Icon chevron-up-circle upvote" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" enable-background="new 0 0 33 33"><g id="Chevron_Up_Circle"><circle fill="none" stroke="#121313" cx="16" cy="16" r="15" /><path fill="#121313" d="M 16.699 11.293 c -0.384 -0.38 -1.044 -0.381 -1.429 0 l -6.999 6.899 c -0.394 0.391 -0.394 1.024 0 1.414 c 0.395 0.391 1.034 0.391 1.429 0 l 6.285 -6.195 l 6.285 6.196 c 0.394 0.391 1.034 0.391 1.429 0 c 0.394 -0.391 0.394 -1.024 0 -1.414 L 16.699 11.293 Z" /></g></svg></span></a></span><div class="DropdownMenu"><a href="#"><span><span class="FormattedAsset "><span class="prefix">$</span><span class="integer">0</span><span class="decimal">.10</span></span><span class="Icon dropdown-arrow" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" viewBox="0 0 512 512" x="0px" y="0px" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" enable-background="new 0 0 512 512"><g><polygon points="128,90 256,218 384,90" /></g></svg></span></span></a><ul class="VerticalMenu menu vertical VerticalMenu"><li><span><!-- react-text: 1414 -->Pending Payout $0.10<!-- /react-text --></span></li><li><span><!-- react-text: 1417 -->(0.01 SBD, 0.03 STEEM, 0.04 SP)<!-- /react-text --></span></li><li><span><span title="‎7‎/‎16‎/‎2018 ‎3‎:‎29‎ ‎PM"><span>in 4 days</span></span></span></li><li><span><!-- react-text: 1424 -->Promotion Cost $0.01<!-- /react-text --></span></li></ul></div></span></span><span class="VotesAndComments"><span title="32 votes" class="VotesAndComments__votes"><span class="Icon chevron-up-circle Icon_1x" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" enable-background="new 0 0 33 33"><g id="Chevron_Up_Circle"><circle fill="none" stroke="#121313" cx="16" cy="16" r="15" /><path fill="#121313" d="M 16.699 11.293 c -0.384 -0.38 -1.044 -0.381 -1.429 0 l -6.999 6.899 c -0.394 0.391 -0.394 1.024 0 1.414 c 0.395 0.391 1.034 0.391 1.429 0 l 6.285 -6.195 l 6.285 6.196 c 0.394 0.391 1.034 0.391 1.429 0 c 0.394 -0.391 0.394 -1.024 0 -1.414 L 16.699 11.293 Z" /></g></svg></span><!-- react-text: 1428 -->&nbsp;<!-- /react-text --><!-- react-text: 1429 -->32<!-- /react-text --></span><span class="VotesAndComments__comments"><a title="45 responses. Click to respond." href="/resteem/@la2410/free-resteem-and-upvote-service-to-839-followers#comments"><span class="Icon chatboxes" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" viewBox="0 0 512 512" x="0px" y="0px" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><g><path d="M 294.1 365.5 c -2.6 -1.8 -7.2 -4.5 -17.5 -4.5 H 160.5 c -34.7 0 -64.5 -26.1 -64.5 -59.2 V 201 h -1.8 C 67.9 201 48 221.5 48 246.5 v 128.9 c 0 25 21.4 40.6 47.7 40.6 H 112 v 48 l 53.1 -45 c 1.9 -1.4 5.3 -3 13.2 -3 h 89.8 c 23 0 47.4 -11.4 51.9 -32 L 294.1 365.5 Z" /><path d="M 401 48 H 183.7 C 149 48 128 74.8 128 107.8 v 69.7 V 276 c 0 33.1 28 60 62.7 60 h 101.1 c 10.4 0 15 2.3 17.5 4.2 L 384 400 v -64 h 17 c 34.8 0 63 -26.9 63 -59.9 V 107.8 C 464 74.8 435.8 48 401 48 Z" /></g></svg></span><!-- react-text: 1433 -->&nbsp;<!-- /react-text --><!-- react-text: 1434 -->45<!-- /react-text --></a></span></span><span class="PostSummary__time_author_category"><span class="Reblog__button Reblog__button-active"><a title="Resteem" href="#"><span class="Icon reblog" style="width: 1.12rem; height: 1.12rem; display: inline-block;"><svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" style="enable-background:new 0 0 512 512;" viewBox="0 0 512 512" x="0px" y="0px" xmlns:xml="http://www.w3.org/XML/1998
amespace" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1"><path d="M 448 192 l -128 96 v -64 H 128 v 128 h 248 c 4.4 0 8 3.6 8 8 v 48 c 0 4.4 -3.6 8 -8 8 H 72 c -4.4 0 -8 -3.6 -8 -8 V 168 c 0 -4.4 3.6 -8 8 -8 h 248 V 96 L 448 192 Z" /></svg></span></a></span></span></div></div></div></div>`;

  logsOn && console.debug('Injecting in blog page a new article with the link of my post to comment..');
  var postElement = document.createElement('div');
  postElement.innerHTML = myElementToClickToEventuallyComment;
  document.body.appendChild(postElement);
  await(1000);

  logsOn && console.debug('Clicking my post title to open it so I can comment it..');
  var myLink = document.querySelectorAll(`[href='${linkOfPostToOpen}']`)[0];
  myLink.click();
  await(5000);
}

// ============================================================
let intervalValueRul;
async function startResteems(w, allResteemsForPostDone, allResteemsForPostHasFailure) {
  let idx = 0;
  if (users.length) {
    logsOn && console.debug('Launching all resteems..!');
    countResteemedTask_prev = countResteemedTask;
    intervalValueRul = setInterval(() => {
      if (idx < users.length) {
        try {
          execService(users[idx], toResteem[users[idx++]], w);
        } catch (err) {
          allResteemsForPostHasFailure(err);
        }
      } else if (idx === users.length) {
        idx = 8888;
        setTimeout(() => {
          logsOn && console.debug(`${now()} -- END.
            Failed resteems: ${failed.length ? JSON.stringify(failed) : 'none! :D'}.
            Warnings: ${warnings.length ? JSON.stringify(warnings) : 'none.'}
          `);
          if (failed.length) {
            localStorage.setItem(
              `errors-execService_FINALREPORT-${new Date().getTime()}`,
              `
FAILED: ${JSON.stringify(failed)}
Warnings: ${JSON.stringify(warnings)}
              `
            );
            clearInterval(intervalValueRul);
            allResteemsForPostHasFailure(JSON.stringify(failed));
          } else {
            allResteemsForPostDone();
          }
        }, 10000);
      }
    }, 15000);
  }
}

const updateUpvotesAndPayoutCount = (w) => {
  logsOn && console.debug('Reading upvotes and payout from my post..');
  try {
    var voteBlock = w.document.getElementsByClassName('Voting')[1];
    var balance = voteBlock.getElementsByClassName('FormattedAsset')[0].textContent.slice(1);
    var votes = voteBlock.getElementsByClassName('DropdownMenu Voting__voters_list')[0];
    const cleanVotes = votes.firstElementChild.firstElementChild.textContent.split(' ')[0];
    if (postStatsDb.indexOf(w.window.location.href) === -1) {
      postStatsDb.push(w.window.location.href);
      countUpvotes += +cleanVotes;
      if (+balance > 0.01) countPayouts += +balance;
      logsOn && console.debug(`${now()} -- ~~~ Added to db. Post upvotes: ${cleanVotes}, Post balance: ${cleanVotes}`);
    }
  } catch (err) {
    logsOn && console.error(`Something went wrong in updateUpvotesAndPayoutCount. Continuing. Cause was: ${err}`);
  }
}


let failed = [], warnings = [];

async function execService(user, link, w0) {
  const target = w0 ? w0.document : document;
  let w;
  try {
    if (blacklist.indexOf(user) !== -1) {
      logsOn && console.debug(`${now()} -- Not resteeming a link from a banned user!`);
      return;
    }
    const targetLink = link.replace('partiko.app', 'steemit.com');
    w = open(targetLink, '_blank'); // default order !
    await nap(5000);

    // PS. IF !opera FIRST 10 LINKS GET UPVOTE & FOLLOW
    let toUpvoteAndFollow = false;
    const idxFirstTenArr = firstTenToUpvAndFollow.indexOf(user);
    if (idxFirstTenArr !== -1) {
      firstTenToUpvAndFollow.splice(idxFirstTenArr, 1);
      toUpvoteAndFollow = 'first 10 (right) link leavers on FOX/EDGE';
    }

    // Only if comment contained (toLowerCase, indexOf: resteemed or re-steemed) @@@
    const currentComment = target.getElementsByClassName('Post_comments__content')[0]
      .querySelectorAll(`[href='${link}']`)[0];
    const userMsg = (currentComment && currentComment.parentElement
      && currentComment.parentElement.parentElement
      && currentComment.parentElement.parentElement.textContent.toLowerCase()) || '';
    if (userMsg.indexOf('resteemed') !== -1 || userMsg.indexOf('re-steemed') !== -1
        || userMsg.indexOf('reblogged') || userMsg.indexOf('shared you')) {
      toUpvoteAndFollow = 'user resteemed me';
    }

    if (toUpvoteAndFollow) {
      logsOn && console.debug(`${now()} -- Upvoting post for user ${user}. Why: ${toUpvoteAndFollow}`);
      const upvBtnType1 = w.document.getElementById('upvote_button');
      const upvBtnBlock = w.document.querySelectorAll('span[class="Voting__button Voting__button-up"]')[0];
      const upvBtnType2 = upvBtnBlock && upvBtnBlock.firstChild.firstChild;
      const upvoteBtn = upvBtnType1 || upvBtnType2;
      if (!upvoteBtn) {
        logsOn && console.debug('No upvote button found. Skipping.');
        return;
      }
      if (upvoteBtn.title === 'Remove Vote') {
        logsOn && console.debug('Was already upvoted..');
      } else {
        upvoteBtn.click();
        await nap(3000);
        const weightBtn = w.document.querySelectorAll('a[class="confirm_weight"]')[0];
        if (weightBtn && isPostWeightBtn(weightBtn, w)) {
          weightBtn.click();
          await nap(3000);
        } else {
          logsOn && console.error(`Weight button was not the post one! Going on.`);
        }
      }
      toUpvoteAndFollow = false;

      const dropdownArrow = w.document.getElementsByClassName('Icon dropdown-arrow')[0];
      if (!dropdownArrow) {
        logsOn && console.debug('No follow button found');
        return;
      }
      dropdownArrow.click();
      await nap(500);
      logsOn && console.debug(`${now()} -- Clicking on FOLLOW for user ${user}`);
      const followBtn = w.document.getElementsByClassName('button slim hollow secondary ')[0];
      if (followBtn.textContent.toUpperCase() === 'FOLLOW') {
        followBtn.click();
        await nap(5000);
        if (followBtn.textContent.toUpperCase() !== 'UNFOLLOW') {
          const msg = `(maybe) was not able to follow ${user}`;
          warnings.push(msg);
          logsOn && console.debug(msg);
        }
      }
    }

    logsOn && console.debug('Resteeming post for user', user);
    const resteemBtn = w.document.querySelectorAll('[title=Resteem]')[0]
    if (!resteemBtn) {
      logsOn && console.debug('Resteem button not found..');
      return; // no btn if eg. expired
    }
    resteemBtn.click();
    await nap(500);
    logsOn && console.debug('Confirming Resteem..');
    const confirmForm = w.document.getElementsByClassName('ConfirmTransactionForm')[0]
    if (confirmForm) {
      confirmForm.getElementsByTagName('button')[0].click();
      await nap(4000);
    }
    const resteemOk = w.document.getElementsByClassName('Reblog__button Reblog__button-active')[0];
    if (resteemOk && confirmForm) {
      logsOn && console.debug('SUCCESS.');
      if (resteemedLinksToday.indexOf(w.window.location.href) === -1) {
        resteemedLinksToday.push(w.window.location.href);
        countResteemedTask++;
      }
    } else if (resteemOk && !confirmForm) {
      warnings.push(`Already resteemed: ${user}`);
    } else {
      const msg = `FAILED? Grey Resteem for ${user} -> ${link}`;
      logsOn && console.debug(msg);
      if (resteemedLinksToday.indexOf(w.window.location.href) === -1) {
        resteemedLinksToday.push(w.window.location.href);
        countResteemedTask++;
      }
      warnings.push(msg);
    }
  } catch (e) {
      logsOn && console.error('FAILED. Stored in errors array. Error was: ', e);
      failed.push(`${user} -> ${link}`);
  } finally {
    w.close();
  }
}
// processUsersComments(/*takeNap->defaulted to: true*/);

// ###########################################################################
// ###########################################################################

// [VERSION 1]
// ...NEXT IMPROVEMENTS: <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// check upvoted and followed, check post has no nsfw (, lgbt) tag,
// ADD BALANCE IN BITBALLOON MONITOR (getTodaysLink -> getTodaysData: returns 'links::$12.23')
// NO FIXED TIMEOUTS, use smart polling & callbacks
// automatically redeem rewards on wallet page
// dont' resteem users with low repo
// Auto flag on steemit.bot -> document.querySelectorAll('span[title="Flag"]')[0].click();document.querySelectorAll('span[title="Flag"]')[1].click()

// ======================================== SCHEDULER EVENT HANDLER (no F5!)
var my_onkeydown_handler = function (e) {
  // logsOn && console.debug(e.which || e.keyCode)
  if ((e.which || e.keyCode) == 116) {
    e.preventDefault();
    e.keyCode = 0;
    window.status = "F5 disabled";
    alert("Can't refresh this page. You'll have to kill it!! :D");
    return;
  }
}
document.addEventListener("keydown", my_onkeydown_handler);

// code above won't work if first button press is F5. Fallback:
window.onbeforeunload = function() {
  return "Dude, are you sure you want to leave? Think of the kittens!";
}



// ======================================================= SCHEDULER

// short name because I have to type it every time in console
// (btns dont work injected in Steemit). USe 'exec (' to search.
async function exec (which, takeNap = true) { // always called with true by scheduler
  if (!which) throw new Error('You gotta provide a valid argument to exec! (1,2,3,4,100,?)');
  if (which === 100) {
    if (!takeNap || takeNap.toLowerCase() === 'all') { // = mode ((ehm..))
      runs = [];
    } else if (takeNap.toLowerCase() === 'last') {
      runs.pop();
    } else {
      throw new Error(`Expected "all" or "last" but found: ${takeNap}`);
    }
    await buildUI(100);
    return;
  }

  showErrorsAndMaybeRemove(true);
  removeTasksFromLocalStorage(true); // fromCode

  let taskName = titlesShort[which];
  const isManual = !tasks[new Date().getHours()]
    || tasks[new Date().getHours()].name.indexOf(taskName) === -1;
  if (isManual) taskName += '_manualLaunch';
  const msg = `Starting Task: @@ ${taskName} @@`;
  logsOn && console.debug(msg);
  if (!takeNap && !confirm(msg)) throw new Error('User error. Task terminated.');
  logsOn && console.debug(`${now()} -- -------- TASK START -------`);
  localStorage.setItem(`${getTodaysDOW()}-task-${taskName.replace(' ','~')}`, new Date().getTime());

  try {
    switch (which) {
      case 1:
        await updateUIAndChangeBtnColorTo(0, which);
        await resteemTheWorld(takeNap);
        break;
      case 2:
        await updateUIAndChangeBtnColorTo(0, which);
        await createMoneyPost(takeNap);
        break;
      case 3:
        await updateUIAndChangeBtnColorTo(0, which);
        await getFamousUsingOthers(takeNap);
        break;
      case 4:
        await updateUIAndChangeBtnColorTo(0, which);
        await selfPromoteForAcent(takeNap);
        break;
      default:
        throw new Error(`Unsupported command exec(${which})`);
    }
  } catch (err) {
    logsOn && console.error(`Error in exec(${which}). Cause: ${err}`);
    await updateUIAndChangeBtnColorTo(2, which);
    throw new Error(`exec(n) -> ${err}`);
  }
}
document.execute = (n) => { exec(n); }

// NOTE: ship.. manualBot goes on more than 24hs, but no more links generally..
let prevCountManualBot = 0;
const addDailyScriptBotResult = (countHere) => {
  const countManualBot = +localStorage.getItem('dailyScriptBot_result');
  logsOn && console.debug(`${now()} -- Calculating amount of resteems. Local: ${countHere}, manualbot: ${countManualBot}`);
  if (!countManualBot) return countHere;

  let diffCountManualBot;
  if (countManualBot >= prevCountManualBot) {
    diffCountManualBot = countManualBot - prevCountManualBot;
  } else {
    // in case the manual script was restarted..
    diffCountManualBot = countManualBot;
  }
  prevCountManualBot = countManualBot;
  logsOn && console.debug(`${now()} -- Total resteems is: ${countHere + diffCountManualBot}`);
  return countHere + diffCountManualBot;
}

const updateCount = (execId) => {
  logsOn && console.debug('Updating stats..');
  let id, value;
  // `<div
  //   TODAY (so far) =>
  //   Resteemed: <span id="resteemedN">n/a</span>,
  //   Resteemers used: <span id="resteeemrsN">n/a</span>,
  //   Posts created: <span id="postsN">n/a</span> (week: <span id="totpostsN">n/a</span>)<br>
  //   7 days range =>
  //   Tot upvotes: <span id="upvotesN">n/a</span>,
  //   Tot payout: <span id="payoutsN">n/a</span> (no dust) = <span id="avg">n/a</span> $ avg
  // </div>`
  switch (execId) {
    case 1: case 'openAllPosts':
      document.getElementById('upvotesN').innerHTML = `<b>${countUpvotes}</b>`;
      document.getElementById('payoutsN').innerHTML = `<b>~${
        countPayouts.toFixed(2) || 'n/a'
      } $</b>`;
      document.getElementById('totpostsN').innerHTML = `<b>${countPostsWeek}</b>`;
      document.getElementById('avg').innerHTML = `<b>${
        (countPayouts / countPostsWeek).toFixed(3) || 'n/a'
      }</b>`;
      countResteemedTask = addDailyScriptBotResult(countResteemedTask);
      id = 'resteemedN';
      value = countResteemedTask;
      // reset:
      countPostsWeek = 0;
      postStatsDb = [];
      countUpvotes = 0;
      countPayouts = 0;
      break;
    case 2:
      id = 'postsN';
      value = countPostsCreatedToday;
      break;
    case 3:
      id = 'resteeemrsN';
      value = countSpammedResteemers;
      break;
    default:
      throw new Error(`updateCount for id ${execId} does not exist!`);
  }
  document.getElementById(id).innerHTML = `<b>${value}</b>`;
}

// NOT IN USE
const saveBeforeRefresh = () => {
  const stastPanel = document.getElementById('statsPanel').innerHTML;
  const btn1 = document.getElementById('exec1').innerHTML;
  const btn2 = document.getElementById('exec2').innerHTML;
  const btn3 = document.getElementById('exec3').innerHTML;
  const btn4 = document.getElementById('exec4').innerHTML;
  const btn1input = document.getElementById('exec3input').value;
  const btn2input = document.getElementById('exec4input').value;
  return { stastPanel, btn1, btn2, btn3, btn4, btn1input, btn2input };
}
const restoreAfterRefresh = ({ stastPanel, btn1, btn2, btn3, btn4, btn1input, btn2input }) => {
  document.getElementById('statsPanel').innerHTML = stastPanel;
  document.getElementById('exec1').innerHTML = btn1;
  document.getElementById('exec2').innerHTML = btn2;
  document.getElementById('exec3').innerHTML = btn3;
  document.getElementById('exec4').innerHTML = btn4;
  document.getElementById('exec3input').value = btn1input;
  document.getElementById('exec4input').value = btn2input;
}

async function updateUIAndChangeBtnColorTo (status, which) {
  switch (status) {
    case -1:
      [1,2,3,4].forEach(id => {
        document.getElementById(`exec${id}`).style['color'] = '#0d284d';
        document.getElementById(`exec${id}`).style['background-color'] = 'transparent';
        // no reset of input fields
      });
      break;
    case 0: // = running
      document.getElementById(`exec${which}`).style['color'] = 'white';
      document.getElementById(`exec${which}`).style['background-color'] = 'blue';
      break;
    case 1: // = ok
      await buildUI(which);
      document.getElementById(`exec${which}`).style['color'] = 'white';
      document.getElementById(`exec${which}`).style['background-color'] = 'green';
      if (which === 3) document.getElementById(`exec${which}input`).value = '';
      if (which === 4) document.getElementById(`exec${which}input`).value = '';
      break;
    case 2: // = error
      await buildUI(which);
      document.getElementById(`exec${which}`).style['color'] = 'white';
      document.getElementById(`exec${which}`).style['background-color'] = 'red';
      break;
    default:
      throw new Error(`Status ${status} not found to change buttons color`);
  }
}

// ~~~~~~~~~~~~ exec(3) ~~~~~~
async function getFamousUsingOthers (takeNap = true) {
  const exec3input = document.getElementById('exec3input').value.trim();
  try {
    if (!exec3input) {
      const msg = 'You gotta paste the argument in the input field first. Use the UI --> http://my-steemit-bots.bitballoon.com/';
      // alert(msg);
      throw new Error(msg);
    }
    logsOn && console.debug('Parsing the input..')
    const data = JSON.parse(exec3input);
    if (!Array.isArray(data)) {
      const msg = 'The data you pasted in the input field is not an array!';
      alert(msg);
      throw new Error(msg);
    }
    if (!hasExternalLink(data)) {
      const msg = data.length ? `At least one of the links has to be not mine! input: ${
        JSON.stringify(data)}` : 'Empty array!';
      alert(msg);
      throw new Error(msg);
    }
    const howManyLinks = data.length;
    if (howManyLinks === 0) throw new Error('No links found in input array!');
    if (takeNap) {
      // [-- DELAYS (to avoid resources congestion) --]
      if (usag === 'opr') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for ${30*howManyLinks} secs = ${30*howManyLinks/60} mins ======= ]]=`);
        await nap(30000 * howManyLinks);
      } else if (usag === 'edge') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for ${30*howManyLinks*2} secs = ${30*howManyLinks*2/60} mins ======= ]]=`);
        await nap(30000 * howManyLinks * 2);
      }
    }
    logsOn && console.debug('Executing getFamousUsingOthers TASK..');
    await spamResteemersWithMyLinks(data, false); // took nap already
    logsOn && console.debug('---------- TASK COMPLETED -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Spam~Resteemers`);
    localStorage.setItem(`${getTodaysDOW()}-task-Spam~Resteemers`,`${startTime}->${new Date().getTime()}`);
    await updateUIAndChangeBtnColorTo(1, 3);
    updateCount(3);
  } catch (err) {
    logsOn && console.debug('---------- TASK END (with errors) -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Spam~Resteemers`);
    localStorage.setItem(`${getTodaysDOW()}-task-Spam~Resteemers`,`${startTime}->${new Date().getTime()}`);
    await updateUIAndChangeBtnColorTo(2, 3);
    updateCount(3);
    throw new Error(`getFamousUsingOthers -> ${err}`);
  }
}

// ~~~~~~~~~~~~ exec(4) ~~~~~~
async function selfPromoteForAcent (takeNap = true) {
  const exec4input = document.getElementById('exec4input').value.trim();
  try {
    if (!exec4input) {
      const msg = 'You gotta paste the argument in the input field first. Use the UI --> http://my-steemit-bots.bitballoon.com/';
      alert(msg);
      throw new Error(msg);
    }
    if (takeNap) {
      // [-- DELAYS (to avoid resources congestion) --]
      if (usag === 'opr') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 90 secs = 1.5 mins ======= ]]=`);
        await nap(60000);
      } else if (usag === 'edge') {
        logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 180 secs = 3 mins ======= ]]=`);
        await nap(120000);
      }
    }
    logsOn && console.debug('Executing selfPromoteForAcent TASK..');
    const data = JSON.parse(exec4input);
    if (typeof data !== 'object' || Array.isArray(data) || Object.keys(data).length === 0) {
      const msg = 'The data you provided as argument is not a valid object';
      alert(msg);
      throw new Error(msg);
    }
    await execTodaysSelfSupport(data, false); // took nap already
    logsOn && console.debug('---------- TASK COMPLETED -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Self~Promotion`);
    localStorage.setItem(`${getTodaysDOW()}-task-Self~Promotion`,`${startTime}->${new Date().getTime()}`);
    await updateUIAndChangeBtnColorTo(1, 4);
  } catch (err) {
    logsOn && console.debug('---------- TASK END (with errors) -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Self~Promotion`);
    localStorage.setItem(`${getTodaysDOW()}-task-Self~Promotion`,`${startTime}->${new Date().getTime()}`);
    await updateUIAndChangeBtnColorTo(2, 4);
    throw new Error(`selfPromoteForAcent -> ${err}`);
  }
}


// ~~~~~~~~~~~~ exec(2) ~~~~~~
async function createMoneyPost (takeNap = true) {
  if (usag === 'chrome') {
    const msg = 'What the hell r u doing? You\'re on your (only semi-bot) main account!';
    alert(msg);
    throw msg;
  }
  if (takeNap) {
    // [-- DELAYS (to avoid resources congestion) --]
    if (usag === 'opr') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for ~1800 secs = 35 mins ======= ]]=`);
      await nap(35 * 60 * 1000);
    } else if (usag === 'edge') {
      // logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 7200 secs = 120 min ======= ]]=`);
      // await nap(2 * 60 * 60 * 1000); // 8:00 + 2hs wait = 10AM
    }
  }
  logsOn && console.debug('Executing createMoneyPost TASK..');
  let w;
  logsOn && console.debug('Opening post submit page..');
  w = open('https://steemit.com/submit.html','_blank');//,'toolbar=no,status=no,menubar=no,left=1000000,top=10000000','');
  w.addEventListener('load', () => {
    processPostCreation(false, w, (err) => { // takeNap false bc already used right above here
      logsOn && console.debug(`${now()} -- .>>> ${err}`);
      logsOn && console.debug('------ END OF TASK (FAILED) ------');
      const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Post~Creation`);
      localStorage.setItem(`${getTodaysDOW()}-task-Post~Creation`,`${startTime}->${new Date().getTime()}`);
      updateUIAndChangeBtnColorTo(2, 2);
      updateCount(2);
      throw new Error(`createMoneyPost -> ${err}`);
    });
  });
}

// ~~~~~~~~~~~~ exec(1) ~~~~~~
async function resteemTheWorld (takeNap = true) {
  if (takeNap) {
    // [-- DELAYS (to avoid resources congestion) --]
    if (usag === 'opr') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 3600 secs = 60 mins ======= ]]=`);
      await nap(360000);
    } else if (usag === 'edge') {
      logsOn && console.debug(`${now()} -- [[ ========= ${usag} --> napping for 7200 secs = 120 min ======= ]]=`);
      await nap(900000);
    }
  }
  logsOn && console.debug('Executing resteemTheWorld TASK..');
  try {
    const allPostsArray = [];
    [0,6,5,4,3,2,1].forEach((idx) => {
      const linksForDay = getTodaysLinkCodeOnly(idx);
      if (linksForDay.indexOf('NOT FOUND') === -1) allPostsArray.push(linksForDay);
    });
    if (!allPostsArray.length) {
      logsOn && console.debug('NO LINKS FOUND IN LOCAL STORAGE!! Resteem process interrupted.');
      return;
    }
    await recurseOverPosts(allPostsArray);

    await updateRepoBalanceAndFollowers();

  } catch (err) {
    logsOn && console.error(`>>> ${err}`);
    logsOn && console.debug('------ END OF TASK (FAILED) ------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Resteem~users`);
    localStorage.setItem(`${getTodaysDOW()}-task-Resteem~users`,`${startTime}->${new Date().getTime()}`);
    await updateUIAndChangeBtnColorTo(2, 1);
    updateCount(2);
    throw new Error(`resteemTheWorld -> ${err}`);
  }
}

let repo, balance;
async function updateRepoBalanceAndFollowers () {
  return; // NOW RETURNING BECAUSE THE WALLET GOT SEPARATED INTO A DIFFERENT PAGE
  logsOn && console.debug(`${now()} -- Opening wallet page to check the current balance and claim rewards..`);
  const w = open(`https://steemit.com/@${accounts[usag]}/transfers`);
  w.addEventListener('load', () => {
    executeExtraction(w);
  });
}
async function executeExtraction (w) {
  try {
    logsOn && console.debug('Checking if there is any reward to claim..');
    await nap(2000);
    const claimRewBtnBlock = w.document.getElementsByClassName('UserWallet')[0]
    const claimRewBtn = claimRewBtnBlock.firstChild.getElementsByTagName('button')[0]
    const btnText = claimRewBtn.textContent.toUpperCase();
    if (btnText.toUpperCase().indexOf('BUY') === -1 && btnText.toUpperCase().indexOf('REDEEM') !== -1) {
      logsOn && console.debug('Claiming reward..');
      claimRewBtn.click();
      await nap(3000);
    }
    logsOn && console.debug('Extracting repo and balance..');
    let repo = 'err-repo';
    let balance = 'err-balance';
    let followers = 'err-followers';
    try {
      repo = w.document.getElementsByClassName('UserProfile__rep')[0].textContent;
      const blocks = w.document.getElementsByClassName('UserWallet__balance row');
      const block = blocks[blocks.length - 2];
      balance = block.getElementsByClassName('column small-12 medium-4')[0].textContent;
      const userStats = document.getElementsByClassName('UserProfile__stats')[0]
      followers = userStats.firstElementChild.textContent.split(' ')[0];
    } catch (err) {
      logsOn && console.error(`>>>>>> ERROR: ${err}`);
    }
    document.getElementById('repo').innerHTML = repo;
    document.getElementById('balance').innerHTML = `~${balance}`;
    document.getElementById('followers').innerHTML = `[${followers}]`;
    logsOn && console.debug('Done.');
  } finally {
    w.close && w.close();
  }
}

const recurseOverPosts = (allPostsArray) => { // ['link1,link2','linkA,linkB','link'] // max-links: 21 !!
  const firstLinkGroup = allPostsArray && allPostsArray[0];
  if (firstLinkGroup === undefined) {
    logsOn && console.debug('-------- TASK COMPLETED -------');
    const startTime = localStorage.getItem(`${getTodaysDOW()}-task-Resteem~users`);
    localStorage.setItem(`${getTodaysDOW()}-task-Resteem~users`,`${startTime}->${new Date().getTime()}`);
    updateUIAndChangeBtnColorTo(1, 1);
    updateCount(1);
    return; // exit case
  }
  const firstLinkGroupArr = firstLinkGroup.split(',');
  const link = firstLinkGroupArr[0];
  if (firstLinkGroupArr[1]) {
    firstLinkGroupArr.shift();
    allPostsArray[0] = firstLinkGroupArr.join(',');
  } else {
    allPostsArray.shift()
  }
  logsOn && console.debug(`${now()} -- Opening link ${link} to process comments..`);
  countPostsWeek++;
  // logsOn && console.debug(`${now()} -- < Remaining links: ${JSON.stringify(allPostsArray)} >`);
  const w = open(link,'_blank'); // `${link}?sort=new#comments`
  w.addEventListener('load', () => {
    logsOn && console.debug(`${now()} -- Page ${link} loaded. Executing processUsersComments..`)
    updateUpvotesAndPayoutCount(w);
    processUsersComments(false, w,
      (_OK) => {
        logsOn && console.debug(`${now()} -- ==> All comments on post ${link} processed.`);
        w.close();
        recurseOverPosts(allPostsArray);
      },
      (err) => {
        logsOn && console.debug(`${now()} -- ==> There was a problem processing comments on post ${link}. Errors: ${err}`);
        w.close();
        recurseOverPosts(allPostsArray);
      }
    );
  });

  // avoid to stuck the whole process in case of 504 gateway error or network glitch
  setTimeout(() => {
    logsOn && console.debug(`${now()} -- Checking if my post ${link} has been correctly opened (checking steemit logo)..`);
    if (!w || !w.document.getElementsByClassName('row Header__nav')[0]) {
      logsOn && console.debug('Not able to load steemit logo after 6 seconds. Killing page and going on..');
      if (w.close) w.close();
      localStorage.setItem(`errors-recurseOverPosts-${formatDate(new Date().getTime())}`, `Unable to load my post ${link}. No steemit logo.`);
      recurseOverPosts(allPostsArray);
    } else { logsOn && console.debug('Stemit logo found.') }
  }, 6000);
  // close it if left open..
  // Forced Killed after 5 mins COMMENTS RESTEEMS <<<<<<<<<< @
  setTimeout(() => { if (w.close) w.close() }, 300000);
}


// SEE AT TOP PAGE
// let tasks = {
//   // hours, id, name, calledInSameHour
//   '2': { id: 1, name: 'Resteem users_h2', calledToday: false }, // + delays
//   '4': { id: 1, name: 'Resteem users_h4', calledToday: false }, // + delays
//   '9': { id: 1, name: 'Resteem users_h9', calledToday: false }, // + delays
//   '10': { id: 1, name: 'Resteem users_h10', calledToday: false }, // + delays
//   '13': { id: 1, name: 'Resteem users_h13', calledToday: false }, // + delays
//   '19': { id: 1, name: 'Resteem users_h19', calledToday: false }, // + delays
//   '21': { id: 1, name: 'Resteem users_h21', calledToday: false }, // + delays
//   '23': { id: 1, name: 'Resteem users_h23', calledToday: false }, // + delays
//   '100': { id: 3, name: 'Spam Resteemers', calledToday: false }, // + delays
//   '101': { id: 4, name: 'Self Promotion' }, // + delays
// };
// tasks[`${usag === 'edge' ? '8':'1'}`] = { id: 2, name: 'Post Creation', calledToday: false }; // + delays

let resetAlready = false;
let edgeSpamResteemers = 11;

notChrome && setInterval(() => {
  const taskTimes = Object.keys(tasks);
  const nowHours = `${new Date().getHours()}`;
  logsOn && console.debug(`${now()} -- ~~~~~~~~~~~ Hour: ${nowHours}. Checking tasks..`);
  if (nowHours === '0' && !resetAlready) {
    resetAlready = true;
    midnightReset();
  } else if (nowHours === '1') {
    resetAlready = false;
  } else if (usag == 'edge' && nowHours == edgeSpamResteemers && !tasks['100'].calledToday) {
    // STUPID EDGE --------------- HARDCODED TIME for Spam Resteemers <<<<<<<<<<<<<<<<<
    // STUPID EDGE --------------- HARDCODED TIME for Spam Resteemers <<<<<<<<<<<<<<<<<
    tasks['100'].calledToday = true;
    exec(3, true);
  }
  const indexOfCurrTime = taskTimes.indexOf(nowHours)
  if (indexOfCurrTime !== -1 && !tasks[nowHours].calledToday) {
    const currTask = tasks[nowHours];
    currTask.calledToday = true;
    logsOn && console.debug(`${now()} -- Executing task ${currTask.name} calling exec(${currTask.id})..`);
    exec(currTask.id, true); // takeNap
  }
}, 600000); // every 20 mins

const midnightReset = () => {
  logsOn && console.debug(`${now()} -- It's a new day! Resetting calledToday bools and global vars..`);
  const taskTimes = Object.keys(tasks);
  taskTimes.forEach((time) => { tasks[time].calledToday = false; });
  countResteemedTask = 0;
  countResteemedTask_prev = 0;
  resteemedLinksToday = [];
  countPostsWeek = 0;
  countSpammedResteemers = 0;
  countSpammedResteemers_prev = 0;
  usedResteemersDb = [];
  countPostsCreatedToday = 0;
  countUpvotes = 0;
  countPayouts = 0;
  postStatsDb = [];
  updateUIAndChangeBtnColorTo(-1);
  document.getElementById('statsPanel').innerHTML = statsPanelData;
  updateRepoBalanceAndFollowers();

  RESET_ERRORS_AT_MIDNIGHT && exec(100, 'all');
}



// ================= UI generator
// PAGE: https://steemit.com/@[USER-HERE]/transfers
// STATUS PANE INJECTED IN HTML ON TOP OF PAGE

const taskReport = ({
  formattedRunTime, taskTitle, failed, errList = [], formattedDuration,
  additionalStatsName, additionalStatsValue
}) => {
  if (!taskTitle) throw new Error('no "taskTitle" found in template creation!');
  if (!formattedRunTime) throw new Error('no "formattedRunTime" found in template creation!');
  if (failed === undefined) throw new Error('no "failed" found in template creation!');
  if (failed && !errList) throw new Error('no "errList" found in template creation!');
  if (!formattedDuration) throw new Error('no "formattedDuration" found in template creation!');
  if (additionalStatsName && !additionalStatsValue) throw new Error(`no "additionalStatsValue" found in template creation for "${additionalStatsName}"!`);
  // formattedRunTime:
  //   'Sun Jul 15 2018 18:49:01'
  // taskTitle:
  //   'Resteem users', Get Resteemed, Post Creation, Self Promotion
  // failed:
  //   t o f
  // errList:
  //   'X is undefined', 'doc not found', 'big stuff....', ..
  // formattedDuration:
  //   '1mins 24sec'
  // additionalStatsName:
  //   '# links resteemed'
  //   VS '# resteemers used'
  // additionalStatsValue:
  //   123
return `
  <div class="taskRes">
    <span style="color:blue">< Run at: ${formattedRunTime} ></span>
      <ul><li>
        <div>TASK: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue">${taskTitle}</span></div>
        ${ failed ?
            `<div>STATUS:
              <div style="color:red">
                <h4>&nbsp;&nbsp;ERROR</h4>
                <div style="font-size:12px">
                  Details:
                  <ul>
                    ${ errList.map(err => `<li>${err}</li>`).join('\n') }
                  </ul>
                 </div>
              </div></div>`
            :
            `<div>STATUS: <span style="color:green">
              &nbsp;&nbsp;Success
              ${ errList.length ?
                `<div style="font-size:12px;color:#e8771a">
                  Warning:
                  <ul>
                    ${errList.map(err => `<li>${err}</li>`).join('\n')}
                  </ul>
                 </div>`
                 : ''
              }
            </div>`
        }
        <div>
        STATS:
        <div style="margin-left:60px">
          <p style="margin:-10px auto 0">Duration: ${formattedDuration}</p>
          ${ additionalStatsName ?
             `<p style="margin:0 auto 0">${additionalStatsName}: ${additionalStatsValue}</p>` : '' }
        </div>
        </div>
      </li></ul>
    </div>
  `;
}

const getTimeDifference = (start, end) => {
  logsOn && console.debug(`${now()} -- Calculating time difference between start ${start} and end ${end}..`);
  const diffMillis = +end - +start;
  var minutes = Math.floor(diffMillis / 60000);
  var seconds = ((diffMillis % 60000) / 1000).toFixed(0);
  const result = `${minutes} mins ${seconds < 10 ? '0' : ''}${seconds} sec ${
    (usag === 'opr' || usag === 'edge') ? '&nbsp; - nap?' : ''
  }`;
  logsOn && console.debug(`${now()} -- Calculated: ${result}`);
  return result;
};

const extractTitle = (key, whichTaskCompleted, from = 'log') => {
  const splitted = key.split('-');
  const foundTitle = `<b>${splitted[2]}</b>`
    .replace('~',' ').replace('_manualLaunch',' (manual launch)')
    .replace('_', ' '); // eg. "_h19"
  if (foundTitle.indexOf(titlesShort[whichTaskCompleted]) !== -1) {
    logsOn && console.debug(`${now()} -- +++ extracted task title ${foundTitle} from ${from}`);
    return foundTitle;
  } else {
    logsOn && console.error(`Found leftover task log in localstorage.
      ${ whichTaskCompleted ?
         `Was expecting title containing "${titlesShort[whichTaskCompleted]}" but found: ${
           foundTitle
         }`:''
      }
      Key: ${key}, value: ${localStorage.getItem(key)}`);
  }
}

async function getResultsLs (whichTaskCompleted) {
  logsOn && console.debug(`${now()} -- Extracing task info from localstorage..`);
  let allErrorsStr;
  try {
    // Extract from: localStorage.setItem(`errors-functionName-${formatDate(new Date().getTime())}`, err);
    let failed = false;
    let errList = [];
    allErrorsStr = readErrors(); // --> leave remove to exec only, same for tasks
    if (!!allErrorsStr) {
      errList = allErrorsStr.split('- ').map((e) => e.trim()).filter(e => !!e);
      failed = true;
      logsOn && console.debug(`${now()} -- Found errors in localStorage. Found task status set to failed.`);
    }

    let taskTitle;
    let formattedRunTime;
    let formattedDuration;
    let additionalStatsName;
    let additionalStatsValue;

    let taskStartTime, taskEndTime;
    let taskStartTime_fallback;
    const today = getTodaysDOW();
    logsOn && console.debug('Extracting data from LS..');

    // Extract from:
    // localStorage.setItem(`${getTodaysDOW()}-task-${taskObj.name.replace(' ','~')}`, new Date().getTime());
    // localStorage.setItem(`${getTodaysDOW()}-task-Post~Creation`,`${startTime}->${new Date().getTime()}`);
    Object.keys(localStorage).forEach((key) => {
      if (key.indexOf(`${today}-task-`) !== -1) {
        logsOn && console.debug(`${now()} -- Checking key ${key}`);
        if (localStorage.getItem(key).indexOf('->') === -1) {         // Task START marker
          taskStartTime = localStorage.getItem(key);
          logsOn && console.debug(`${now()} -- +++ extracted start time ${taskStartTime}`);
          formattedRunTime = formatDate(+taskStartTime);
          taskTitle = extractTitle(key, whichTaskCompleted, 'start log');
        } else {                                                    // Task END marker
          const splitted = localStorage.getItem(key).split('->');
          taskEndTime = splitted[1];
          logsOn && console.debug(`${now()} -- +++ extracted end time ${taskEndTime}`);
          // Extract all info from end log only
          taskStartTime_fallback = localStorage.getItem(key).split('->')[0];
          logsOn && console.debug(`${now()} -- +++ extracted start time (fallback) ${taskStartTime}`);
          formattedRunTime = formatDate(+taskStartTime_fallback);
          if (formattedRunTime.indexOf('invalid') !== -1) formattedRunTime += ` -> End time: ${formatDate(+taskEndTime)}`
          if (!taskTitle) taskTitle = extractTitle(key, whichTaskCompleted, 'end log');
        }
      }
    });

    if (taskTitle) {
      if (taskEndTime) {
        formattedDuration = getTimeDifference(taskStartTime, taskEndTime);
      } else {
        formattedDuration = `No end time found.<br>Time of extraction: ${formatDate(new Date().getTime())}`;
        errList = ['End time not found, something went wrong in the executed Task.', ...errList];
      }
      if (!taskStartTime) {
        taskStartTime = taskStartTime_fallback;
        formattedDuration = getTimeDifference(taskStartTime, taskEndTime);
        errList = ['Start log not found. Used timestamp found in End log.', ...errList];
      }

      if (taskTitle.toLowerCase().indexOf('resteem users') !== -1) {
        additionalStatsName = '# links resteemed';
        additionalStatsValue = `${countResteemedTask - countResteemedTask_prev}`;
      } else if (taskTitle.toLowerCase().indexOf('spam resteemers') !== -1) {
        additionalStatsName = '# resteemers used';
        additionalStatsValue = `${countSpammedResteemers - countSpammedResteemers_prev}`;
      }
    } else if (errList.length) {
      logsOn && console.error(`Title not found but found errors in LS! Errors:\n${JSON.stringify(errList)}`);
    }

    return !taskTitle ? null : {
      taskTitle, failed, formattedRunTime, taskTitle, formattedDuration,
      additionalStatsName, additionalStatsValue, errList,
    }
  } catch (err) {
    logsOn && console.error(`Error in getResultsLs. Cause: ${err}. ERRORS EXTRACTED FROM TASK RESULT AND DELETED: ${allErrorsStr}`);
    throw err;
  }
}

const readErrors = () => {
  logsOn && console.debug(`${now()} -- Checking localStorage for errors ${runs.length ? 'after task execution..':''}`);
  const allErrorsStr = showErrorsAndMaybeRemove(true, false); // fromCode, deleteToo
  return allErrorsStr;
}

let runs = [];
async function extractResults (whichTaskCompleted) {
  try {
    const taskProperties = await getResultsLs(whichTaskCompleted);
    if (!taskProperties && !runs.length) return '<br><span style="color:grey">No tasks run yet.</span>' // bots manager page just loaded
    if (taskProperties) {
      const report = taskReport(taskProperties || {});
      // MAX SIZE 150 (runs[i%150]) -> 11 tasks per day (+ ~3 manuals?) x 10gg = ~140 tasks..
      if (runs.length === 150) runs = runs.slice(1); // discard first item = oldest
      runs.push(report);
    } else {
      whichTaskCompleted !== 100 && runs.length &&
        logsOn && console.error(`ui refreshed but no new tasks found in LS.. <=============== (weird..)`);
    }
    // most recent on top
    return runs.slice().reverse().join(''); // poor perfomance re-doing this all the time but whatev, not too big..
  } catch (err) {
    logsOn && console.error(`Error in extractResults rendering the tasks reports. Cause: `, err);
    return `<h3 style="color:red">ERROR. UNABLE TO RENDER.</h3>Raw data:<br>${
      runs.join('<br>') || 'No task results found. "runs" array is empty.'
    }`;
  }
}

const statsPanelData = `
  TODAY (so far) => Resteemed: <span id="resteemedN">n/a</span>,
  Resteemers used: <span id="resteeemrsN">n/a</span>,
  Posts created: <span id="postsN">n/a</span> (in 5 days: <span id="totpostsN">n/a</span>)<br>
  5 days range =>
  Tot upvotes: <span id="upvotesN">n/a</span>,
  Tot payout: <span id="payoutsN">n/a</span> (no dust) =
  <span id="avg">n/a</span> $ avg
`;

async function buildUI (whichTaskCompleted) { // called: on first load, after every task (twice if async issues..)
  logsOn && console.debug(`${now()} -- ${runs.length ? 'Refreshing':'Building'} UI ..`);
  let divToAdd;
  let prevState;
  const x = document.getElementsByTagName('body')[0];
  const injectedDiv = document.getElementById('my-injected-ui');
  if (!injectedDiv) {
    divToAdd = document.createElement('div');
    divToAdd.id = 'my-injected-ui';
    divToAdd.style['background-color'] = '#d1e7f8';
  } else {
    // prevState = saveBeforeRefresh();
    logsOn && console.debug('State of UI components saved before refresh');
  }
  let runsReport = await extractResults(whichTaskCompleted);
  let botName = accounts[usag];
  // divToAdd.innerHTML = ` <!-- @@@@@@ TEMP <<<<<<< // >>>>> use this to edit. Syntax highligthing.
  const content = ` <i style="display:none">--></i>
    <p>Browser: <span style="color:#8A2BE2">${usag.charAt(0).toUpperCase() + usag.slice(1)}<span><p>
    <h4 style="margin:-20px auto 20px">
      Bot: <b style="color:#8A2BE2">${botName}
      <span style="color:green;font-size:20px;">
      <span id="repo"></span>
      <span id="followers"></span>
      <span id="balance"></span><span></b>
    </h4>
    <div id="statsPanel"
      style="display:${usag==='chrome'?'none':'inherit'};float:right;width:620px;margin-top:-70px;background-color:#c1eabc;padding:5px;color:#216e1f">
      ${statsPanelData}
    </div>
    <div style="width:420px;padding:10px;float:right;margin-top:-20px">
      <button id="exec1" ${usag==='chrome'?'disabled':''} class="UserWallet__buysp button hollow" style="cursor:default">
        [exec(1)] (sure??) PROCESS **ALL** COMMENTS (week) -- H 2, 3, 9, 10, 13, 19, 21, 23
      </button>
      <button id="exec2" ${usag==='chrome'?'disabled':''} class="UserWallet__buysp button hollow" style="cursor:default">
        [exec(2)] (sure??) CREATE TODAYS POST -- h1:00 (8 edge)
      </button>
      <button id="exec3" class="UserWallet__buysp button hollow" style="cursor:default">
        [exec(3)] { SPAM RESTEEMERS } (needs UI paste)
      </button>
      <input id="exec3input" type="text" placeholder="Paste full command to spam resteemers"></input><br>
      <button id="exec4" class="UserWallet__buysp button hollow" style="cursor:default">
        ${usag==='chrome'?'<b>':''}[exec(4)] { SELF PROMOTION } (needs UI paste)${usag==='chrome'?'</b>':''}
      </button>
      <input id="exec4input" type="text" placeholder="Paste full command for auto promotion"></input>
    </div>
    <div id="reports" style="background-color:#1111;padding:5px;width:50%;overflow:auto;height:600px;">
      ${runsReport}
    </div>
    <button id="exec100" class="UserWallet__buysp button hollow" style="cursor:default;color:white;background-color:orange;width:380px">
      [exec(100)] Clear Task Logs ('last' or 'all')
    </button>
  `;
  const topDiv = document.getElementById('content');
  if (divToAdd) {
    divToAdd.style.border = 'thin solid grey';
    divToAdd.style.padding = '5px';
    divToAdd.innerHTML = content;
    document.body.insertBefore(divToAdd, document.body.firstChild);
    document.getElementsByTagName('header')[0].style.position = 'relative';
  } else {
    // injectedDiv.innerHTML = content;
    // restoreAfterRefresh(prevState);
    document.getElementById('reports').innerHTML = `${runsReport}`;
    logsOn && console.debug('State of UI components restored after refresh');
  }
  if (!whichTaskCompleted || whichTaskCompleted === 1) {
    setTimeout(() => updateRepoBalanceAndFollowers(), 1);
  }
}
buildUI();

// SCHEDULER specific UTILITIES ====================

const promotePost = (link) => localStorage.setItem('postToPromote', link);
const removePromotedLink = () => localStorage.removeItem('postToPromote');

const removeAllPosts = () => {
  if (confirm(`Are you sure you want to delete all ${accounts[usag]}'s posts from the localStorage ??!? @.@ `)) {
    if (confirm('Fucking sure sure ?? O.o')) {
      const found = [];
      Object.keys(localStorage).forEach((lsKey) => {
        'sunday,monday,tuesday,wednesday,thursday,friday,saturday'.split(',')
          .forEach((dow) => {
            if (lsKey.indexOf(dow) !== -1) {
              found.push(`${lsKey} -> ${localStorage[lsKey]}`);
              localStorage.removeItem(lsKey);
            }
          });
      });
      alert(`Found and removed:\n${found.length ? JSON.stringify(found):'\nnone'}`)
    }
  }
}

let tabsCount = 0;
const openAllPosts = () => {
  if (window.location.href.indexOf('https://steemit.com') === -1) {
    const msg = 'You gotta be on steemit to access the localStorage to get the posts..!';
    alert(msg);
    throw new Error(msg);
  }
  tabsCount = 0;
  const fromOldestToLastPost = [1,2,3,4,5,6,0];
  const allPostsArray = [];
  fromOldestToLastPost.forEach((idx) => {
    const linksForDay = getTodaysLinkCodeOnly(idx);
    if (linksForDay.indexOf('NOT FOUND') === -1) allPostsArray.push(linksForDay);
  });
  if (!allPostsArray.length) {
    logsOn && console.debug('NO LINKS FOUND IN LOCAL STORAGE!! Open all posts interrupted.');
    return;
  }
  logsOn && console.debug(`${now()} -- Opening links. Found posts for ${allPostsArray.length} day(s).`);
  recursivelyOpenMyPostsInNewTabs(allPostsArray);
}

const recursivelyOpenMyPostsInNewTabs = (allPostsArray) => { // ['link1,link2','linkA,linkB','link'] // max-links: 21 !!
  if (!allPostsArray) {
    const msg = 'Use openAllPosts() not this!';
    alert(msg);
    throw new Error(msg);
  }
  const firstLinkGroup = allPostsArray && allPostsArray[0];
  if (firstLinkGroup === undefined) {
    logsOn && console.debug(`${now()} -- ----- ALL DONE. Opened ${tabsCount} posts.`);
    countPostsWeek = tabsCount;
    updateCount('openAllPosts');
    return; // exit case
  }
  const firstLinkGroupArr = firstLinkGroup.split(',');
  const link = firstLinkGroupArr[0];
  if (firstLinkGroupArr[1]) {
    firstLinkGroupArr.shift();
    allPostsArray[0] = firstLinkGroupArr.join(',');
  } else {
    allPostsArray.shift()
  }
  logsOn && console.debug(`${now()} -- Opening link ${link}..`);
  const w = open(link); //, '_blank');//,'toolbar=no,status=no,menubar=no,left=1000000,top=10000000',''); //  ,width=100,height=100, scrollbars=no,resizable=no, ,visible=none
  w.addEventListener('load', () => {
    logsOn && console.debug(`${now()} -- Page ${link} loaded.`);
    tabsCount++;
    updateUpvotesAndPayoutCount(w);
    recursivelyOpenMyPostsInNewTabs(allPostsArray);
  });
}

const addTodaysPostToLocalStorageManual = (link) => {
  if (!link || link.indexOf('https://steemit.com') == -1 || link.indexOf(accounts[usag]) == -1) {
    throw new Error('Invalid argument. Provide your link to save in the localStorage.');
  }
  const dow = getTodaysDOW();
  for(let id = 1; id < 4; id++) {
    const currPost = localStorage.getItem(`${dow}${id}`);
    if (!currPost) {
      localStorage.setItem(`${dow}${id}`, link);
      if (usag !== 'chrome') {
        cancelTaskAtTime(usag === 'edge' ? 8 : 1, 'from-code');
        openGithubAndLastPost();
      }
      return `DONE. Added ${link} in localStorage as ${dow}${id}`;
    }
  }
  throw new Error(`LocalStorage FULL. Unable to add ${link}`);
}

const openLastPost = (minusN) => { // -1, -2
  const howManyToSkip = -minusN || 0;
  let foundcounter = 0;
  const fromLastPost = [0,6,5,4,3,2,1];
  let linkToOpen, which;
  fromLastPost.forEach((idx) => {
    const linksForDay = getTodaysLinkCodeOnly(idx);
    if (!linkToOpen && linksForDay.indexOf('NOT FOUND') === -1) {
      const dayLinks = linksForDay.split(',');
      for (let i = 0 ; i < dayLinks.length; i++) {
        foundcounter++;
        if (foundcounter === howManyToSkip + 1) {
          linkToOpen = dayLinks[i];
          which = `Today + ${idx} days % 7`;
        }
      }
    }
  });
  if (!linkToOpen) {
    throw new Error('NO LINKS FOUND IN LOCAL STORAGE!!');
  }
  logsOn && console.debug(`${now()} -- Opening link ${linkToOpen}. Found in: ${which}`);
  return open(linkToOpen);
}

const cancelTaskAtTime = (time, fromCode) => {
  if (tasks[time] == undefined) {
    const msg =  `Error. Task for hour ${time} not found.`;
    if (!fromCode) alert(msg);
    else logsOn && console.error(msg);
    return;
  }
  const POST_CREATION_TIME = usag === 'edge' ? 8 : 1;
  if (time === POST_CREATION_TIME && tasks[POST_CREATION_TIME].name !== 'Post Creation') {
    const msg =  `Error. Gotta update cancelTaskAtTime. Post Creation is not at ${POST_CREATION_TIME} anymore..`;
    if (!fromCode) alert(msg);
    else logsOn && console.error(msg);
    return;
  }
  tasks[time].calledToday = true;
  updateUIAndChangeBtnColorTo(1, time === POST_CREATION_TIME ? 2 : 1);
  logsOn && console.debug(`${now()} -- OK, I WONT EXECUTE TASK "${tasks[time].name}" TODAY AT ${time}.`);
}

// Date hack:
// original = Date;
// mock = new Date('Fri Sep 13 2019');
// Date = class extends Date{
//      constructor() {
//        return mock;
//      }
//    };
// new Date();
// // Date = original


document['ation'] = {
  // let tasks = {
  //   // hours, id, name, calledInSameHour
  //   '2': { id: 1, name: 'Resteem users_h2', calledToday: false }, // + delays
  //   '4': { id: 1, name: 'Resteem users_h4', calledToday: false }, // + delays
  //   '9': { id: 1, name: 'Resteem users_h9', calledToday: false }, // + delays
  //   '10': { id: 1, name: 'Resteem users_h10', calledToday: false }, // + delays
  //   '13': { id: 1, name: 'Resteem users_h13', calledToday: false }, // + delays
  //   '19': { id: 1, name: 'Resteem users_h19', calledToday: false }, // + delays
  //   '21': { id: 1, name: 'Resteem users_h21', calledToday: false }, // + delays
  //   '23': { id: 1, name: 'Resteem users_h23', calledToday: false }, // + delays
  //   '100': { id: 3, name: 'Spam Resteemers', calledToday: false }, // + delays
  //   '101': { id: 4, name: 'Self Promotion' }, // + delays
  // }; tasks[`${usag === 'edge' ? '8':'1'}`] = { id: 2, name: 'Post Creation', calledToday: false }; // + delays
  //
  // BOTS SUMMARY:
  // - gaottantacinque: personal blog (coding, security, photo, music)
  // - gasaeightyfive: (usual free resteems comments)
  //     * crappy upvote if: first 10 or resteemed
  //     * subscription + cheap resteem
  // - marcocasario: (usual free resteems comments)
  //     * $0.03 upvote if: resteem
  // - cribbio: (usual free resteems comments)
  //     * MAX 3 LINKS
  //     ( * crappy upvote if first 10 or resteemed )
  //
  // COMMANDS:
  // TODO
}
