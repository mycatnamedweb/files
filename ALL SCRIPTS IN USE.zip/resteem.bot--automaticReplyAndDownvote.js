﻿// NEXT:
// - #resteembot #bestofresteembot #winwithresteembot #resteembotvip
// - hey, @resteem.bot's 100% upvote is worthless: https://steemd.com/@resteem.bot
//
// - give free memberships if users downvote him? nah..
// - downvote flauschi?



// - if he messes up separators -> sort age + arr.reverse()



// CHANGE THESE IF NEEDED:

const MY_ACCOUNT_NAME = 'marcocasario'; // gasaeightyfive. (cribbio broken..?)
const STOP_VOTING_AT = 0.07; // gasa: -1

const EVERY_X_MINS = 5;
const BOT_OFF_AT_HOURS = [20,21,22,23,0,1];

let logsOn = false;

const extractUA = () => {
  const ua = navigator.userAgent.split(' ').pop().split('/')[0].toLowerCase();
  return ua === 'safari' ? 'chrome' : ua;
}
if (extractUA() !== 'opr' && MY_ACCOUNT_NAME === 'marcocasario') {
  alert(`Error. You're not on opr but the account is marcocasario!`);
  throw new Error(`Wrong account!`);
}

const todaysLink = () => {
  const days = 'sunday,monday,tuesday,wednesday,thursday,friday,saturday';
  const today1 = `${days.split(',')[new Date().getDay()]}1`;
  const yesterday1 = `${days.split(',')[(new Date().getDay() - 1) % 7]}1`;
  return localStorage.getItem(today1) || localStorage.getItem(yesterday1) || 'https://steemit.com/@marcocasario';
}

const getTodaysDOW = (arg) => { // -1 or +n
  let dayIdx = new Date().getDay();
  if (arg === -1) dayIdx = (dayIdx + 6) % 7;
  else if (+arg) dayIdx = (dayIdx + arg) % 7;
  return 'sunday,monday,tuesday,wednesday,thursday,friday,saturday'.split(',')[dayIdx];
};

const getFlagedReply = (contextHref) => {
  if (MY_ACCOUNT_NAME === 'gasaeightyfive') {
    const link = todaysLink();
    return link ? `<sub>--auto reply-- </sub> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <sub>[Reason for low rep score? The nazi.](https://steemit.com/steemithelp/@gasaeightyfive/did-you-miss-my-article-in-the-news-steemit-weekly-news-steemit-mafia)</sub>
    <h5>Since he spams us.. today's FREE RESTEEM post [here](${link}).</h5>` : 'https://steemit.com/created/resteem';
  } else {
    return Math.random() >= 0.3 ? `
  <sub>-- automatic reply --</sub>
  ${contextHref.indexOf('@marcocasario') !== -1 ? '':`( Since he spams us - [Today's FREE RESTEEM post](${todaysLink() || 'https://steemit.com/created/resteem'}) )`}

  NOPE @resteem.<b>${Math.random()>=0.5?'rot':'bot-not'}</b>, <b>YOU</b> ${Math.random()>=0.3?'are':'have been'} flaGGed for multiple account spam, comment spam and tag spam.
  If I was a spammer as he claims, Steemit Police (cheeta, steemcleaners, etc) would add their comments all around me or I'd be on their blacklist. [Nope](http://blacklist.usesteem.com/user/marcocasario).

  The accounts of ${Math.random()>=0.3?'The':'THE'} spammer${Math.random()>=0.3?' / scammer / thief':' nazi'}:

  Main account:
  https://steemit.com/@flauschi

  Spam accounts:
  https://steemit.com/@resteem.bot
  https://steemit.com/@sweety170 <sub>( [proof](https://steemd.com/@sweety170#9da00a3f21715483b4c34679b71c667a54b67abe) )</sub>
  ( [many other accounts](https://steemit.com/steemit/@rcr.bis/resteem-bot-is-cheating-the-system-and-trying-to-hurt-others-for-self-gain) )

  Manual ( ${Math.random()>=0.3?':\'D':'XD'} ) comment spam:
  https://steemit.com/@resteem.bot/comments

  Community tags he is spamming: #resteembot, #bestofresteembot, #winwithresteembot, #resteembotvip
  <b>[The ${Math.random()>=0.3?'1st':'first'} one existed even before he joined. He started ${Math.random()>=0.3?'flagging':'downvoting'} ${Math.random()>=0.3?'people':'users'} to steal it!](https://steemit.com/resteem/@resteem.bot/4neva7-steemit-resteem-bot-faq#@thedolphin/re-resteembot-4neva7-steemit-resteem-bot-faq-20180518t013035772z)</b>

  <h6>More info on the ${Math.random()>=0.3?'nazi':'bully'}:</h6>
  - [${Math.random()>=0.3?'Recap':'SUMMARY of this wrongdoings'}](https://steemit.com/resteem/@marcocasario/re-marcocasario-re-resteembot-re-cribbio-joke-of-the-day-daily-free-resteem-bot-leave-your-link-in-the-comments-open-for-3days-18-sep-20180918t212938392z)
  - [${Math.random()>=0.3?'themarkymark\'s':'One of Steemit Witnesses\''} article](https://steemit.com/byteball/@themarkymark/byteball-referrals-snipped-was-probably-resteem-bot)
    `
    // <h6>PS. Since ${Math.random()>=0.3?'he':'resteem.bot'} spams me let's take advantage of it - [Free Resteems](https://steemit.com/created/resteem) on ${Math.random()>=0.3?'the other accounts too':'all those accounts'}! &nbsp; : )</h6>
    :
    `
  Sure, if ${Math.random()>=0.3?'publishing ':''}one post a day is ${Math.random()>=0.5?'spam':'spamming'} then [you're the mother of spam](https://steemit.com/@resteem.bot/comments). ${Math.random()>=0.9?'Aka #spammutti #mutterdesmulls':''}.<br>

  We know you don't like competitors${Math.random()>=0.3?', cyber bully':' kid'}.
  ( [${Math.random()>=0.2?'hilarious, just':'Just'} one example.](https://steemit.com/steemit/@resteem.bot/resteem-bot-version-2-0-banana-dont-t-forget-the-point#@resteembot/re-resteembot-resteem-bot-version-2-0-banana-dont-t-forget-the-point-20171219t155829769z) ${
  Math.random()>=0.8?`And do you still stop your service for bad wifi when it rains${Math.random()>=0.4?' pathetic kid':' liar kid'}? ROFL`:' =)'} )

  ${Math.random()>=0.5?`PS. In reply to the accusations of the ${Math.random()>=0.9?'troll kid':'cyber bully'} (@resteem.bot / @flauschi / many ${Math.random()>=0.5?'other accounts':'downvote accounts nuked by admins'}`:''})
  - gaottantacinque ${Math.random()>=0.5?'owns only':'only owns'} gasaeightyfive${Math.random()>=0.1?', the others are biz partners':''}<sub> &nbsp;free resteems!</sub>
  - The automated ${Math.random()>=0.5?'comments':'replies'} are ${Math.random()>=0.5?'just':'only'} on @resteem.bot comments, see below ${Math.random()>=0.5?'for the reasons':''}
  - He claims ${Math.random()>=0.5?'#resteembot':'tags'} that existed even before he joined. We use ${Math.random()>=0.5?'1':'one'} of "his" tags a day${Math.random()>=0.5?' as retaliation':''} for the reasons ${Math.random()>=0.3?'explained ':' '}below:
  https://steemit.com/freeresteems/@resteem.bot/re-gasaeightyfive-service-updates-and-support-20180731t111823030z#@marcocasario/re-resteembot-re-gasaeightyfive-service-updates-and-support-20180803t155353009z

  Even your name is a lie <em>@</em>resteem.bot. You do everything manually. [No resteems during your night time](https://steem.makerwannabe.com/@resteem.bot/resteemed/2), how come?? :'D
  ${Math.random()>0.9?'![fake-robot.gif](https://cdn.steemitimages.com/DQmeRQwRcZFnnqGEN7Tf3cDvXU3fkPgsnT9coUme8717QMj/fake-robot.gif)':''}
  ${contextHref.indexOf('@marcocasario') !== -1 ? '':`<sub>PS. Since ${Math.random()>=0.3?'the nazi':'resteem.bot'} spams us let's ${Math.random()>=0.5?'take advantage of it':'tell the readers that we offer..'} - [FREE Resteems on our daily posts](${todaysLink()}) on ${Math.random()>=0.3?'the other accounts too':'all those accounts'}! &nbsp; : )</sub>`}
    `;
  }
}

const getBadNewsReply = () => `
  Right, or maybe ${Math.random()>=0.5?'we angered':''} just you ${Math.random()>=0.5?'and your right hand':'and your mommy'}.

  Stop ${Math.random()>=0.5?'trolling':'bullying'} kid. We know you don't like ${Math.random()>=0.5?'competitors':'competition'}.
`;
const bigReplyText = () => `<sub>Why is my repo so low? [Thanks to this ${Math.random()>=0.5?'nazi':'mafioso'}](https://steemit.com/steemit/@marcocasario/resteem-bot-as-he-did-with-others-managed-to-send-our-repo-to-3-cribbio-marcocasario-gasaeightyfive) that does not like our [FREE Resteems](${todaysLink()})</sub>

  ${Math.random()>=0.95?'No self upvote payout for this hypocrite and immoral individual!<br>':''}
  ⚠️⚠️⚠️ &nbsp; Who is @resteem.bot / flauschi / sweety170 <sub>[proof](https://steemd.com/@sweety170#9da00a3f21715483b4c34679b71c667a54b67abe)</sub> / ([many other accounts](https://steemit.com/steemit/@rcr.bis/resteem-bot-is-cheating-the-system-and-trying-to-hurt-others-for-self-gain)) /
    &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;   &nbsp;  aka "slow manual resteemer":

  - He <b>STEALS</b>:
  1. As pointed out by one of Steemit ${Math.random()>=0.9?'main':''} Witnesses
  <sub>(right click, "Open${Math.random()>=0.5?' image':''} in a new tab" or click on the image)</sub>
  <a href="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmcmk1mns7QB7Xfi9NXwh3kvTu2cHXTbPxV8CyZzST5eUw/image.png"><img src="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmcmk1mns7QB7Xfi9NXwh3kvTu2cHXTbPxV8CyZzST5eUw/image.png"/></a>

  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  [ themarkymark ${Math.random()>=0.5?'also':''} wrote [a WHOLE POST about him](https://steemit.com/byteball/@themarkymark/byteball-referrals-snipped-was-probably-resteem-bot) ]
  2. He stole [~$100 from a veteran](https://steemit.com/discussion/@dynamicgreentk/re-marcocasario-re-dynamicgreentk-re-marcocasario-re-resteembot-re-marcocasario-re-robertandrew-re-kittyninja-re-whatsup-questions-for-steemit-inc-20180917t001816056z)
  <a href="https://steemit.com/discussion/@dynamicgreentk/re-marcocasario-re-dynamicgreentk-re-marcocasario-re-resteembot-re-marcocasario-re-robertandrew-re-kittyninja-re-whatsup-questions-for-steemit-inc-20180917t001816056z"><img src="https://cdn.steemitimages.com/DQmViMLcRaZwxdpZMEfPdLwnuoEvx2UNSKe6VRDaJRz7fAC/image.png"></a>
  <sub>(click on the image for more info)</sub>
  <br/>
  3. He [stole tags](https://steemit.com/resteem/@resteem.bot/4neva7-steemit-resteem-bot-faq#@thedolphin/re-resteembot-4neva7-steemit-resteem-bot-faq-20180518t013035772z)
  <br/>

  - Most of his <b>FOLLOWERS</b> are <b>FAKE</b> as pointed out by ${Math.random()>=0.9?'one of the admins':'another Steemit Witness'}
  <sub>(right click, "Open${Math.random()>=0.5?' image':''} in a new tab" or click on the image)</sub>
  <a href="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmUBCYE1MomSdimJUyFBQZe8toHtFV6hQHCgBVQzooMF8F/admin%20reply%20to%20resteem.bot.png"><img src="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmUBCYE1MomSdimJUyFBQZe8toHtFV6hQHCgBVQzooMF8F/admin%20reply%20to%20resteem.bot.png" alt="admin reply to resteem.bot.png"/></a>
  <sub>&nbsp;</sub>
    And here is more proof: <b>~19 K ghost users (of which ~11 K dead accounts)</b>
  <a href="https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmZWLBv4uZ1dkKZW4P7gvWcC3sLFpoUdB5CCuqqsCUJZFe/image.png"><img src="https://cdn.steemitimages.com/DQmZWLBv4uZ1dkKZW4P7gvWcC3sLFpoUdB5CCuqqsCUJZFe/image.png"></a>
  <sub>Source: https://www.steemspectacles.com/@resteem.bot/followers</sub>
  <br>
  - He <b>SPAMS</b>. <sub>One of the [MOST RECENT ONES](https://xenodochial-mahavira-8d9c76.netlify.com/whatsup-offtopic-mess.png). <B>Byteball spam:</B>  [example1](https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmQ3MNUzGQVj17yCUgUAZAPbVZU6u4i9mQuzsExjZNFYw7/image.png), [another byteball spam comment on other people's posts](https://steemit.com/appreciator/@abhinavmendhe/alphabet#@resteem.bot/re-abhinavmendhe-alphabet-20180723t193941655z), [one more](https://steemit.com/charlesfuchs/@stackin/giving-away-free-byteball-tokens-to-my-followers#@resteem.bot/re-stackin-giving-away-free-byteball-tokens-to-my-followers-20180715t224642660z), [again](https://steemit.com/byteball/@goldenarms/can-a-brother-get-a-byteball-hook-up#@resteem.bot/re-goldenarms-can-a-brother-get-a-byteball-hook-up-20180716t123838408z), [flagging competitors for byteball referrals](https://steemit.com/byteball/@jedi-won/re-punqtured-referral-links-are-king-20180721t172352833z), [example](https://steemit.com/discussion/@marcocasario/re-resteembot-re-dynamicgreentk-re-resteembot-re-dynamicgreentk-re-marcocasario-re-resteembot-re-marcocasario-re-robertandrew-re-kittyninja-re-whatsup-questions-for-steemit-inc-20180918t022659664z), [themarkymark's reply](https://steemitimages.com/0x0/https://cdn.steemitimages.com/DQmUH5wyax82ahLcMzUqt3EF3WCgmE3d1Q1ZCZSTNyc4K61/image.png)</sub>
  <br/>
  <br/>
  - He <b>LIES</b> about his service. He [always <b>manually</b> resteems during his day time](https://steem.makerwannabe.com/@resteem.bot/resteemed/2), not when it's best for you as he claims instead in [his FAQs](https://steemit.com/resteem/@resteem.bot/4neva7-steemit-resteem-bot-faq) and [his replies](https://xenodochial-mahavira-8d9c76.netlify.com/liar.png)!
  <sub>( [And clearly only if it's not raining..](https://steemit.com/steemit/@resteem.bot/resteem-bot-version-2-0-banana-dont-t-forget-the-point#@resteembot/re-resteembot-resteem-bot-version-2-0-banana-dont-t-forget-the-point-20171219t155829769z) )</sub>
  <br/>
  - It's ${Math.random()>=0.5?'pretty':''} well know by now that he tries to <b>DAMAGE COMPETITORS</b> in general:
  [see HERE](https://steemit.com/steemit/@rcr.bis/resteem-bot-is-cheating-the-system-and-trying-to-hurt-others-for-self-gain), <sub>[example 2](https://steemit.com/resteem/@resteem.bot/4neva7-steemit-resteem-bot-faq#@thedolphin/re-resteembot-4neva7-steemit-resteem-bot-faq-20180518t013035772z), [example 3](https://steemit.com/flag/@rcr.bis/re-guiltyparties-the-flag-ring-20180715t083311448z#@guiltyparties/re-rcrbis-re-guiltyparties-the-flag-ring-20180724t152007480z), [example 4](https://steemit.com/steemit/@resteem.bot/re-vimukthi-re-foovler-re-transparencybot-the-daily-coverup-transparency-under-attack-5-02-18-20180502t165440954z), [example 5](https://steemit.com/cryptocurrency/@crypto.piotr/what-s-your-view-on-bots-promotion-tool-or-necessary-evil-let-me-share-my-personal-view#@trumanity/re-resteembot-re-cryptopiotr-re-trumanity-re-resteembot-re-cryptopiotr-re-resteembot-re-cryptopiotr-what-s-your-view-on-bots-promotion-tool-or-necessary-evil-let-me-share-my-personal-view-20180526t132017982z), ..</sub>
  <sub>(right click, "Open${Math.random()>=0.5?' image':''} in a new tab" or click on the image)</sub>
  <a href="https://cdn.steemitimages.com/DQmUa774vs84mvCeFFCJwApp9MNavzAikMaqW27XZvAPG3S/image.png"><img src="https://cdn.steemitimages.com/DQmUa774vs84mvCeFFCJwApp9MNavzAikMaqW27XZvAPG3S/image.png"></a>
  <a href="https://steemitimages.com/0x0/https://xenodochial-mahavira-8d9c76.netlify.com/nazi-competitors.png"><img src="https://steemitimages.com/0x0/https://xenodochial-mahavira-8d9c76.netlify.com/nazi-competitors.png"></a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <sub><sub><sub>[rep nuked](https://steemit.com/steemit/@marcocasario/resteem-bot-as-he-did-with-others-managed-to-send-our-repo-to-3-cribbio-marcocasario-gasaeightyfive)</sub></sub></sub>

  - He <b>THREATENS PEOPLE</b> [through anonymous emails!!](https://steemit.com/life/@anomaly/an-open-letter-to-the-steemit-community-and-the-anonymous-spammers-who-have-been-threatening-to-flag-me#@marcocasario/re-anomaly-an-open-letter-to-the-steemit-community-and-the-anonymous-spammers-who-have-been-threatening-to-flag-me-20180920t214029438z)
`;
// <em>And he also steals content - see [here](https://steemit.com/win/@resteem.bot/win-with-resteem-bot-30-07-2018#@marcocasario/re-resteembot-win-with-resteem-bot-30-07-2018-20180731t195742167z)</em>


// VARS

let enoughVotingPower = true;
let stopNow = false;
let titlesDb = [];
let errors = [];
let downvotesCount = 0;
let selfUpvotesCount = 0;
let repliesCount = 0;
let skipList = ['ricpicks', 'arcanu', 'valentin86','ektorcaba','friendly-fenix','amzar123'];

const addToSkipList = (user) => {
  logsOn && console.debug(`${user} won't be bothered anymore with my spam comment on nazi.
  >>>> NOTE: add in skipList in code base too (unless you add LS feature..)`);
  skipList.push(user);
}

const getCommentIntro = (id) => {
  switch (id) {
    case 0:
      return `Re: ${Math.random()>=0.5?'@':''}resteem.bot - ${Math.random()>=0.5?'Watch':'watch'} out for this ${Math.random()>=0.5?'scammer':'thief'}!! More info${Math.random()>=0.5?': &nbsp; 👇':'.. 📖'}`;
    case 1:
      return `RE: ${Math.random()>=0.5?'@':''}resteem.bot -- ${Math.random()>=0.5?'Diffide from':'Be wary of'} this ${Math.random()>=0.5?'dishonest':''} individual${Math.random()>=0.5?'...':':'}`;
    default:
      return `re: ${Math.random()>=0.5?'@':''}resteem.bot \n${Math.random()>=0.5?'Warning':'Disclosure'} about this ${Math.random()>=0.5?'THIEF':'cheater'}${Math.random()>=0.9?':':''}`;
  }
}

const getCommentLink = (id) => { // NOTE: >>>> '@marcocasario/re-resteembot-re-' IN USE TO AVOID DOUBLE COMMENTS <<<<<<
  switch (id) {
    case 0:
      return `https://steemit.com/resteem/@marcocasario/re-marcocasario-re-resteembot-re-cribbio-joke-of-the-day-daily-free-resteem-bot-leave-your-link-in-the-comments-open-for-3days-18-sep-20180918t212938392z`;
    case 1:
      return `https://steemit.com/win/@marcocasario/re-resteembot-win-with-resteem-bot-31-08-2018-20180831t174651800z`;
    case 2:
      return `https://steemit.com/steemithelp/@marcocasario/re-marcocasario-re-resteembot-re-gasaeightyfive-did-you-miss-my-article-in-the-news-steemit-weekly-news-steemit-mafia-20180831t012054471z`;
    default:
      return `https://steemit.com/win/@marcocasario/re-resteembot-win-with-resteem-bot-15-08-2018-20180815t192412525z`;
  }
}

const getApology = (apologiesTo) => {
  return  Math.random() >= 0.5 ?
    `( ${Math.random()>=0.5?'Apologies for the':'Please excuse my'} little ${Math.random()>=0.5?'invasion':'incursion'} @${apologiesTo} ${Math.random()>=0.5?':)':': )'} )
    Reply "@marcocasario SKIP" to turn these off for you. Thanks :)` :
    `<em>@${apologiesTo} ${Math.random()>=0.5?'apologies for the':'please forgive my'} little intrusion. Reply "@marcocasario SKIP" to ${Math.random()>=0.5?'turn off these':'turn these off'} for you. Thanks :)
    </em>`;
}

const getLessIntrusiveComment = (apologiesTo, wReply) => {
  const randomIdTxt = Math.floor(Math.random() * 3 - 1) + 1;
  const intro = getCommentIntro(randomIdTxt);
  const randomIdLink = Math.floor(Math.random() * 4 - 1) + 1;
  const link = getCommentLink(Math.random() >= 0.5 ? 0 : randomIdLink);
  const apology = wReply.window.location.href.indexOf('@resteem.bot') !== -1 ? '' : getApology(apologiesTo);
  const introFirst = Math.random() >= 0.2;
  return `<sub>Why is my rep so low? [Thanks to <b>@</b>resteem.bot](https://steemit.com/steemit/@marcocasario/resteem-bot-as-he-did-with-others-managed-to-send-our-repo-to-3-cribbio-marcocasario-gasaeightyfive) because I offer [FREE Resteems](${todaysLink()})!</sub>

  ${introFirst ? intro : `${apology}\n`}
  ${link}
  ${introFirst ? `\n${apology}` : intro}`;
}

// utils

const sleep = (durationMs) => new Promise(resolve => setTimeout(() => {resolve()}, durationMs));
const now = () => new Date().toString().split(' ').slice(1,5).join(' ');

const setNativeValue = (element, value, w) => {
  const valueSetter = Object.getOwnPropertyDescriptor(element, 'value').set;
  const prototype = !w ?
    Object.getPrototypeOf(element) : w.window.Object.getPrototypeOf(element);
  const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value').set;
  if (valueSetter && valueSetter !== prototypeValueSetter) {
    prototypeValueSetter.call(element, value);
  } else {
    valueSetter.call(element, value);
  }
}


// main logic helpers

const addWarning = (commentsPage, errors) => {
  try {
    const target = commentsPage ? commentsPage.document : document;
    const divToAdd = target.createElement('div');
    divToAdd.id = 'warning';
    const myStyle = divToAdd.style;
    myStyle.border = '2px solid red';
    myStyle.padding = '20px';
    myStyle['text-align'] = 'center';
    myStyle.width = '50%';
    myStyle.position = 'fixed';
    myStyle.top = '200px';
    myStyle.left = '25%';
    myStyle['background-color'] = 'orange';
    myStyle['z-index'] = '1000';
    if (commentsPage) {
      logsOn && console.debug(`${now()} -- Adding warning to other tab..`);
      divToAdd.innerHTML = `<h4 style="color:red">DO NOT CLOSE THIS WINDOW.<br>Processing nazi's stuff..</h3>`;
    } else {
      logsOn && console.debug(`${now()} -- Adding errors notice to current tab..`);
      divToAdd.style['max-height'] = '400px';
      divToAdd.style.overflow = 'auto';
      divToAdd.innerHTML = `
        <h6 style="color:red">THERE ARE ERRORS</h6>
        <ul>
          ${errors.map(err => `<li>${err}</li>`).join('<br>')}
        </ul>
      `;
    }
    const warningDiv = document.getElementById('warning');
    if (warningDiv) {
      warningDiv.parentNode.removeChild(warningDiv);
    }
    target.body.insertBefore(divToAdd, target.body.firstChild);
  } catch (err) {
    console.error(`${now()} -- Error in addWarning: ${err}`);
  }
}

const isRightBtn = (upvoteBtn) =>
  upvoteBtn.offsetParent && upvoteBtn.offsetParent.offsetParent.offsetParent.offsetParent ?
    upvoteBtn.offsetParent.offsetParent.offsetParent.offsetParent.id.indexOf(`#@${MY_ACCOUNT_NAME}`) === -1
    : upvoteBtn.parentElement.parentElement.parentElement.parentElement
      .parentElement.parentElement.parentElement.innerText.split(']')[1].split(' (')[0] === MY_ACCOUNT_NAME;

// const isRightWeightBtn = (weightBtn) => weightBtn.parentElement &&
//   weightBtn.parentElement.parentElement.parentElement
//   .parentElement.parentElement.parentElement
//   .parentElement.parentElement.innerText.split('by ')[1].split(' (')[0] === MY_ACCOUNT_NAME;

const isRighCommentWeightBtn = (weightBtn, win) => {
  try {
    const name = weightBtn.parentElement.parentElement.parentElement
      .parentElement.parentElement.parentElement.parentElement
      .parentElement.parentElement
      .innerText.split('[-]')[1].split(' (')[0];
    logsOn && console.debug(`Weight btn is for name: ${name}`);
    return name === MY_ACCOUNT_NAME;
  } catch (err) {
    console.error(err);
    return false;
  }
}

async function upvoteMyCommentIfNew(element, wReply, isPost) {
  try {
    const comment = wReply.document.getElementById(element.id);
    const upvoteBtn = comment.querySelectorAll('a[title="Upvote"]')[0];
    if (!upvoteBtn) {
      logsOn && console.debug(`${now()} -- Comment was already upvoted..`);
    } else if (!isRightBtn(upvoteBtn)) {
      logsOn && console.debug(`${now()} -- Not my upvote btn, it's the nazi's (or other commenter). Means that mine is upvoted already.`);
    } else {
      if (!enoughVotingPower && !isPost) {
        logsOn && console.debug('Skipping self upvote - enoughVotingPower still set to false');
        return;
      }
      upvoteBtn.click();
      await sleep(1000);

      const weightBtn = wReply.document.querySelectorAll('a[class="confirm_weight"]')[0];
      if (isRighCommentWeightBtn(weightBtn)) {
        weightBtn.click();
      } else {
        console.error(`${now()} -- upvoteMyCommentIfNew __ Weight button was not the comment one! Not clicked.`);
      }
      await sleep(6000);
      selfUpvotesCount++;
      logsOn && console.debug(`${now()} -- Checking voting power`);
      const currentPay = +element.querySelectorAll('span[class="Voting"]')[1].innerText.substr(1,5).trim();
      // enoughVotingPower = currentPay >= STOP_VOTING_AT;
    }
  } catch (err) {
    console.error(`${now()} -- Error in upvoteMyCommentIfNew: ${err}`);
    errors.push(`${now()} -- upvoteMyCommentIfNew __ ${err}`);
  }
}

const getIfPostFlag = (win) => {
  try {
    logsOn && console.debug(`${now()} -- getIfPostFlag __ getting post flag btn..`);
    const flagDropBtn = win.document.querySelectorAll('span[title="Flag"]')[0];
    const isPf1 = flagDropBtn &&
      flagDropBtn.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement
      .className === 'PostFull hentry';
    const flagDropBtn2 = win.document.querySelectorAll('a[title="Flag"]')[0];
    const isPf2 = flagDropBtn2 &&
      flagDropBtn2.parentElement.parentElement.parentElement.parentElement.parentElement
      .className === 'PostFull hentry';
    if (!isPf1 && !isPf2) throw 'no pf';
    if (flagDropBtn2 && flagDropBtn2.id === 'revoke_downvote_button') {
      logsOn && console.debug('found flag btn and its already used. Stopping.');
      throw 'no pf';
    }
    return isPf1 ? flagDropBtn : flagDropBtn2;
  } catch (err) {
    err !== 'no pf' && errors.push(`${now()} -- isPostFlag __ ${err}`);
    console.error(`${now()} -- getIfPostFlag __ error. Won't dowvote.. (skip all remaining replies though..). Cause: ${err}`);
    throw 'no-downvote-btn';
  }
}

async function downVoteNazi (win, forceDownvote) {
  try {
    if (enoughVotingPower || forceDownvote || MY_ACCOUNT_NAME === 'gasaeightyfive') {
      logsOn && console.debug(`${now()} -- Downvoting...`);
      let flagDropBtn = getIfPostFlag(win);
      flagDropBtn.click();
      await sleep(2000);
      const confirmFlagBtn = win.document.querySelectorAll('span[title="Flag"]')[1];
      logsOn && console.debug(`${now()} -- downVoteNazi __ checking confirmation form for flagging..`);
      if (confirmFlagBtn.parentElement.className !== "clear Voting__about-flag") throw 'no-downvote-btn';
      confirmFlagBtn.click();
      await sleep(1000);
      const confirmAgain = win.document.querySelectorAll('button[class="button"]')[0];
      confirmAgain && confirmAgain.click();
      await sleep(7000);
      downvotesCount++;
    } else {
      logsOn && console.debug(`${now()} -- Not enough vp to vote my comment and downvote him. Sleeping 10s for comments delay..`);
      await sleep(10000);
    }
  } catch (err) {
    console.error(`${now()} -- Error in downVoteNazi: ${err}`);
    if (err === 'no-downvote-btn') {
      if (MY_ACCOUNT_NAME === 'gasaeightyfive') throw err;
      else err = `Was gonna click the wrong downvote button! (or it's already hidden, ok) Skipped.`
    }
    // errors.push(`${now()} -- downVoteNazi __ ${err}`);
    console.error(`${now()} -- downVoteNazi __ ${err}`);
  }
}

const linkHasNoneOfMyAccountNames = (link) => {
  let notFound = true;
  ['gaottantacinque', 'gasaeightyfive', 'marcocasario', 'cribbio'].forEach(account => {
    if (notFound) notFound = link.indexOf(account) === -1;
  });
  return notFound;
}

const isFlagedCommentOnMyPosts = (wReply, contextHref) => {
  if (linkHasNoneOfMyAccountNames(contextHref)) {
    return false;
  }
  const articleText = wReply.document.getElementsByTagName('article')[0].textContent.toLowerCase();
  return articleText.indexOf('resteembot') !== -1 && articleText.indexOf(' spam') !== -1 ? true : false;
}

const isBadNews = (wReply, contextHref) => {
  if (linkHasNoneOfMyAccountNames(contextHref)) {
    return false;
  }
  const articleText = wReply.document.getElementsByTagName('article')[0].innerText;
  return articleText.indexOf('Bad news') !== -1 ? true : false;
}

const getComment = (wReply) => {
  try {
    const reHeader = wReply.document.querySelectorAll('div[class="PostFull__header"]')[0];
    const context = reHeader.getElementsByTagName('a')[0];
    const name = context.innerText;
    const contextHref = context.href;
    const apologiesTo = contextHref.split('/@')[1].split('/')[0]; // tag/@username/blah
    if (name.toLowerCase() === 'view the full context' && contextHref.indexOf('/@resteem.bot') !== -1  && MY_ACCOUNT_NAME !== 'gasaeightyfive') {
      logsOn && console.debug(`${now()} -- Using long comment since it's a nazi's comment on his post.`)
      return getLessIntrusiveComment(apologiesTo);
    }
    if (skipList.indexOf(apologiesTo) !== -1) throw `reply on ${apologiesTo}'s post skipped bc asked to`;
    logsOn && console.debug(`${now()} -- Using short comment since it's another user's post (${apologiesTo}) .`);
    // if (isFlagedCommentOnMyPosts(wReply, contextHref)) return `${getFlagedReply()}\n
    //  Automatic tail:
    //  ${getLessIntrusiveComment(apologiesTo)}`;
    if (isFlagedCommentOnMyPosts(wReply, contextHref) && (MY_ACCOUNT_NAME !== 'gasaeightyfive' || contextHref.indexOf('@gasaeightyfive') == -1)) /*&& !linkHasNoneOfMyAccountNames(contextHref)))*/
      return `${getFlagedReply(contextHref)}`;
    if (isBadNews(wReply, contextHref)) return `
     ${getBadNewsReply()}\n
     ${getApology(apologiesTo)}`;
    return MY_ACCOUNT_NAME !== 'gasaeightyfive' ? getLessIntrusiveComment(apologiesTo, wReply) : null;
  } catch (err) {
    errors.push(`Error in getComment. Rethrown. ${err}`);
    throw err;
  }
}

async function addReplyToNazi(win, onPost) {
  if (MY_ACCOUNT_NAME === 'gasaeightyfive' && Math.random() >= 0/*.25*/) return console.log(`Skipping gasa reply to avoid spamming my daily posts too much..`);

  // initial check:
  logsOn && console.debug(`${now()} -- Double checking that my comment is not there to avoid my double comment..`);
  var allRepliesOnPage = win.document.querySelectorAll('div[class="Post_comments row hfeed"]')[0];
  if (!allRepliesOnPage) {
    throw new Error(`Comments section not found below nazi reply`);
  }
  if (MY_ACCOUNT_NAME !== 'gasaeightyfive' && allRepliesOnPage.innerText.indexOf(bigReplyText().substr(0,20).trim()) !== -1 // long comment
      ||  allRepliesOnPage.innerText.indexOf('@marcocasario/re-resteembot-re-') !== -1) { // those 3 links to long comment
    console.error(`${now()} -- I already posted here! Skipping..`);
    throw new Error(`I already posted here! Skipping..`);
  }

  try {
    logsOn && console.debug(`${now()} -- Adding reply ${onPost ? 'on nazis newly created post':'on nazis reply'}...`);
    let replyBtn = win.document.getElementsByClassName('PostFull__reply')[0]
      .getElementsByTagName('a')[0];
    replyBtn.click();
    await sleep(1000);
    let textarea = win.document.getElementsByTagName('textarea')[0];
    let comment;
    try {
      comment = onPost ? bigReplyText() : getComment(win);
    } catch (err) {
      if (`${err}`.indexOf('skipped') !== -1) {
        logsOn && console.debug(`User complained. Auto reply to nazi skipped.`);
        return 'user-skipped';
      }
      else throw err;
    }
    if (!comment) return;
    setNativeValue(textarea, comment, win);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(500);
    let postReplyBtn = win.document.querySelectorAll('[type=submit]')[1];
    logsOn && console.debug(`${now()} -- Sumbitting reply..`);
    postReplyBtn.click();
    await sleep(10000);
    repliesCount++;
  } catch (err) {
    console.error(`${now()} -- Error in addReplyToNazi: ${err}`);
    errors.push(`${now()} -- addReplyToNazi __ ${err}`);
  }
}

async function selfUpvoteMyCommentsToContrastNaziFlag(win, isPost) {
  try {
    var htmlEntities = win.document.querySelectorAll('div[class="hentry Comment root"]');
    var allMyReplies = Array.prototype.slice.call(htmlEntities);
    var repliesToNazi = allMyReplies.filter(div => div.id.indexOf(`#@${MY_ACCOUNT_NAME}/re-resteembot`) !== -1);
    // for (let id = 0; id < repliesToNazi.length; id ++) {
      logsOn && console.debug(`${now()} - Upvoting my comment ${0/*id*/}`);
      await upvoteMyCommentIfNew(repliesToNazi[0/*id*/], win, isPost);
    // }
  } catch (err) {
    console.error(`${now()} -- Error in selfUpvoteMyCommentsToContrastNaziFlag: ${err}`);
    errors.push(`${now()} -- selfUpvoteMyCommentsToContrastNaziFlag __ ${err}`);
  }
}

async function processAllNewReplies(newCommentsOnly) {
  for (let id = 0; id < newCommentsOnly.length && stopNow === false; id++) {
    try {
      const titleTxt = `RE: ${newCommentsOnly[id].innerText.split('RE: ')[1].split('\n')[0]}`;
      logsOn && console.debug(`${now()} -- id ${id}. Clicking on the comment button on the replies full list. Item title: ${titleTxt}`);

      var title = newCommentsOnly[id].querySelectorAll('h2[class="articles__h2 entry-title"]')[0]
      var toOopen = title.firstElementChild.href;
      let wReply;
      try {
        wReply = open(toOopen);
        await sleep(10000);

        logsOn && console.debug(`${now()} -- Adding my reply to nazi..`);
        const wasSkipped = await addReplyToNazi(wReply);
        if (!wasSkipped && enoughVotingPower && MY_ACCOUNT_NAME !== 'gasaeightyfive') {
          logsOn && console.debug(`${now()} -- Self upvoting my new comment..`);
          await selfUpvoteMyCommentsToContrastNaziFlag(wReply);
        }
        if (MY_ACCOUNT_NAME === 'gasaeightyfive' || enoughVotingPower) {
          try {
            await downVoteNazi(wReply);
          } catch (err) {
            if (err === 'no-downvote-btn' && MY_ACCOUNT_NAME === 'gasaeightyfive') {
              logsOn && console.debug(`MY_ACCOUNT_NAME === 'gasaeightyfive' is true (gasa85) and first comment is already flagged. Skipping the rest.`);
              break; // skip remaining comments
            }
          }
        }

        if (!enoughVotingPower) await sleep(10000); // comments delay -- reply on his comment only when cannot downvote
      } finally {
        wReply && wReply.close && wReply.close();
      }
    } catch (err) {
      console.error(`${now()} -- Error in processAllNewReplies: ${err}`);
      errors.push(`${now()} -- processAllNewReplies __ ${err}`);
    }
  }
}

const replyTitle = (element) => element && element.innerText.split('RE: ')[1].split('\n')[0].trim();

let repliesDbId = -1;

const fillDbWithAllFirstTwentyReplies = (commentsPage) => {
  var lastTwentyReplies = commentsPage.document.querySelectorAll('div[class="articles__summary"]');
  var lastTwentyRepliesArr = Array.prototype.slice.call(lastTwentyReplies);
  for (let id = 0; id < lastTwentyRepliesArr.length; id++) {
    const replyTitleTxt = replyTitle(lastTwentyReplies[id]);
    if (titlesDb.indexOf(replyTitleTxt) === -1) titlesDb[++repliesDbId % 40] = replyTitleTxt;
    if (isOneOfMyPosts(replyTitleTxt)) {
      const replyLink = getReplyLink(lastTwentyReplies[id]);
      if (alreadyProcessedLinks.indexOf(replyLink) === -1) alreadyProcessedLinks[++myPostRepliesId % 40] = replyLink;
    }
  }
}

const isOneOfMyPosts = (replyTitleTxt) => {
  const pos1 = replyTitleTxt.indexOf('FREE RESTEEM ');
  const pos2 = replyTitleTxt.indexOf('upvote');
  return pos1 + pos2 + 2;
}

const alreadyProcessedLinks = [];
let myPostRepliesId = -1;

const getReplyLink = (element) => element && element.querySelectorAll('a')[5].href;

const updateDbAndGetNewComments = (commentsPage) => {
  const newComments = [];
  var lastTwentyReplies = commentsPage.document.querySelectorAll('div[class="articles__summary"]');
  var lastTwentyRepliesArr = Array.prototype.slice.call(lastTwentyReplies);
  logsOn && console.debug(`${now()} -- Getting new replies..`);
  for (let id = 0; id < lastTwentyRepliesArr.length; id++) {
    const replyTitleTxt = replyTitle(lastTwentyReplies[id]);
    const posizDb = titlesDb.indexOf(replyTitleTxt);
    if (isOneOfMyPosts(replyTitleTxt)) {
      logsOn && console.debug(`My post. Now I process all nazi's replies on my posts.`);
      const replyLink = getReplyLink(lastTwentyReplies[id]);
      if (alreadyProcessedLinks.indexOf(replyLink) !== -1) continue;
      newComments.push(lastTwentyReplies[id]);
      alreadyProcessedLinks[++myPostRepliesId % 40] = replyLink;
    } else if (posizDb !== -1 && MY_ACCOUNT_NAME !== 'gasaeightyfive') {
      logsOn && console.debug(`${now()} -- Skipping this reply. Found in db arr, posiz ${posizDb}. It's reply ${id+1} from the top.`);
      continue;
    } else {
      titlesDb[++repliesDbId % 40] = replyTitleTxt;
      newComments.push(lastTwentyReplies[id]);
    }
  }
  return newComments;
}

async function refreshComments () { // NOTE: not in use anymore
  const repliesTab = document.querySelectorAll('a[href="/@resteem.bot/recent-replies"]')[0];
  repliesTab.click();
  await sleep(2000);
  const commentsTab = document.querySelectorAll('a[href="/@resteem.bot/comments"]')[0];
  commentsTab.click();
  await sleep(2000);
}

let postsDb = [];
let postsDbId = -1;

const updatePostDbAndGetLinksToNewPosts = (postsPage) => {
  const newPosts = [];
  var allBlogItems = postsPage.document.querySelectorAll('ul[class="PostsList__summaries hfeed"]')[0].children;
  var allBlogItemsArr = Array.prototype.slice.call(allBlogItems);
  var firstItemsOnBlogList = allBlogItemsArr.slice(0, 40);
  for (let id = 0; id < firstItemsOnBlogList.length; id++) {
    const htmlElement = allBlogItems[id];
    if (htmlElement.innerText.substr(0,9) !== 'resteemed') {
      logsOn && console.debug(`${now()} -- Found nazi's post and added to db. #${id+1} from top.`);
      const postLink = htmlElement.getElementsByTagName('a')[3].href;
      if (postsDb.indexOf(postLink) === -1) {
        logsOn && console.debug(`${now()} -- It's a new one, not in db. Link: ${postLink}`);
        if (postLink.indexOf('/@resteem.bot/') === -1) throw new Error(`Error. Got invalid link from post extraction: ${postLink}`);
        postsDb[++postsDbId % 40] = postLink;
        newPosts.push(postLink);
      } else {
        logsOn && console.debug(`Was already in db. Going on..`);
      }
    }
  }
  return newPosts;
}

const fillDbWithAllRecentPosts = (postsPage) => {
  logsOn && console.debug(`${now()} -- filling post db with old posts found in last 40 items..`)
  var allBlogItems = postsPage.document.querySelectorAll('ul[class="PostsList__summaries hfeed"]')[0].children;
  var allBlogItemsArr = Array.prototype.slice.call(allBlogItems);
  var firstItemsOnBlogList = allBlogItemsArr.slice(0, 40);
  let count = 0;
  for (let id = 0; id < firstItemsOnBlogList.length; id++) {
    const htmlElement = allBlogItems[id];
    if (htmlElement.innerText.substr(0,9) !== 'resteemed') {
      const postLink = htmlElement.getElementsByTagName('a')[3].href;
      logsOn && console.debug(`${now()} -- Found nazi's post and added to db. #${id+1} from top. Link: ${postLink}`);
      if (postLink.indexOf('/@resteem.bot/') === -1) throw new Error(`Error. Got invalid link from post extraction: ${postLink}`);
      postsDb[++postsDbId % 40] = postLink;
      count++
    }
  }
  logsOn && console.debug(`Added ${count} posts to db.`);
}

let nazisPostsProcessed = 0;

async function processNaziPosts(newPosts) {
  for(let id = 0; id < newPosts.length; id++) {
    const postLink = newPosts[id];
    let wPost = open(postLink);
    await sleep(7000);
    try {
      logsOn && console.debug(`${now()} -- Replying on resteem.bot newly created post..`);
      if (MY_ACCOUNT_NAME !== 'gasaeightyfive') {
        await addReplyToNazi(wPost, 'yep,onpost');
        await sleep(5000);

        logsOn && console.debug(`${now()} -- Self upvoting my new comment on nazi's post @@@ ..`);
        await selfUpvoteMyCommentsToContrastNaziFlag(wPost, 'my-comment-on-top-of-his-post');
      }
      logsOn && console.debug(`${now()} -- Downvoting nazi..`);
      await downVoteNazi(wPost, 'force-downvote');

      nazisPostsProcessed++;
    } catch (err) {
      console.error(`${now()} -- Error in processNaziPosts: ${err}`);
      errors.push(`${now()} -- processNaziPosts __ ${err}`);
    } finally {
      wPost && !wPost.window.closed && wPost.close();
    }
  }
}

async function ifNewPostDownvoteAndComment (skipOld) {
  let postsPage;
  try {
    logsOn && console.debug(`${now()} -- Opening nazi blog list page..`);
    postsPage = open('https://steemit.com/@resteem.bot');
    await sleep(10000);

    logsOn && console.debug(`${now()} -- Adding do not close warning..`);
    addWarning(postsPage);
    postsPage && postsPage.close && postsPage.close(); // page not needed anymore..

    if (skipOld) fillDbWithAllRecentPosts(postsPage);
    const newPosts = updatePostDbAndGetLinksToNewPosts(postsPage);
    if (newPosts.length) {
      await processNaziPosts(newPosts);
    } else {
      logsOn && console.debug(`#####>> NO NEW POSTS FOUND.`);
    }
  } catch (err) {
    console.error(`${now()} -- Error in ifNewPostDownvoteAndComment: ${err}`);
    errors.push(`${now()} -- ifNewPostDownvoteAndComment __ ${err}`);
  } finally {
    postsPage && postsPage.close && postsPage.close();
  }
}

async function damageResteemBot(mode) {
  if (!mode) throw new Error(`Provide mode. "skip-all" to wait for new replies or "now" to anticipate check of new replies.`);
  if (mode !== 'skip-all' && BOT_OFF_AT_HOURS.indexOf(new Date().getHours()) !== -1) {
    logsOn && console.debug(`${now()} In theory nazi is sleeping. Not running.`);
    return;
  }
  let commentsPage;
  try {
    logsOn && console.debug(`${now()} -- Getting rid of outdated content on this page..`);
    const comments = document.querySelectorAll('ul[class="PostsList__summaries hfeed"]')[0];
    comments && comments.parentNode.removeChild(comments);

    logsOn && console.debug(`${now()} -- Opening nazi comments page..`);
    commentsPage = open('https://steemit.com/@resteem.bot/comments');
    await sleep(10000);

    if (mode === 'skip-all') {
      logsOn && console.debug(`${now()} -- Populating db with all replies titles to start only when gets new replies..`);
      fillDbWithAllFirstTwentyReplies(commentsPage);
    } else if (mode.toLowerCase() === 'now') {
      logsOn && console.debug(`${now()} -- Going to check new comments NOW..`);
    } else if (mode === 'timer') {
      logsOn && console.debug(`${now()} -- ${EVERY_X_MINS} passed..`);
    }

    logsOn && console.debug(`${now()} -- Adding do not close warning..`);
    addWarning(commentsPage);

    var newCommentsOnly = updateDbAndGetNewComments(commentsPage);
    commentsPage.close(); commentsPage = null; // no need to leave it open

    if (MY_ACCOUNT_NAME !== 'gasaeightyfive') {
      logsOn && console.debug(`${now()} -- >>>>>>>>>>>>>>>>> Checking if there is a new post from nazi..`);
      await ifNewPostDownvoteAndComment(mode === 'skip-all');
    }

    logsOn && console.debug(`${now()} -- >>>>>>>>>>>>>>>>> Processing ${newCommentsOnly.length} new replies from nazi..`);
    await processAllNewReplies(newCommentsOnly);

    // await refreshComments(); // does not have new ones anyway..

    if (errors.length) {
      addWarning(null, errors);
      // errors = [];
      throw `THERE ARE ERRORS! ${errors.map(e => `- ${e}\n`).join('')}`;
    } else {
      logsOn && console.debug(`${now()} -- SUCCESS. ALL COMPLETED WITHOUT ERRORS. <<<< \n
      Total replies added: ${repliesCount} - 0 for gasa85
      Total downvotes: ${downvotesCount} (off when low vp) - except for gasa85
      Total selfUpvotes: ${selfUpvotesCount} (off when low vp) - 0 for gasa85
      nazisPostsProcessed: ${nazisPostsProcessed}
      enoughVotingPower: ${enoughVotingPower} - always true for gasa85
      `);
    }
  } finally {
    commentsPage && commentsPage.close && commentsPage.close();
  }
}


// startup

if (window.location.href.indexOf('https://steemit.com') == -1) {
  alert('Gotta be on steemit..');
  throw new Error('NOT_ON_STEEMIT');
}

setInterval(() => {
  if (new Date().getHours() === 0 && new Date().getMinutes() <= 15
      && !enoughVotingPower) {
      // if (Math.random() >= 0.5) enoughVotingPower = true;
    }
  stopNow = false;
  damageResteemBot('timer')
}, EVERY_X_MINS * 60 * 1000);

window.onbeforeunload = () => {
  return "Dude, are you sure you want to leave? The nazi is wasting your precious time!";
};

const removeErrors = () => {
  const warningDiv = document.getElementById('warning');
  warningDiv.parentNode.removeChild(warningDiv);
  errors = [];
}

const forceStop = () => stopNow = true;

document['ation'] = `
  damageResteemBot('skip-all'); // then 'now' if want to anticipate execution
  enoughVotingPower = false;
  // forceStop(); // stops processing the new replies it picked up.
  // removeErrors();
`;
